-- Migration: Create Directory Tables
-- Run this in your Supabase SQL Editor

-- ============================================
-- Hotels Directory
-- ============================================
CREATE TABLE IF NOT EXISTS directory_hotels (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    name_kr TEXT,
    location TEXT,
    location_kr TEXT,
    area TEXT,
    area_kr TEXT,
    phone TEXT,
    email TEXT,
    website TEXT,
    stars INTEGER DEFAULT 0,
    notes TEXT,
    notes_kr TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- Transportation Directory
-- ============================================
CREATE TABLE IF NOT EXISTS directory_transport (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    name_kr TEXT,
    location TEXT,
    location_kr TEXT,
    phone TEXT,
    email TEXT,
    vehicles TEXT,
    vehicles_kr TEXT,
    capacity TEXT,
    notes TEXT,
    notes_kr TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- Restaurants Directory
-- ============================================
CREATE TABLE IF NOT EXISTS directory_restaurants (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    name_kr TEXT,
    location TEXT,
    location_kr TEXT,
    cuisine TEXT,
    cuisine_kr TEXT,
    capacity TEXT,
    phone TEXT,
    email TEXT,
    notes TEXT,
    notes_kr TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- Admission/Attractions Directory
-- ============================================
CREATE TABLE IF NOT EXISTS directory_admission (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    name_kr TEXT,
    location TEXT,
    location_kr TEXT,
    type TEXT,
    type_kr TEXT,
    hours TEXT,
    phone TEXT,
    email TEXT,
    website TEXT,
    notes TEXT,
    notes_kr TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- Customers Directory
-- ============================================
CREATE TABLE IF NOT EXISTS directory_customers (
    id TEXT PRIMARY KEY,
    type TEXT DEFAULT 'individual', -- individual, company, agent
    name TEXT NOT NULL,
    name_kr TEXT,
    contact TEXT, -- contact person for companies
    contact_kr TEXT,
    phone TEXT,
    email TEXT,
    country TEXT,
    country_kr TEXT,
    city TEXT,
    city_kr TEXT,
    address TEXT,
    address_kr TEXT,
    reg_no TEXT, -- company registration number
    license TEXT, -- TAT license for agents
    notes TEXT,
    notes_kr TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- Enable Row Level Security (RLS)
-- ============================================
ALTER TABLE directory_hotels ENABLE ROW LEVEL SECURITY;
ALTER TABLE directory_transport ENABLE ROW LEVEL SECURITY;
ALTER TABLE directory_restaurants ENABLE ROW LEVEL SECURITY;
ALTER TABLE directory_admission ENABLE ROW LEVEL SECURITY;
ALTER TABLE directory_customers ENABLE ROW LEVEL SECURITY;

-- ============================================
-- Create policies for anonymous access (adjust as needed)
-- Drop existing policies first to avoid conflicts
-- ============================================
DROP POLICY IF EXISTS "Allow all operations on directory_hotels" ON directory_hotels;
CREATE POLICY "Allow all operations on directory_hotels" ON directory_hotels
    FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all operations on directory_transport" ON directory_transport;
CREATE POLICY "Allow all operations on directory_transport" ON directory_transport
    FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all operations on directory_restaurants" ON directory_restaurants;
CREATE POLICY "Allow all operations on directory_restaurants" ON directory_restaurants
    FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all operations on directory_admission" ON directory_admission;
CREATE POLICY "Allow all operations on directory_admission" ON directory_admission
    FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all operations on directory_customers" ON directory_customers;
CREATE POLICY "Allow all operations on directory_customers" ON directory_customers
    FOR ALL USING (true) WITH CHECK (true);

-- ============================================
-- Create updated_at trigger function (if not exists)
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- ============================================
-- Apply trigger to all directory tables
-- ============================================
DROP TRIGGER IF EXISTS update_directory_hotels_updated_at ON directory_hotels;
CREATE TRIGGER update_directory_hotels_updated_at
    BEFORE UPDATE ON directory_hotels
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_directory_transport_updated_at ON directory_transport;
CREATE TRIGGER update_directory_transport_updated_at
    BEFORE UPDATE ON directory_transport
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_directory_restaurants_updated_at ON directory_restaurants;
CREATE TRIGGER update_directory_restaurants_updated_at
    BEFORE UPDATE ON directory_restaurants
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_directory_admission_updated_at ON directory_admission;
CREATE TRIGGER update_directory_admission_updated_at
    BEFORE UPDATE ON directory_admission
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_directory_customers_updated_at ON directory_customers;
CREATE TRIGGER update_directory_customers_updated_at
    BEFORE UPDATE ON directory_customers
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- Create indexes for better search performance
-- ============================================
CREATE INDEX IF NOT EXISTS idx_directory_hotels_name ON directory_hotels(name);
CREATE INDEX IF NOT EXISTS idx_directory_hotels_location ON directory_hotels(location);
CREATE INDEX IF NOT EXISTS idx_directory_transport_name ON directory_transport(name);
CREATE INDEX IF NOT EXISTS idx_directory_restaurants_name ON directory_restaurants(name);
CREATE INDEX IF NOT EXISTS idx_directory_admission_name ON directory_admission(name);
CREATE INDEX IF NOT EXISTS idx_directory_customers_name ON directory_customers(name);
CREATE INDEX IF NOT EXISTS idx_directory_customers_type ON directory_customers(type);

-- ============================================
-- STORED FUNCTIONS FOR SUPPLIER DIRECTORY
-- ============================================

-- Function to upsert hotel
CREATE OR REPLACE FUNCTION upsert_directory_hotel(
    p_id TEXT,
    p_name TEXT,
    p_name_kr TEXT DEFAULT NULL,
    p_location TEXT DEFAULT NULL,
    p_location_kr TEXT DEFAULT NULL,
    p_area TEXT DEFAULT NULL,
    p_area_kr TEXT DEFAULT NULL,
    p_phone TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL,
    p_website TEXT DEFAULT NULL,
    p_stars INTEGER DEFAULT 0,
    p_notes TEXT DEFAULT NULL,
    p_notes_kr TEXT DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    INSERT INTO directory_hotels (id, name, name_kr, location, location_kr, area, area_kr, phone, email, website, stars, notes, notes_kr)
    VALUES (p_id, p_name, p_name_kr, p_location, p_location_kr, p_area, p_area_kr, p_phone, p_email, p_website, p_stars, p_notes, p_notes_kr)
    ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        name_kr = EXCLUDED.name_kr,
        location = EXCLUDED.location,
        location_kr = EXCLUDED.location_kr,
        area = EXCLUDED.area,
        area_kr = EXCLUDED.area_kr,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        website = EXCLUDED.website,
        stars = EXCLUDED.stars,
        notes = EXCLUDED.notes,
        notes_kr = EXCLUDED.notes_kr,
        updated_at = NOW();
    
    SELECT row_to_json(h) INTO result FROM directory_hotels h WHERE h.id = p_id;
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function to upsert transport
CREATE OR REPLACE FUNCTION upsert_directory_transport(
    p_id TEXT,
    p_name TEXT,
    p_name_kr TEXT DEFAULT NULL,
    p_location TEXT DEFAULT NULL,
    p_location_kr TEXT DEFAULT NULL,
    p_phone TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL,
    p_vehicles TEXT DEFAULT NULL,
    p_vehicles_kr TEXT DEFAULT NULL,
    p_capacity TEXT DEFAULT NULL,
    p_notes TEXT DEFAULT NULL,
    p_notes_kr TEXT DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    INSERT INTO directory_transport (id, name, name_kr, location, location_kr, phone, email, vehicles, vehicles_kr, capacity, notes, notes_kr)
    VALUES (p_id, p_name, p_name_kr, p_location, p_location_kr, p_phone, p_email, p_vehicles, p_vehicles_kr, p_capacity, p_notes, p_notes_kr)
    ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        name_kr = EXCLUDED.name_kr,
        location = EXCLUDED.location,
        location_kr = EXCLUDED.location_kr,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        vehicles = EXCLUDED.vehicles,
        vehicles_kr = EXCLUDED.vehicles_kr,
        capacity = EXCLUDED.capacity,
        notes = EXCLUDED.notes,
        notes_kr = EXCLUDED.notes_kr,
        updated_at = NOW();
    
    SELECT row_to_json(t) INTO result FROM directory_transport t WHERE t.id = p_id;
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function to upsert restaurant
CREATE OR REPLACE FUNCTION upsert_directory_restaurant(
    p_id TEXT,
    p_name TEXT,
    p_name_kr TEXT DEFAULT NULL,
    p_location TEXT DEFAULT NULL,
    p_location_kr TEXT DEFAULT NULL,
    p_cuisine TEXT DEFAULT NULL,
    p_cuisine_kr TEXT DEFAULT NULL,
    p_capacity TEXT DEFAULT NULL,
    p_phone TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL,
    p_notes TEXT DEFAULT NULL,
    p_notes_kr TEXT DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    INSERT INTO directory_restaurants (id, name, name_kr, location, location_kr, cuisine, cuisine_kr, capacity, phone, email, notes, notes_kr)
    VALUES (p_id, p_name, p_name_kr, p_location, p_location_kr, p_cuisine, p_cuisine_kr, p_capacity, p_phone, p_email, p_notes, p_notes_kr)
    ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        name_kr = EXCLUDED.name_kr,
        location = EXCLUDED.location,
        location_kr = EXCLUDED.location_kr,
        cuisine = EXCLUDED.cuisine,
        cuisine_kr = EXCLUDED.cuisine_kr,
        capacity = EXCLUDED.capacity,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        notes = EXCLUDED.notes,
        notes_kr = EXCLUDED.notes_kr,
        updated_at = NOW();
    
    SELECT row_to_json(r) INTO result FROM directory_restaurants r WHERE r.id = p_id;
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function to upsert admission/attraction
CREATE OR REPLACE FUNCTION upsert_directory_admission(
    p_id TEXT,
    p_name TEXT,
    p_name_kr TEXT DEFAULT NULL,
    p_location TEXT DEFAULT NULL,
    p_location_kr TEXT DEFAULT NULL,
    p_type TEXT DEFAULT NULL,
    p_type_kr TEXT DEFAULT NULL,
    p_hours TEXT DEFAULT NULL,
    p_phone TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL,
    p_website TEXT DEFAULT NULL,
    p_notes TEXT DEFAULT NULL,
    p_notes_kr TEXT DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    INSERT INTO directory_admission (id, name, name_kr, location, location_kr, type, type_kr, hours, phone, email, website, notes, notes_kr)
    VALUES (p_id, p_name, p_name_kr, p_location, p_location_kr, p_type, p_type_kr, p_hours, p_phone, p_email, p_website, p_notes, p_notes_kr)
    ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        name_kr = EXCLUDED.name_kr,
        location = EXCLUDED.location,
        location_kr = EXCLUDED.location_kr,
        type = EXCLUDED.type,
        type_kr = EXCLUDED.type_kr,
        hours = EXCLUDED.hours,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        website = EXCLUDED.website,
        notes = EXCLUDED.notes,
        notes_kr = EXCLUDED.notes_kr,
        updated_at = NOW();
    
    SELECT row_to_json(a) INTO result FROM directory_admission a WHERE a.id = p_id;
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function to upsert customer
CREATE OR REPLACE FUNCTION upsert_directory_customer(
    p_id TEXT,
    p_type TEXT DEFAULT 'individual',
    p_name TEXT DEFAULT NULL,
    p_name_kr TEXT DEFAULT NULL,
    p_contact TEXT DEFAULT NULL,
    p_contact_kr TEXT DEFAULT NULL,
    p_phone TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL,
    p_country TEXT DEFAULT NULL,
    p_country_kr TEXT DEFAULT NULL,
    p_city TEXT DEFAULT NULL,
    p_city_kr TEXT DEFAULT NULL,
    p_address TEXT DEFAULT NULL,
    p_address_kr TEXT DEFAULT NULL,
    p_reg_no TEXT DEFAULT NULL,
    p_license TEXT DEFAULT NULL,
    p_notes TEXT DEFAULT NULL,
    p_notes_kr TEXT DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    INSERT INTO directory_customers (id, type, name, name_kr, contact, contact_kr, phone, email, country, country_kr, city, city_kr, address, address_kr, reg_no, license, notes, notes_kr)
    VALUES (p_id, p_type, p_name, p_name_kr, p_contact, p_contact_kr, p_phone, p_email, p_country, p_country_kr, p_city, p_city_kr, p_address, p_address_kr, p_reg_no, p_license, p_notes, p_notes_kr)
    ON CONFLICT (id) DO UPDATE SET
        type = EXCLUDED.type,
        name = EXCLUDED.name,
        name_kr = EXCLUDED.name_kr,
        contact = EXCLUDED.contact,
        contact_kr = EXCLUDED.contact_kr,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        country = EXCLUDED.country,
        country_kr = EXCLUDED.country_kr,
        city = EXCLUDED.city,
        city_kr = EXCLUDED.city_kr,
        address = EXCLUDED.address,
        address_kr = EXCLUDED.address_kr,
        reg_no = EXCLUDED.reg_no,
        license = EXCLUDED.license,
        notes = EXCLUDED.notes,
        notes_kr = EXCLUDED.notes_kr,
        updated_at = NOW();
    
    SELECT row_to_json(c) INTO result FROM directory_customers c WHERE c.id = p_id;
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- SEARCH FUNCTIONS FOR SUPPLIER DIRECTORY
-- ============================================

-- Search hotels by name or location
CREATE OR REPLACE FUNCTION search_directory_hotels(p_query TEXT)
RETURNS SETOF directory_hotels AS $$
BEGIN
    RETURN QUERY
    SELECT * FROM directory_hotels
    WHERE name ILIKE '%' || p_query || '%'
       OR name_kr ILIKE '%' || p_query || '%'
       OR location ILIKE '%' || p_query || '%'
       OR location_kr ILIKE '%' || p_query || '%'
       OR area ILIKE '%' || p_query || '%'
    ORDER BY name;
END;
$$ LANGUAGE plpgsql;

-- Search transport by name
CREATE OR REPLACE FUNCTION search_directory_transport(p_query TEXT)
RETURNS SETOF directory_transport AS $$
BEGIN
    RETURN QUERY
    SELECT * FROM directory_transport
    WHERE name ILIKE '%' || p_query || '%'
       OR name_kr ILIKE '%' || p_query || '%'
       OR location ILIKE '%' || p_query || '%'
       OR vehicles ILIKE '%' || p_query || '%'
    ORDER BY name;
END;
$$ LANGUAGE plpgsql;

-- Search restaurants by name or cuisine
CREATE OR REPLACE FUNCTION search_directory_restaurants(p_query TEXT)
RETURNS SETOF directory_restaurants AS $$
BEGIN
    RETURN QUERY
    SELECT * FROM directory_restaurants
    WHERE name ILIKE '%' || p_query || '%'
       OR name_kr ILIKE '%' || p_query || '%'
       OR location ILIKE '%' || p_query || '%'
       OR cuisine ILIKE '%' || p_query || '%'
    ORDER BY name;
END;
$$ LANGUAGE plpgsql;

-- Search admission/attractions by name or type
CREATE OR REPLACE FUNCTION search_directory_admission(p_query TEXT)
RETURNS SETOF directory_admission AS $$
BEGIN
    RETURN QUERY
    SELECT * FROM directory_admission
    WHERE name ILIKE '%' || p_query || '%'
       OR name_kr ILIKE '%' || p_query || '%'
       OR location ILIKE '%' || p_query || '%'
       OR type ILIKE '%' || p_query || '%'
    ORDER BY name;
END;
$$ LANGUAGE plpgsql;

-- Search customers by name, email, or phone
CREATE OR REPLACE FUNCTION search_directory_customers(p_query TEXT, p_type TEXT DEFAULT NULL)
RETURNS SETOF directory_customers AS $$
BEGIN
    RETURN QUERY
    SELECT * FROM directory_customers
    WHERE (name ILIKE '%' || p_query || '%'
       OR name_kr ILIKE '%' || p_query || '%'
       OR email ILIKE '%' || p_query || '%'
       OR phone ILIKE '%' || p_query || '%'
       OR contact ILIKE '%' || p_query || '%')
       AND (p_type IS NULL OR type = p_type)
    ORDER BY name;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- GET ALL SUPPLIERS FUNCTION
-- ============================================
CREATE OR REPLACE FUNCTION get_all_suppliers()
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_build_object(
        'hotels', (SELECT COALESCE(json_agg(h ORDER BY h.name), '[]'::json) FROM directory_hotels h),
        'transport', (SELECT COALESCE(json_agg(t ORDER BY t.name), '[]'::json) FROM directory_transport t),
        'restaurants', (SELECT COALESCE(json_agg(r ORDER BY r.name), '[]'::json) FROM directory_restaurants r),
        'admission', (SELECT COALESCE(json_agg(a ORDER BY a.name), '[]'::json) FROM directory_admission a)
    ) INTO result;
    RETURN result;
END;
$$ LANGUAGE plpgsql;
