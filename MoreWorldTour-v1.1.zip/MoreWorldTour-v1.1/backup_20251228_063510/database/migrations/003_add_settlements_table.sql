-- ==========================================
-- TOURIX - Settlements Table Migration
-- 단체 정산서 (Group Settlement) Storage
-- ==========================================

-- Create settlements table
CREATE TABLE IF NOT EXISTS settlements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID REFERENCES bookings(id) ON DELETE SET NULL,
    booking_number VARCHAR(50),
    
    -- Basic Info
    group_name VARCHAR(255),
    pax_count INTEGER DEFAULT 0,
    tc VARCHAR(100),
    period VARCHAR(100),
    guide VARCHAR(100),
    
    -- Exchange Rate
    exchange_rate DECIMAL(10,2) DEFAULT 1350,
    
    -- Income Items (수금) - JSON array
    -- Each item: { name, pax, usd_price, krw_total }
    income_items JSONB DEFAULT '[]'::jsonb,
    
    -- Shopping Revenue (쇼핑센터) - JSON array
    -- Each item: { name, sales, commission_percent, commission_amount, subtotal }
    shopping_items JSONB DEFAULT '[]'::jsonb,
    
    -- Duty Free (면세점) - JSON array
    duty_free_items JSONB DEFAULT '[]'::jsonb,
    
    -- Other Revenue (기타 수익) - JSON array
    -- Each item: { name, amount, notes }
    other_revenue_items JSONB DEFAULT '[]'::jsonb,
    
    -- Hotel Expenses (호텔) - JSON array
    -- Each item: { name, nights, rooms, unit_price, total }
    hotel_items JSONB DEFAULT '[]'::jsonb,
    
    -- Transport Expenses (차량) - JSON array
    transport_items JSONB DEFAULT '[]'::jsonb,
    
    -- Meal Expenses (식사) - JSON array
    -- Each item: { name, pax, unit_price, total }
    meal_items JSONB DEFAULT '[]'::jsonb,
    
    -- Admission Expenses (입장료) - JSON array
    admission_items JSONB DEFAULT '[]'::jsonb,
    
    -- Guide/Driver Expenses (가이드/기사) - JSON array
    guide_driver_items JSONB DEFAULT '[]'::jsonb,
    
    -- Other Expenses (기타 지출) - JSON array
    other_expense_items JSONB DEFAULT '[]'::jsonb,
    
    -- Calculated Totals
    total_income_krw DECIMAL(15,2) DEFAULT 0,
    total_shopping_revenue DECIMAL(15,2) DEFAULT 0,
    total_duty_free_revenue DECIMAL(15,2) DEFAULT 0,
    total_other_revenue DECIMAL(15,2) DEFAULT 0,
    total_revenue DECIMAL(15,2) DEFAULT 0,
    
    total_hotel_expense DECIMAL(15,2) DEFAULT 0,
    total_transport_expense DECIMAL(15,2) DEFAULT 0,
    total_meal_expense DECIMAL(15,2) DEFAULT 0,
    total_admission_expense DECIMAL(15,2) DEFAULT 0,
    total_guide_driver_expense DECIMAL(15,2) DEFAULT 0,
    total_other_expense DECIMAL(15,2) DEFAULT 0,
    total_expense DECIMAL(15,2) DEFAULT 0,
    
    per_person_cost DECIMAL(15,2) DEFAULT 0,
    per_person_income DECIMAL(15,2) DEFAULT 0,
    profit DECIMAL(15,2) DEFAULT 0,
    balance DECIMAL(15,2) DEFAULT 0,
    
    -- Notes
    notes TEXT,
    
    -- Metadata
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'finalized', 'approved')),
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_settlements_booking ON settlements(booking_id);
CREATE INDEX idx_settlements_booking_number ON settlements(booking_number);
CREATE INDEX idx_settlements_created_at ON settlements(created_at);
CREATE INDEX idx_settlements_status ON settlements(status);

-- Enable RLS
ALTER TABLE settlements ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Allow read access for authenticated users" ON settlements
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow insert for authenticated users" ON settlements
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow update for authenticated users" ON settlements
    FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Allow delete for authenticated users" ON settlements
    FOR DELETE USING (auth.role() = 'authenticated');

-- For anonymous access (if not using auth)
CREATE POLICY "Allow anonymous read" ON settlements
    FOR SELECT USING (true);

CREATE POLICY "Allow anonymous insert" ON settlements
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow anonymous update" ON settlements
    FOR UPDATE USING (true);

-- Trigger for updated_at
CREATE TRIGGER update_settlements_updated_at BEFORE UPDATE ON settlements
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ==========================================
-- Run this in Supabase SQL Editor
-- ==========================================
