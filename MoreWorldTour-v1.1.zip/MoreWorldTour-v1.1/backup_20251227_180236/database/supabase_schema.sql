-- ==========================================
-- TOURIX - Supabase Database Schema
-- Tour Management System
-- ==========================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ==========================================
-- 1. CUSTOMERS TABLE
-- ==========================================
CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_name VARCHAR(255) NOT NULL,
    contact_person VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_customers_email ON customers(email);
CREATE INDEX idx_customers_name ON customers(customer_name);

-- ==========================================
-- 2. QUOTATIONS TABLE (Main)
-- ==========================================
CREATE TABLE quotations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quotation_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
    
    -- Customer details (denormalized for quote snapshot)
    customer_name VARCHAR(255),
    contact_person VARCHAR(255),
    customer_email VARCHAR(255),
    customer_phone VARCHAR(50),
    
    -- Quotation type
    quotation_type VARCHAR(20) NOT NULL CHECK (quotation_type IN ('itinerary', 'service')),
    
    -- Dates
    quotation_date DATE NOT NULL,
    valid_until DATE,
    travel_date DATE,
    
    -- Tour details (for itinerary type)
    tour_name VARCHAR(255),
    destination VARCHAR(255),
    number_of_days INTEGER,
    number_of_passengers INTEGER,
    
    -- Service details (for service type)
    service_period VARCHAR(100),
    service_type VARCHAR(100),
    
    -- Pricing
    subtotal DECIMAL(12,2) DEFAULT 0,
    discount_percent DECIMAL(5,2) DEFAULT 0,
    discount_amount DECIMAL(12,2) DEFAULT 0,
    tax_percent DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(12,2) DEFAULT 0,
    grand_total DECIMAL(12,2) DEFAULT 0,
    per_person_price DECIMAL(12,2) DEFAULT 0,
    currency VARCHAR(10) DEFAULT 'USD',
    
    -- Additional info
    inclusions TEXT,
    exclusions TEXT,
    terms_conditions TEXT,
    internal_notes TEXT,
    
    -- Status
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'confirmed', 'cancelled', 'expired')),
    
    -- Metadata
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    sent_at TIMESTAMP WITH TIME ZONE,
    confirmed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_quotations_number ON quotations(quotation_number);
CREATE INDEX idx_quotations_customer ON quotations(customer_id);
CREATE INDEX idx_quotations_date ON quotations(quotation_date);
CREATE INDEX idx_quotations_status ON quotations(status);
CREATE INDEX idx_quotations_type ON quotations(quotation_type);

-- ==========================================
-- 3. ITINERARY DAYS TABLE
-- ==========================================
CREATE TABLE itinerary_days (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quotation_id UUID NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
    day_number INTEGER NOT NULL,
    day_date DATE,
    day_title VARCHAR(255),
    
    -- Hotel information
    hotel_name VARCHAR(255),
    hotel_star_rating INTEGER,
    room_type VARCHAR(100),
    
    -- Meals
    breakfast BOOLEAN DEFAULT false,
    breakfast_menu TEXT,
    lunch BOOLEAN DEFAULT false,
    lunch_menu TEXT,
    dinner BOOLEAN DEFAULT false,
    dinner_menu TEXT,
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_quotation_day UNIQUE (quotation_id, day_number)
);

CREATE INDEX idx_itinerary_days_quotation ON itinerary_days(quotation_id);
CREATE INDEX idx_itinerary_days_number ON itinerary_days(day_number);

-- ==========================================
-- 4. ACTIVITIES TABLE
-- ==========================================
CREATE TABLE activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    itinerary_day_id UUID NOT NULL REFERENCES itinerary_days(id) ON DELETE CASCADE,
    activity_number INTEGER NOT NULL,
    activity_description TEXT NOT NULL,
    activity_time VARCHAR(50),
    duration VARCHAR(50),
    location VARCHAR(255),
    notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_day_activity UNIQUE (itinerary_day_id, activity_number)
);

CREATE INDEX idx_activities_day ON activities(itinerary_day_id);

-- ==========================================
-- 5. PRICING ITEMS TABLE
-- ==========================================
CREATE TABLE pricing_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quotation_id UUID NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
    item_number INTEGER NOT NULL,
    description TEXT NOT NULL,
    quantity INTEGER DEFAULT 1,
    unit VARCHAR(50),
    rate DECIMAL(12,2) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_quotation_item UNIQUE (quotation_id, item_number)
);

CREATE INDEX idx_pricing_items_quotation ON pricing_items(quotation_id);

-- ==========================================
-- 6. BOOKINGS TABLE
-- ==========================================
CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_number VARCHAR(50) UNIQUE NOT NULL,
    quotation_id UUID REFERENCES quotations(id) ON DELETE SET NULL,
    customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
    
    -- Booking details
    booking_date DATE NOT NULL,
    travel_start_date DATE NOT NULL,
    travel_end_date DATE,
    number_of_passengers INTEGER NOT NULL,
    
    -- Flight information
    arrival_flight VARCHAR(100),
    departure_flight VARCHAR(100),
    -- Duration (string like '2 Days 1 Night' or numeric representation)
    duration VARCHAR(100),
    
    -- Hotel booking
    hotel_name VARCHAR(255),
    hotel_confirmation_no VARCHAR(100),
    hotel_tel VARCHAR(50),
    hotel_address TEXT,
    room_twn INTEGER DEFAULT 0,
    room_dbl INTEGER DEFAULT 0,
    room_sgl INTEGER DEFAULT 0,
    room_trp INTEGER DEFAULT 0,
    room_other INTEGER DEFAULT 0,
    room_total INTEGER DEFAULT 0,
    
    -- Hotel workflow
    hotel_request_status VARCHAR(50) DEFAULT 'draft',
    hotel_special_requests TEXT,
    
    -- Hotels (JSON array with multiple hotel bookings)
    -- Each hotel object: { id, name, confirmation_no, tel, address, checkIn, checkOut, room_twn, room_dbl, room_sgl, room_trp, room_other, status, notes }
    hotels JSONB DEFAULT '[]'::jsonb,
    
    -- Transports (JSON array with transport bookings)
    -- Each transport object: { id, company, vehicle_type, driver, phone, license_plate, startDate, endDate, pickup_time, notes }
    transports JSONB DEFAULT '[]'::jsonb,
    
    -- Tour Guides (JSON array with guide assignments)
    -- Each guide object: { id, name, phone, languages, license, rating, startDate, endDate }
    guides JSONB DEFAULT '[]'::jsonb,
    
    -- Restaurants/Meals (JSON array with meal bookings)
    -- Each restaurant object: { id, name, cuisine, location, phone, date, meal_type, pax, notes }
    restaurants JSONB DEFAULT '[]'::jsonb,
    
    -- Admissions/Tickets (JSON array with admission bookings)
    -- Each admission object: { id, name, date, reservation_no, reservation_time, adult_price, adult_qty, child_price, child_qty, notes }
    admissions JSONB DEFAULT '[]'::jsonb,
    
    -- Financial
    total_amount DECIMAL(12,2) NOT NULL,
    deposit_amount DECIMAL(12,2),
    paid_amount DECIMAL(12,2) DEFAULT 0,
    balance_amount DECIMAL(12,2),
    
    -- Status
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'processing', 'completed', 'cancelled')),
    
    -- Additional info
    special_requests TEXT,
    internal_notes TEXT,
    
    -- Metadata
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    confirmed_at TIMESTAMP WITH TIME ZONE,
    cancelled_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_bookings_number ON bookings(booking_number);
CREATE INDEX idx_bookings_customer ON bookings(customer_id);
CREATE INDEX idx_bookings_quotation ON bookings(quotation_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_travel_date ON bookings(travel_start_date);

-- ==========================================
-- 7. USERS TABLE (for authentication)
-- ==========================================
-- Note: Supabase has built-in auth.users table
-- This is for additional user profile information
CREATE TABLE user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'agent' CHECK (role IN ('admin', 'manager', 'agent')),
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50),
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_user_profiles_email ON user_profiles(email);
CREATE INDEX idx_user_profiles_role ON user_profiles(role);

-- ==========================================
-- 8. AUDIT LOG TABLE (optional but recommended)
-- ==========================================
CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(50) NOT NULL,
    record_id UUID NOT NULL,
    action VARCHAR(20) NOT NULL CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
    old_data JSONB,
    new_data JSONB,
    changed_by UUID REFERENCES auth.users(id),
    changed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_log_table ON audit_log(table_name);
CREATE INDEX idx_audit_log_record ON audit_log(record_id);
CREATE INDEX idx_audit_log_date ON audit_log(changed_at);

-- ==========================================
-- FUNCTIONS & TRIGGERS
-- ==========================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at trigger to all tables
CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON customers
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_quotations_updated_at BEFORE UPDATE ON quotations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_itinerary_days_updated_at BEFORE UPDATE ON itinerary_days
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_activities_updated_at BEFORE UPDATE ON activities
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_pricing_items_updated_at BEFORE UPDATE ON pricing_items
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at BEFORE UPDATE ON bookings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON user_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ==========================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================

-- Enable RLS on all tables
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotations ENABLE ROW LEVEL SECURITY;
ALTER TABLE itinerary_days ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read all data
CREATE POLICY "Allow read access for authenticated users" ON customers
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access for authenticated users" ON quotations
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access for authenticated users" ON itinerary_days
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access for authenticated users" ON activities
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access for authenticated users" ON pricing_items
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access for authenticated users" ON bookings
    FOR SELECT USING (auth.role() = 'authenticated');

-- Allow authenticated users to insert/update their own data
CREATE POLICY "Allow insert for authenticated users" ON customers
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow insert for authenticated users" ON quotations
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow update for authenticated users" ON customers
    FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Allow update for authenticated users" ON quotations
    FOR UPDATE USING (auth.role() = 'authenticated');

-- ==========================================
-- SAMPLE DATA (for testing)
-- ==========================================

-- Insert sample customer
INSERT INTO customers (customer_name, contact_person, email, phone, city, country)
VALUES 
    ('ABC Travel Agency', 'John Smith', 'john@abctravel.com', '+1-555-0123', 'New York', 'USA'),
    ('Global Tours Ltd', 'Sarah Johnson', 'sarah@globaltours.com', '+44-20-1234-5678', 'London', 'UK');

-- Note: You can run this entire file in Supabase SQL Editor
