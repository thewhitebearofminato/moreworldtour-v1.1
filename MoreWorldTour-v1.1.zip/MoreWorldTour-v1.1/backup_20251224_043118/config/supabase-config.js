// ==========================================
// TOURIX - Supabase Configuration
// ==========================================

// TODO: Replace these with your actual Supabase credentials
// Get them from: Supabase Dashboard → Settings → API

const SUPABASE_URL = 'https://xokvixmokaltfqdtsblq.supabase.co';  // e.g., https://xxxxx.supabase.co
const SUPABASE_ANON_KEY = 'sb_publishable_LmnJO1AvuXPdI_IgJyzlJg_IYDPnaqV';  // Long string starting with eyJhbGc...

// Initialize Supabase client
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Export for use in other files
window.supabaseClient = supabase;
