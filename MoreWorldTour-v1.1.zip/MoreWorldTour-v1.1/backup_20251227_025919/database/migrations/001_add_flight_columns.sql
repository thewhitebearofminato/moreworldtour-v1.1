-- ==========================================
-- Migration: Add flight columns to bookings
-- Run this in Supabase SQL Editor
-- ==========================================

-- Add arrival_flight and departure_flight columns
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS arrival_flight VARCHAR(100);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS departure_flight VARCHAR(100);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS duration VARCHAR(100);

-- Hotel booking columns
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS hotel_name VARCHAR(255);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS hotel_confirmation_no VARCHAR(100);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS hotel_tel VARCHAR(50);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS hotel_address TEXT;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS room_twn INTEGER DEFAULT 0;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS room_dbl INTEGER DEFAULT 0;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS room_sgl INTEGER DEFAULT 0;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS room_trp INTEGER DEFAULT 0;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS room_other INTEGER DEFAULT 0;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS room_total INTEGER DEFAULT 0;

-- Hotel workflow columns
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS hotel_request_status VARCHAR(50) DEFAULT 'draft';
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS hotel_special_requests TEXT;

-- Update RLS policies to allow updates from anonymous users (for development)
-- Remove or modify these for production with proper authentication

-- Allow anonymous select
CREATE POLICY "Allow select for anon" ON bookings
    FOR SELECT TO anon
    USING (true);

-- Allow anonymous insert
CREATE POLICY "Allow insert for anon" ON bookings
    FOR INSERT TO anon
    WITH CHECK (true);

-- Allow anonymous update
CREATE POLICY "Allow update for anon" ON bookings
    FOR UPDATE TO anon
    USING (true)
    WITH CHECK (true);

-- Verify the columns were added
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'bookings' 
AND column_name IN ('arrival_flight', 'departure_flight');
