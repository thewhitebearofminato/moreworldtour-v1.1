// ==========================================
// TOURIX - Main Application Script
// ==========================================

// Current page state
let currentPage = 'dashboard';

// ==========================================
// Dynamic Content Loading
// ==========================================
async function loadContent(page) {
    const contentArea = document.getElementById('contentArea');
    const headerTitle = document.querySelector('.header-left h1');
    const breadcrumb = document.querySelector('.breadcrumb');
    
    // Show loading spinner
    contentArea.innerHTML = `
        <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading...</p>
        </div>
    `;
    
    try {
        // Fetch content from the content folder
        const response = await fetch(`content/${page}.html`);
        
        if (!response.ok) {
            throw new Error('Page not found');
        }
        
        const html = await response.text();
        contentArea.innerHTML = html;
        
        // Update page title mapping
        const pageTitles = {
            'dashboard': 'Dashboard',
            'quotations': 'Quotations',
            'quotation-itinerary': 'Quotation with Itinerary',
            'quotation-service': 'Quotation by Service',
            'quotation-summary': 'Quotation Summary',
            'quotation-service-summary': 'Service Quotation Summary',
            'booking': 'Booking',
            'booking-confirmation': 'Booking Confirmation',
            'print-confirmation': 'Print Confirmation',
            'operation': 'Operation Timeline',
            'operation-arrangement': 'Operation Arrangement',
            'tour-product': 'Tour Product',
            'financial': 'Financial',
            'directory': 'Directory'
        };
        
        // Update header
        const title = pageTitles[page] || page.charAt(0).toUpperCase() + page.slice(1);
        if (headerTitle) headerTitle.textContent = title;
        if (breadcrumb) breadcrumb.textContent = `Overview / ${title}`;
        
        // Update active nav item
        updateActiveNavItem(page);
        
        // Update current page
        currentPage = page;
        
        // Save to URL hash for refresh persistence
        window.location.hash = page;
        
        // Also save to localStorage as backup
        localStorage.setItem('currentPage', page);
        
        // Initialize page-specific scripts
        initPageScripts(page);
        
        // Scroll to top
        contentArea.scrollTop = 0;
        
    } catch (error) {
        contentArea.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Page Not Found</h3>
                <p>The requested page could not be loaded.</p>
                <button class="btn-primary" onclick="loadContent('dashboard')">
                    <i class="fas fa-home"></i> Back to Dashboard
                </button>
            </div>
        `;
        console.error('Error loading content:', error);
    }
}

// Update active navigation item
function updateActiveNavItem(page) {
    const navItems = document.querySelectorAll('.nav-menu .nav-item');
    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) {
            item.classList.add('active');
            
            // If item is in submenu, open the parent submenu
            const parentSubmenu = item.closest('.submenu');
            if (parentSubmenu) {
                parentSubmenu.classList.add('open');
                const parentNavItem = parentSubmenu.previousElementSibling;
                if (parentNavItem) {
                    parentNavItem.classList.add('open');
                }
            }
        }
    });
}

// Toggle submenu visibility
window.toggleSubmenu = function(event, submenuId) {
    event.preventDefault();
    event.stopPropagation();
    
    const submenu = document.getElementById(submenuId);
    const navItem = event.currentTarget;
    
    if (submenu) {
        submenu.classList.toggle('open');
        navItem.classList.toggle('open');
    }
};

// Initialize page-specific scripts after content loads
function initPageScripts(page) {
    try {
        if (page === 'dashboard') {
            initDashboardCharts();
            initContactFilters();
        } else if (page === 'quotation-itinerary') {
            initQuotePage();
        } else if (page === 'quotation-service') {
            initQuoteServicePage();
        } else if (page === 'quotations') {
            loadQuotationsFromStorage();
        } else if (page === 'quotation-summary') {
            populateSummaryPage();
        } else if (page === 'quotation-service-summary') {
            populateServiceSummaryPage();
        } else if (page === 'booking') {
            loadBookings();
        } else if (page === 'booking-confirmation') {
            initBookingConfirmationPage();
        } else if (page === 'print-confirmation') {
            initPrintConfirmation();
        } else if (page === 'operation') {
            initOperationTimeline();
        } else if (page === 'operation-arrangement') {
            initOperationArrangement();
        }
    } catch (error) {
        console.error('Error initializing page scripts:', error);
    }
}

// ==========================================
// Booking Management Functions
// ==========================================

function loadBookings(attempt = 0) {
    console.log('📂 loadBookings() called (attempt', attempt + 1 + ')');

    // Try multiple selectors in case content is not yet parsed into the DOM
    const findTbody = () => document.getElementById('bookingsBody') || document.querySelector('#contentArea #bookingsBody') || document.querySelector('.page-container #bookingsBody');
    const tbody = findTbody();

    if (!tbody) {
        if (attempt < 8) {
            // Retry shortly — sometimes loadContent hasn't fully inserted DOM
            setTimeout(() => loadBookings(attempt + 1), 120);
            return;
        }
        console.error('❌ bookingsBody not found after retries');
        return;
    }
    
    let allBookings = [];
    try {
        allBookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
        console.log('📦 Found bookings in localStorage:', allBookings.length);
    } catch (e) {
        console.error('❌ Error reading localStorage:', e);
        allBookings = [];
    }
    
    tbody.innerHTML = '';
    
    if (allBookings.length === 0) {
        tbody.innerHTML = `
            <tr id="emptyRow">
                <td colspan="8" style="padding:60px;text-align:center;color:#94a3b8;">
                    <i class="fas fa-inbox" style="font-size:48px;margin-bottom:16px;display:block;opacity:0.5;"></i>
                    <p style="margin:0;font-size:16px;">No bookings found</p>
                    <p style="margin:8px 0 0 0;font-size:13px;">Bookings will appear here when created from quotations</p>
                </td>
            </tr>
        `;
        updateBookingCounts([]);
        return;
    }
    
    allBookings.sort((a, b) => new Date(b.booking_date) - new Date(a.booking_date));
    
    allBookings.forEach(booking => {
        console.log('➕ Adding row for:', booking.booking_id);
        const row = createBookingRow(booking);
        tbody.appendChild(row);
    });
    
    updateBookingCounts(allBookings);
    console.log('✅ Total bookings displayed:', allBookings.length);
}

function createBookingRow(booking) {
    const row = document.createElement('tr');
    row.dataset.bookingId = booking.booking_id;
    row.dataset.status = booking.status || 'confirmed';
    
    row.style.cssText = 'border-bottom:1px solid #f1f5f9;transition:background 0.2s;background:white;';
    row.onmouseover = function() { this.style.background = '#f8fafc'; };
    row.onmouseout = function() { this.style.background = 'white'; };
    
    const formatDate = (dateStr) => {
        if (!dateStr) return '-';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' });
    };
    
    const getStatusStyle = (status) => {
        const styles = {
            'confirmed': 'background:#fef3c7;color:#92400e;',
            'processing': 'background:#dcfce7;color:#166534;',
            'completed': 'background:#dbeafe;color:#1e40af;',
            'cancelled': 'background:#fee2e2;color:#991b1b;'
        };
        return styles[status] || styles['confirmed'];
    };
    
    const getStatusLabel = (status) => {
        const labels = {
            'confirmed': 'Receive from OP',
            'processing': 'Send to Sales',
            'completed': 'Sales Updated',
            'cancelled': 'Cancelled'
        };
        return labels[status] || 'Receive from OP';
    };
    
    const status = booking.status || 'confirmed';
    
    row.innerHTML = `
        <td style="padding:14px 16px;">
            <a href="#" onclick="viewBooking('${booking.booking_id}'); return false;" style="color:#3b82f6;font-weight:600;text-decoration:none;">
                ${booking.booking_id}
            </a>
        </td>
        <td style="padding:14px 16px;color:#1e293b;">${booking.customer_name || '-'}</td>
        <td style="padding:14px 16px;color:#64748b;">${booking.nationality || '-'}</td>
        <td style="padding:14px 16px;color:#1e293b;">${booking.tour_name || '-'}</td>
        <td style="padding:14px 16px;color:#64748b;">${formatDate(booking.travel_date)}${booking.arrival_flight ? `<div style="font-size:12px;color:#94a3b8;margin-top:6px;">${booking.arrival_flight}</div>` : ''}</td>
        <td style="padding:14px 16px;color:#64748b;">${formatDate(booking.end_date)}${booking.departure_flight ? `<div style="font-size:12px;color:#94a3b8;margin-top:6px;">${booking.departure_flight}</div>` : ''}</td>
        <td style="padding:14px 16px;">
            <span style="padding:4px 12px;border-radius:20px;font-size:12px;font-weight:500;${getStatusStyle(status)}">
                ${getStatusLabel(status)}
            </span>
        </td>
        <td style="padding:14px 16px;text-align:center;">
            <div style="display:flex;justify-content:center;gap:8px;">
                <button onclick="toggleBookingHighlight('${booking.booking_id}')" title="Highlight" style="width:32px;height:32px;border:none;background:#f1f5f9;border-radius:6px;cursor:pointer;color:#64748b;">
                    <i class="fas fa-highlighter"></i>
                </button>
                <button onclick="duplicateBooking('${booking.booking_id}')" title="Duplicate" style="width:32px;height:32px;border:none;background:#f1f5f9;border-radius:6px;cursor:pointer;color:#64748b;">
                    <i class="fas fa-copy"></i>
                </button>
                <button onclick="deleteBooking('${booking.booking_id}')" title="Delete" style="width:32px;height:32px;border:none;background:#fee2e2;border-radius:6px;cursor:pointer;color:#ef4444;">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </td>
    `;
    
    return row;
}

function updateBookingCounts(bookings) {
    const countAll = document.getElementById('countAll');
    const countConfirmed = document.getElementById('countConfirmed');
    const countProcessing = document.getElementById('countProcessing');
    const countCompleted = document.getElementById('countCompleted');
    const countCancelled = document.getElementById('countCancelled');
    
    if (countAll) countAll.textContent = bookings.length;
    if (countConfirmed) countConfirmed.textContent = bookings.filter(b => b.status === 'confirmed').length;
    if (countProcessing) countProcessing.textContent = bookings.filter(b => b.status === 'processing').length;
    if (countCompleted) countCompleted.textContent = bookings.filter(b => b.status === 'completed').length;
    if (countCancelled) countCancelled.textContent = bookings.filter(b => b.status === 'cancelled').length;
}

function filterBookings(status) {
    document.querySelectorAll('.stat-card').forEach(card => {
        card.style.border = '2px solid transparent';
    });
    const activeCard = document.querySelector(`[data-filter="${status}"]`);
    if (activeCard) activeCard.style.border = '2px solid #3b82f6';
    
    const rows = document.querySelectorAll('#bookingsBody tr[data-booking-id]');
    rows.forEach(row => {
        row.style.display = (status === 'all' || row.dataset.status === status) ? '' : 'none';
    });
}

function searchBookings() {
    const searchInput = document.getElementById('searchBookings');
    if (!searchInput) return;
    const query = searchInput.value.toLowerCase();
    const rows = document.querySelectorAll('#bookingsBody tr[data-booking-id]');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(query) ? '' : 'none';
    });
}

function viewBooking(bookingId) {
    const bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const booking = bookings.find(b => b.booking_id === bookingId);
    
    if (booking) {
        // Store the current booking for the confirmation page
        localStorage.setItem('currentBooking', JSON.stringify(booking));
        loadContent('booking-confirmation');
    } else {
        showNotification('Booking details not found', 'error');
    }
}

function toggleBookingHighlight(bookingId) {
    const row = document.querySelector(`tr[data-booking-id="${bookingId}"]`);
    if (row) {
        const isHighlighted = row.style.background === 'rgb(254, 249, 195)';
        row.style.background = isHighlighted ? 'white' : '#fef9c3';
    }
}

function duplicateBooking(bookingId) {
    showNotification('Duplicate feature coming soon', 'info');
}

function deleteBooking(bookingId) {
    if (confirm('Are you sure you want to delete this booking?')) {
        let bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
        bookings = bookings.filter(b => b.booking_id !== bookingId);
        localStorage.setItem('bookingsList', JSON.stringify(bookings));
        loadBookings();
        showNotification('Booking deleted successfully', 'success');
    }
}

function createNewBooking() {
    showNotification('Please create a booking from a confirmed quotation', 'info');
}

function createTestBooking() {
    const testBooking = {
        booking_id: 'BK-2025-TEST',
        quotation_number: 'QT-2025-0001',
        customer_name: 'Test Company Ltd.',
        nationality: 'Thailand',
        tour_name: 'Amazing Thailand Tour',
        travel_date: '2025-01-15',
        end_date: '2025-01-20',
        status: 'confirmed',
        booking_date: new Date().toISOString(),
        pax_count: 4
    };
    
    try {
        let bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
        bookings = bookings.filter(b => b.booking_id !== 'BK-2025-TEST');
        bookings.unshift(testBooking);
        localStorage.setItem('bookingsList', JSON.stringify(bookings));
        console.log('✅ Test booking created');
        loadBookings();
        showNotification('Test booking created!', 'success');
    } catch (e) {
        console.error('❌ Error creating test booking:', e);
        alert('Error: ' + e.message);
    }
}

// ==========================================
// Booking Confirmation Page Functions
// ==========================================

function initBookingConfirmationPage() {
    console.log('📋 Initializing Booking Confirmation page');
    
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) {
        showNotification('No booking data found', 'error');
        loadContent('booking');
        return;
    }
    
    const booking = JSON.parse(bookingData);
    const fullData = booking.full_data || {};
    
    console.log('📦 Booking data:', booking);
    
    // Format date helper
    const formatDate = (dateStr) => {
        if (!dateStr) return '-';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' });
    };
    
    // Populate booking ID and date
    const bookingIdEl = document.getElementById('bookingIdDisplay');
    const bookingDateEl = document.getElementById('bookingDateDisplay');
    if (bookingIdEl) bookingIdEl.textContent = booking.booking_id;
    if (bookingDateEl) bookingDateEl.textContent = formatDate(booking.booking_date);
    
    // Update status banner based on status
    updateStatusBanner(booking.status || 'confirmed');
    
    // Customer Information
    const customerNameEl = document.getElementById('customerName');
    const nationalityEl = document.getElementById('nationality');
    const contactPersonEl = document.getElementById('contactPerson');
    const customerEmailEl = document.getElementById('customerEmail');
    
    if (customerNameEl) customerNameEl.textContent = booking.customer_name || fullData.customer_name || '-';
    if (nationalityEl) nationalityEl.textContent = booking.nationality || fullData.nationality || '-';
    if (contactPersonEl) contactPersonEl.textContent = fullData.contact_person || '-';
    if (customerEmailEl) customerEmailEl.textContent = fullData.email || '-';
    
    // Tour Information
    const tourNameEl = document.getElementById('tourName');
    const quotationNumberEl = document.getElementById('quotationNumber');
    const durationEl = document.getElementById('duration');
    const paxCountEl = document.getElementById('paxCount');
    
    if (tourNameEl) tourNameEl.textContent = booking.tour_name || fullData.tour_name || '-';
    if (quotationNumberEl) quotationNumberEl.textContent = booking.quotation_number || '-';
    // Prefer top-level booking.duration (saved), fall back to full_data snapshot
    if (durationEl) durationEl.textContent = booking.duration || fullData.duration || '-';
    if (paxCountEl) paxCountEl.textContent = booking.pax_count || fullData.pax || '-';
    
    // Travel Dates
    const arrivalDateEl = document.getElementById('arrivalDate');
    const departureDateEl = document.getElementById('departureDate');
    const arrivalFlightEl = document.getElementById('arrivalFlight');
    const departureFlightEl = document.getElementById('departureFlight');
    
    if (arrivalDateEl) arrivalDateEl.textContent = formatDate(booking.travel_date || fullData.travel_date || fullData.arrival_date);
    if (departureDateEl) departureDateEl.textContent = formatDate(booking.end_date || fullData.end_date || fullData.departure_date);
    // Prefer top-level booking fields (saved), fall back to full_data snapshot
    if (arrivalFlightEl) arrivalFlightEl.textContent = booking.arrival_flight || fullData.arrival_flight || '-';
    if (departureFlightEl) departureFlightEl.textContent = booking.departure_flight || fullData.departure_flight || '-';
    
    // Hotel Booking - Display hotels from quotation itinerary for selection
    const itineraryHotelsSection = document.getElementById('itineraryHotelsSection');
    const itineraryHotelsList = document.getElementById('itineraryHotelsList');
    if (itineraryHotelsSection && itineraryHotelsList && fullData.itinerary && fullData.itinerary.length > 0) {
        // Get unique hotels from itinerary
        const hotelsMap = new Map();
        fullData.itinerary.forEach((day, index) => {
            const hotelName = day.hotel_name || day.hotel || day.hotelName;
            if (hotelName && hotelName.trim() !== '' && hotelName !== '-') {
                if (!hotelsMap.has(hotelName)) {
                    hotelsMap.set(hotelName, {
                        name: hotelName,
                        stars: day.hotel_star_rating || day.star_rating || '',
                        roomType: day.room_type || day.roomType || '',
                        days: [day.day || index + 1]
                    });
                } else {
                    hotelsMap.get(hotelName).days.push(day.day || index + 1);
                }
            }
        });

        if (hotelsMap.size > 0) {
            itineraryHotelsSection.style.display = 'block';
            let hotelsHtml = '';
            hotelsMap.forEach((hotel, name) => {
                const starsDisplay = hotel.stars ? '⭐'.repeat(parseInt(hotel.stars) || 0) : '';
                const daysDisplay = hotel.days.length > 1 
                    ? `Day ${hotel.days[0]}-${hotel.days[hotel.days.length - 1]}` 
                    : `Day ${hotel.days[0]}`;
                hotelsHtml += `
                    <div onclick="selectHotelFromItinerary('${name.replace(/'/g, "\\'")}', '${hotel.roomType.replace(/'/g, "\\'")}', '${daysDisplay}')" 
                         style="background:white;padding:12px 16px;border-radius:8px;border:1px solid #e2e8f0;cursor:pointer;transition:all 0.2s;display:flex;justify-content:space-between;align-items:center;"
                         onmouseover="this.style.borderColor='#6366f1';this.style.boxShadow='0 2px 8px rgba(99,102,241,0.15)';"
                         onmouseout="this.style.borderColor='#e2e8f0';this.style.boxShadow='none';">
                        <div>
                            <div style="font-weight:600;color:#1e293b;">${name} ${starsDisplay}</div>
                            <div style="font-size:12px;color:#64748b;margin-top:2px;">${daysDisplay} ${hotel.roomType ? '• ' + hotel.roomType : ''}</div>
                        </div>
                        <i class="fas fa-plus-circle" style="color:#10b981;font-size:18px;"></i>
                    </div>
                `;
            });
            itineraryHotelsList.innerHTML = hotelsHtml;
        }
    }

    // Initialize multi-hotel system
    initBookingHotels(booking, fullData);

    // Initialize guide system
    initBookingGuides(booking, fullData);

    // Initialize transport system
    initBookingTransports(booking, fullData);

    // Initialize restaurant system
    initBookingRestaurants(booking, fullData);

    // Initialize admission system
    initBookingAdmissions(booking, fullData);

    // Pricing Summary
    const netTotalEl = document.getElementById('netTotal');
    const sellingPriceEl = document.getElementById('sellingPrice');
    const profitEl = document.getElementById('profit');
    
    const netTotal = parseFloat(fullData.net_total || fullData.total_net || 0);
    const sellingPrice = parseFloat(fullData.selling_price || fullData.total_selling || 0);
    const profit = sellingPrice - netTotal;
    
    if (netTotalEl) netTotalEl.textContent = '$' + netTotal.toLocaleString('en-US', { minimumFractionDigits: 2 });
    if (sellingPriceEl) sellingPriceEl.textContent = '$' + sellingPrice.toLocaleString('en-US', { minimumFractionDigits: 2 });
    if (profitEl) profitEl.textContent = '$' + profit.toLocaleString('en-US', { minimumFractionDigits: 2 });
    
    // Itinerary / Services
    const itineraryContainer = document.getElementById('itineraryContainer');
    if (itineraryContainer && fullData.itinerary && fullData.itinerary.length > 0) {
        let html = '<div style="display:grid;gap:12px;">';
        fullData.itinerary.forEach((day, index) => {
            html += `
                <div style="background:#f8fafc;padding:16px;border-radius:8px;border-left:4px solid #3b82f6;">
                    <div style="font-weight:600;color:#1e293b;margin-bottom:8px;">
                        Day ${day.day || index + 1}: ${day.title || day.location || 'Activities'}
                    </div>
                    <div style="color:#64748b;font-size:14px;">${day.description || day.activities || '-'}</div>
                </div>
            `;
        });
        html += '</div>';
        itineraryContainer.innerHTML = html;
    } else if (itineraryContainer && fullData.services && fullData.services.length > 0) {
        let html = '<div style="display:grid;gap:12px;">';
        fullData.services.forEach((service) => {
            html += `
                <div style="background:#f8fafc;padding:16px;border-radius:8px;border-left:4px solid #f59e0b;">
                    <div style="font-weight:600;color:#1e293b;margin-bottom:8px;">
                        ${service.service_type || service.type || 'Service'}
                    </div>
                    <div style="color:#64748b;font-size:14px;">${service.description || service.details || '-'}</div>
                </div>
            `;
        });
        html += '</div>';
        itineraryContainer.innerHTML = html;
    }
    
    // Highlight current status button
    highlightCurrentStatusButton(booking.status || 'confirmed');

    // Load booking notes
    const bookingNotesEl = document.getElementById('bookingNotes');
    if (bookingNotesEl) {
        bookingNotesEl.value = booking.booking_notes || '';
    }

    // Initialize hotel workflow section
    initHotelWorkflow(booking);
}

// ==========================================
// Hotel Workflow Functions (Sales ↔ Operation)
// ==========================================

function initHotelWorkflow(booking) {
    // Set hotel request status
    const statusSelect = document.getElementById('hotelRequestStatus');
    if (statusSelect && booking.hotel_request_status) {
        statusSelect.value = booking.hotel_request_status;
    }
    updateHotelStatusBadge();

    // Set special requests
    const specialRequestsEl = document.getElementById('hotelSpecialRequests');
    if (specialRequestsEl) {
        specialRequestsEl.value = booking.hotel_special_requests || '';
    }

    // Load messages
    loadHotelMessages(booking);
}

function updateHotelStatusBadge() {
    const statusSelect = document.getElementById('hotelRequestStatus');
    const badge = document.getElementById('hotelStatusBadge');
    if (!statusSelect || !badge) return;

    const statusConfig = {
        'draft': { bg: '#f1f5f9', color: '#64748b', icon: 'fa-circle', text: 'Draft - Not sent' },
        'sent': { bg: '#dbeafe', color: '#1d4ed8', icon: 'fa-paper-plane', text: 'Sent to Operation' },
        'waiting': { bg: '#fef3c7', color: '#92400e', icon: 'fa-clock', text: 'Waiting for Hotel Confirmation' },
        'confirmed': { bg: '#dcfce7', color: '#166534', icon: 'fa-check-circle', text: 'Hotel Confirmed' },
        'not_available': { bg: '#fee2e2', color: '#991b1b', icon: 'fa-times-circle', text: 'Not Available - Need Alternative' },
        'alternative': { bg: '#e0e7ff', color: '#4338ca', icon: 'fa-sync-alt', text: 'Alternative Hotel Offered' }
    };

    const config = statusConfig[statusSelect.value] || statusConfig['draft'];
    badge.style.background = config.bg;
    badge.style.color = config.color;
    badge.innerHTML = `<i class="fas ${config.icon}" style="font-size:8px;"></i><span>${config.text}</span>`;
}

function loadHotelMessages(booking) {
    const container = document.getElementById('hotelMessages');
    if (!container) return;

    const messages = booking.hotel_messages || [];
    
    if (messages.length === 0) {
        container.innerHTML = '<div style="color:#a16207;font-size:13px;text-align:center;padding:12px;">No messages yet</div>';
        return;
    }

    let html = '';
    messages.forEach(msg => {
        const isOperation = msg.from === 'operation';
        const align = isOperation ? 'flex-start' : 'flex-end';
        const bg = isOperation ? '#fef3c7' : '#dbeafe';
        const border = isOperation ? '#fde68a' : '#bfdbfe';
        const label = isOperation ? '🔧 Operation' : '💼 Sales';
        
        html += `
            <div style="display:flex;justify-content:${align};margin-bottom:8px;">
                <div style="max-width:80%;background:${bg};border:1px solid ${border};border-radius:8px;padding:8px 12px;">
                    <div style="font-size:11px;color:#64748b;margin-bottom:4px;">${label} • ${msg.time || 'Just now'}</div>
                    <div style="font-size:13px;color:#1e293b;">${msg.text}</div>
                </div>
            </div>
        `;
    });
    container.innerHTML = html;
    container.scrollTop = container.scrollHeight;
}

function sendHotelMessage() {
    const input = document.getElementById('hotelMessageInput');
    if (!input || !input.value.trim()) return;

    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) return;

    const booking = JSON.parse(bookingData);
    if (!booking.hotel_messages) booking.hotel_messages = [];

    const now = new Date();
    const timeStr = now.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

    booking.hotel_messages.push({
        from: 'sales',
        text: input.value.trim(),
        time: timeStr,
        timestamp: now.toISOString()
    });

    // Save to localStorage
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    updateBookingInList(booking);

    // Reload messages and clear input
    loadHotelMessages(booking);
    input.value = '';

    showNotification('Message sent to Operation', 'success');
}

// Global current booking reference
let currentBooking = null;

// Global hotels array for multi-hotel support
let bookingHotels = [];

// ============================================
// HOTEL DIRECTORY - Autocomplete System
// ============================================
let hotelDirectory = [];

// Load hotel directory from localStorage or initialize with sample data
function loadHotelDirectory() {
    const saved = localStorage.getItem('hotelDirectory');
    if (saved) {
        hotelDirectory = JSON.parse(saved);
    } else {
        // Initialize with sample Thailand hotels
        hotelDirectory = [
            { id: 1, name: 'Anantara Siam Bangkok Hotel', tel: '+66 2 126 8866', address: '155 Rajadamri Road, Pathumwan', postal_code: '10330', city: 'Bangkok', country: 'Thailand', star_rating: 5 },
            { id: 2, name: 'Mandarin Oriental Bangkok', tel: '+66 2 659 9000', address: '48 Oriental Avenue', postal_code: '10500', city: 'Bangkok', country: 'Thailand', star_rating: 5 },
            { id: 3, name: 'The Peninsula Bangkok', tel: '+66 2 020 2888', address: '333 Charoennakorn Road, Klongsan', postal_code: '10600', city: 'Bangkok', country: 'Thailand', star_rating: 5 },
            { id: 4, name: 'Centara Grand Beach Resort Phuket', tel: '+66 76 201 234', address: '683 Patak Road, Karon Beach', postal_code: '83100', city: 'Phuket', country: 'Thailand', star_rating: 5 },
            { id: 5, name: 'Amari Phuket', tel: '+66 76 340 106', address: '2 Meun-Ngern Road, Patong Beach', postal_code: '83150', city: 'Phuket', country: 'Thailand', star_rating: 4 },
            { id: 6, name: 'Le Meridien Chiang Mai', tel: '+66 52 253 666', address: '108 Chang Klan Road', postal_code: '50100', city: 'Chiang Mai', country: 'Thailand', star_rating: 5 },
            { id: 7, name: 'Anantara Chiang Mai Resort', tel: '+66 53 253 333', address: '123-123/1 Charoen Prathet Road', postal_code: '50100', city: 'Chiang Mai', country: 'Thailand', star_rating: 5 },
            { id: 8, name: 'Dusit Thani Pattaya', tel: '+66 38 425 611', address: '240/2 Pattaya Beach Road', postal_code: '20150', city: 'Pattaya', country: 'Thailand', star_rating: 5 },
            { id: 9, name: 'Hilton Pattaya', tel: '+66 38 253 000', address: '333/101 Moo 9, Pattaya Beach Road', postal_code: '20150', city: 'Pattaya', country: 'Thailand', star_rating: 5 },
            { id: 10, name: 'Centara Grand Mirage Beach Resort', tel: '+66 38 301 234', address: '277 Moo 5, Naklua, Banglamung', postal_code: '20150', city: 'Pattaya', country: 'Thailand', star_rating: 5 }
        ];
        saveHotelDirectory();
    }
}

// Save hotel directory to localStorage
function saveHotelDirectory() {
    localStorage.setItem('hotelDirectory', JSON.stringify(hotelDirectory));
}

// Search hotels in directory
function searchHotelDirectory(query) {
    if (!query || query.length < 2) return [];
    const q = query.toLowerCase();
    return hotelDirectory.filter(h => 
        h.name.toLowerCase().includes(q) || 
        h.city.toLowerCase().includes(q) ||
        h.address.toLowerCase().includes(q)
    ).slice(0, 10); // Max 10 suggestions
}

// Add new hotel to directory
function addHotelToDirectory(hotel) {
    const newId = hotelDirectory.length > 0 ? Math.max(...hotelDirectory.map(h => h.id)) + 1 : 1;
    const newHotel = {
        id: newId,
        name: hotel.name || '',
        tel: hotel.tel || '',
        address: hotel.address || '',
        postal_code: hotel.postal_code || '',
        city: hotel.city || '',
        country: hotel.country || 'Thailand',
        star_rating: hotel.star_rating || 0
    };
    hotelDirectory.push(newHotel);
    saveHotelDirectory();
    return newHotel;
}

// Show autocomplete dropdown
function showHotelAutocomplete(inputId, hotelId) {
    const input = document.getElementById(inputId);
    if (!input) return;

    const query = input.value;
    const results = searchHotelDirectory(query);
    
    // Remove existing dropdown
    const existingDropdown = document.getElementById(`autocomplete_${hotelId}`);
    if (existingDropdown) existingDropdown.remove();

    if (results.length === 0) {
        // Show "Add to directory" option if query is long enough
        if (query.length >= 3) {
            const dropdown = createAutocompleteDropdown(hotelId, input, [{
                isNew: true,
                name: `➕ Add "${query}" to directory...`
            }]);
            input.parentNode.appendChild(dropdown);
        }
        return;
    }

    const dropdown = createAutocompleteDropdown(hotelId, input, results);
    input.parentNode.appendChild(dropdown);
}

// Create autocomplete dropdown element
function createAutocompleteDropdown(hotelId, input, results) {
    const dropdown = document.createElement('div');
    dropdown.id = `autocomplete_${hotelId}`;
    dropdown.style.cssText = `
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 1px solid #e2e8f0;
        border-top: none;
        border-radius: 0 0 8px 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        max-height: 250px;
        overflow-y: auto;
        z-index: 1000;
    `;

    results.forEach(hotel => {
        const item = document.createElement('div');
        item.style.cssText = `
            padding: 10px 12px;
            cursor: pointer;
            border-bottom: 1px solid #f1f5f9;
            transition: background 0.15s;
        `;
        
        if (hotel.isNew) {
            item.innerHTML = `<span style="color:#10b981;font-weight:500;">${hotel.name}</span>`;
            item.onclick = () => {
                hideHotelAutocomplete(hotelId);
                showAddHotelDialog(hotelId, input.value);
            };
        } else {
            const stars = '⭐'.repeat(hotel.star_rating || 0);
            item.innerHTML = `
                <div style="font-weight:500;color:#1e293b;">${hotel.name} ${stars}</div>
                <div style="font-size:12px;color:#64748b;margin-top:2px;">
                    <i class="fas fa-map-marker-alt" style="margin-right:4px;"></i>${hotel.city} • ${hotel.postal_code}
                </div>
            `;
            item.onclick = () => selectHotelFromDirectory(hotelId, hotel);
        }
        
        item.onmouseover = () => item.style.background = '#f8fafc';
        item.onmouseout = () => item.style.background = 'white';
        dropdown.appendChild(item);
    });

    return dropdown;
}

// Hide autocomplete dropdown
function hideHotelAutocomplete(hotelId) {
    const dropdown = document.getElementById(`autocomplete_${hotelId}`);
    if (dropdown) dropdown.remove();
}

// Select hotel from directory and fill fields
function selectHotelFromDirectory(hotelId, directoryHotel) {
    const hotel = bookingHotels.find(h => h.id === hotelId);
    if (!hotel) return;

    // Update hotel object
    hotel.name = directoryHotel.name;
    hotel.tel = directoryHotel.tel;
    hotel.address = `${directoryHotel.address}, ${directoryHotel.postal_code}`;
    hotel.directory_id = directoryHotel.id;

    // Update form fields
    const nameInput = document.getElementById(`hotel_name_${hotelId}`);
    const telInput = document.getElementById(`hotel_tel_${hotelId}`);
    const addressInput = document.getElementById(`hotel_address_${hotelId}`);

    if (nameInput) nameInput.value = hotel.name;
    if (telInput) telInput.value = hotel.tel;
    if (addressInput) addressInput.value = hotel.address;

    hideHotelAutocomplete(hotelId);
    showNotification(`Hotel "${directoryHotel.name}" selected with contact info`, 'success');
}

// Show dialog to add new hotel to directory
function showAddHotelDialog(hotelId, hotelName) {
    const modal = document.createElement('div');
    modal.id = 'addHotelModal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;padding:24px;width:450px;max-width:90%;box-shadow:0 20px 40px rgba(0,0,0,0.2);">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                <h3 style="margin:0;color:#1e293b;display:flex;align-items:center;gap:8px;">
                    <i class="fas fa-plus-circle" style="color:#10b981;"></i> Add Hotel to Directory
                </h3>
                <button onclick="document.getElementById('addHotelModal').remove()" style="border:none;background:none;cursor:pointer;font-size:20px;color:#94a3b8;">&times;</button>
            </div>
            <div style="display:grid;gap:16px;">
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Hotel Name *</label>
                    <input type="text" id="newHotelName" value="${hotelName}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">City</label>
                        <input type="text" id="newHotelCity" placeholder="e.g., Bangkok" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Star Rating</label>
                        <select id="newHotelStars" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                            <option value="0">No rating</option>
                            <option value="3">⭐⭐⭐ 3 Star</option>
                            <option value="4">⭐⭐⭐⭐ 4 Star</option>
                            <option value="5" selected>⭐⭐⭐⭐⭐ 5 Star</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Telephone</label>
                    <input type="text" id="newHotelTel" placeholder="+66 2 xxx xxxx" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                </div>
                <div style="display:grid;grid-template-columns:2fr 1fr;gap:12px;">
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Address</label>
                        <input type="text" id="newHotelAddress" placeholder="Street address" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Postal Code</label>
                        <input type="text" id="newHotelPostal" placeholder="e.g., 10330" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
                <button onclick="document.getElementById('addHotelModal').remove()" style="padding:10px 20px;background:#f1f5f9;color:#64748b;border:none;border-radius:6px;cursor:pointer;font-weight:500;">
                    Cancel
                </button>
                <button onclick="saveNewHotelToDirectory('${hotelId}')" style="padding:10px 20px;background:#10b981;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:500;display:flex;align-items:center;gap:6px;">
                    <i class="fas fa-save"></i> Save to Directory
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.getElementById('newHotelName').focus();
}

// Save new hotel to directory and select it
function saveNewHotelToDirectory(hotelId) {
    const name = document.getElementById('newHotelName')?.value.trim();
    const city = document.getElementById('newHotelCity')?.value.trim();
    const tel = document.getElementById('newHotelTel')?.value.trim();
    const address = document.getElementById('newHotelAddress')?.value.trim();
    const postal = document.getElementById('newHotelPostal')?.value.trim();
    const stars = parseInt(document.getElementById('newHotelStars')?.value) || 0;

    if (!name) {
        showNotification('Hotel name is required', 'error');
        return;
    }

    const newHotel = addHotelToDirectory({
        name: name,
        city: city || '',
        tel: tel || '',
        address: address || '',
        postal_code: postal || '',
        star_rating: stars
    });

    // Close modal
    document.getElementById('addHotelModal')?.remove();

    // Select this hotel for the booking
    selectHotelFromDirectory(hotelId, newHotel);
    
    showNotification(`"${name}" added to hotel directory!`, 'success');
}

// Show hotel directory manager
function showHotelDirectoryManager() {
    const modal = document.createElement('div');
    modal.id = 'hotelDirectoryModal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;

    let hotelsHtml = hotelDirectory.map((h, idx) => `
        <tr style="border-bottom:1px solid #f1f5f9;">
            <td style="padding:12px 8px;font-weight:500;">${h.name} ${'⭐'.repeat(h.star_rating || 0)}</td>
            <td style="padding:12px 8px;color:#64748b;">${h.city || '-'}</td>
            <td style="padding:12px 8px;color:#64748b;">${h.tel || '-'}</td>
            <td style="padding:12px 8px;color:#64748b;font-size:12px;">${h.address || '-'}, ${h.postal_code || ''}</td>
            <td style="padding:12px 8px;text-align:center;">
                <button onclick="editHotelInDirectory(${h.id})" style="padding:4px 8px;background:#f1f5f9;border:none;border-radius:4px;cursor:pointer;margin-right:4px;" title="Edit">
                    <i class="fas fa-edit" style="color:#3b82f6;"></i>
                </button>
                <button onclick="deleteHotelFromDirectory(${h.id})" style="padding:4px 8px;background:#fee2e2;border:none;border-radius:4px;cursor:pointer;" title="Delete">
                    <i class="fas fa-trash" style="color:#dc2626;"></i>
                </button>
            </td>
        </tr>
    `).join('');

    modal.innerHTML = `
        <div style="background:white;border-radius:12px;width:900px;max-width:95%;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 40px rgba(0,0,0,0.2);">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid #e2e8f0;">
                <h3 style="margin:0;color:#1e293b;display:flex;align-items:center;gap:10px;">
                    <i class="fas fa-book" style="color:#6366f1;"></i> Hotel Directory
                    <span style="background:#e0e7ff;color:#4f46e5;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600;">${hotelDirectory.length} Hotels</span>
                </h3>
                <div style="display:flex;gap:12px;align-items:center;">
                    <button onclick="addHotelToDirectoryPrompt()" style="padding:8px 16px;background:#10b981;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:500;display:flex;align-items:center;gap:6px;">
                        <i class="fas fa-plus"></i> Add Hotel
                    </button>
                    <button onclick="document.getElementById('hotelDirectoryModal').remove()" style="border:none;background:none;cursor:pointer;font-size:24px;color:#94a3b8;line-height:1;">&times;</button>
                </div>
            </div>
            <div style="padding:16px 24px;border-bottom:1px solid #e2e8f0;background:#f8fafc;">
                <input type="text" id="directorySearchInput" placeholder="🔍 Search hotels..." 
                       oninput="filterHotelDirectory(this.value)"
                       style="width:100%;padding:10px 16px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;">
            </div>
            <div style="flex:1;overflow-y:auto;padding:0;">
                <table id="hotelDirectoryTable" style="width:100%;border-collapse:collapse;">
                    <thead>
                        <tr style="background:#f8fafc;position:sticky;top:0;">
                            <th style="padding:12px 8px;text-align:left;font-weight:600;color:#64748b;font-size:12px;text-transform:uppercase;">Hotel Name</th>
                            <th style="padding:12px 8px;text-align:left;font-weight:600;color:#64748b;font-size:12px;text-transform:uppercase;">City</th>
                            <th style="padding:12px 8px;text-align:left;font-weight:600;color:#64748b;font-size:12px;text-transform:uppercase;">Tel</th>
                            <th style="padding:12px 8px;text-align:left;font-weight:600;color:#64748b;font-size:12px;text-transform:uppercase;">Address</th>
                            <th style="padding:12px 8px;text-align:center;font-weight:600;color:#64748b;font-size:12px;text-transform:uppercase;width:100px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="hotelDirectoryBody">
                        ${hotelsHtml || '<tr><td colspan="5" style="padding:40px;text-align:center;color:#94a3b8;">No hotels in directory</td></tr>'}
                    </tbody>
                </table>
            </div>
            <div style="padding:16px 24px;border-top:1px solid #e2e8f0;background:#f8fafc;display:flex;justify-content:space-between;align-items:center;">
                <span style="color:#64748b;font-size:13px;">💡 Hotels are saved locally. Add new hotels when typing in the booking form.</span>
                <button onclick="document.getElementById('hotelDirectoryModal').remove()" style="padding:10px 20px;background:#f1f5f9;color:#64748b;border:none;border-radius:6px;cursor:pointer;font-weight:500;">
                    Close
                </button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
}

// Filter hotel directory table
function filterHotelDirectory(query) {
    const tbody = document.getElementById('hotelDirectoryBody');
    if (!tbody) return;

    const q = query.toLowerCase();
    const filtered = hotelDirectory.filter(h => 
        h.name.toLowerCase().includes(q) || 
        (h.city && h.city.toLowerCase().includes(q)) ||
        (h.address && h.address.toLowerCase().includes(q))
    );

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="padding:40px;text-align:center;color:#94a3b8;">No hotels found</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(h => `
        <tr style="border-bottom:1px solid #f1f5f9;">
            <td style="padding:12px 8px;font-weight:500;">${h.name} ${'⭐'.repeat(h.star_rating || 0)}</td>
            <td style="padding:12px 8px;color:#64748b;">${h.city || '-'}</td>
            <td style="padding:12px 8px;color:#64748b;">${h.tel || '-'}</td>
            <td style="padding:12px 8px;color:#64748b;font-size:12px;">${h.address || '-'}, ${h.postal_code || ''}</td>
            <td style="padding:12px 8px;text-align:center;">
                <button onclick="editHotelInDirectory(${h.id})" style="padding:4px 8px;background:#f1f5f9;border:none;border-radius:4px;cursor:pointer;margin-right:4px;" title="Edit">
                    <i class="fas fa-edit" style="color:#3b82f6;"></i>
                </button>
                <button onclick="deleteHotelFromDirectory(${h.id})" style="padding:4px 8px;background:#fee2e2;border:none;border-radius:4px;cursor:pointer;" title="Delete">
                    <i class="fas fa-trash" style="color:#dc2626;"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Add hotel to directory via prompt (from directory manager)
function addHotelToDirectoryPrompt() {
    document.getElementById('hotelDirectoryModal')?.remove();
    showAddHotelDialog('', '');
}

// Edit hotel in directory
function editHotelInDirectory(hotelId) {
    const hotel = hotelDirectory.find(h => h.id === hotelId);
    if (!hotel) return;

    document.getElementById('hotelDirectoryModal')?.remove();

    const modal = document.createElement('div');
    modal.id = 'editHotelModal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;padding:24px;width:450px;max-width:90%;box-shadow:0 20px 40px rgba(0,0,0,0.2);">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                <h3 style="margin:0;color:#1e293b;display:flex;align-items:center;gap:8px;">
                    <i class="fas fa-edit" style="color:#3b82f6;"></i> Edit Hotel
                </h3>
                <button onclick="document.getElementById('editHotelModal').remove(); showHotelDirectoryManager();" style="border:none;background:none;cursor:pointer;font-size:20px;color:#94a3b8;">&times;</button>
            </div>
            <div style="display:grid;gap:16px;">
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Hotel Name *</label>
                    <input type="text" id="editHotelName" value="${hotel.name}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">City</label>
                        <input type="text" id="editHotelCity" value="${hotel.city || ''}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Star Rating</label>
                        <select id="editHotelStars" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                            <option value="0" ${hotel.star_rating === 0 ? 'selected' : ''}>No rating</option>
                            <option value="3" ${hotel.star_rating === 3 ? 'selected' : ''}>⭐⭐⭐ 3 Star</option>
                            <option value="4" ${hotel.star_rating === 4 ? 'selected' : ''}>⭐⭐⭐⭐ 4 Star</option>
                            <option value="5" ${hotel.star_rating === 5 ? 'selected' : ''}>⭐⭐⭐⭐⭐ 5 Star</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Telephone</label>
                    <input type="text" id="editHotelTel" value="${hotel.tel || ''}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                </div>
                <div style="display:grid;grid-template-columns:2fr 1fr;gap:12px;">
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Address</label>
                        <input type="text" id="editHotelAddress" value="${hotel.address || ''}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Postal Code</label>
                        <input type="text" id="editHotelPostal" value="${hotel.postal_code || ''}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
                <button onclick="document.getElementById('editHotelModal').remove(); showHotelDirectoryManager();" style="padding:10px 20px;background:#f1f5f9;color:#64748b;border:none;border-radius:6px;cursor:pointer;font-weight:500;">
                    Cancel
                </button>
                <button onclick="saveEditedHotel(${hotel.id})" style="padding:10px 20px;background:#3b82f6;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:500;display:flex;align-items:center;gap:6px;">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Save edited hotel
function saveEditedHotel(hotelId) {
    const hotel = hotelDirectory.find(h => h.id === hotelId);
    if (!hotel) return;

    hotel.name = document.getElementById('editHotelName')?.value.trim() || hotel.name;
    hotel.city = document.getElementById('editHotelCity')?.value.trim() || '';
    hotel.tel = document.getElementById('editHotelTel')?.value.trim() || '';
    hotel.address = document.getElementById('editHotelAddress')?.value.trim() || '';
    hotel.postal_code = document.getElementById('editHotelPostal')?.value.trim() || '';
    hotel.star_rating = parseInt(document.getElementById('editHotelStars')?.value) || 0;

    saveHotelDirectory();

    document.getElementById('editHotelModal')?.remove();
    showHotelDirectoryManager();
    showNotification('Hotel updated!', 'success');
}

// Delete hotel from directory
function deleteHotelFromDirectory(hotelId) {
    const hotel = hotelDirectory.find(h => h.id === hotelId);
    if (!hotel) return;

    if (confirm(`Delete "${hotel.name}" from the directory?`)) {
        hotelDirectory = hotelDirectory.filter(h => h.id !== hotelId);
        saveHotelDirectory();
        
        // Refresh the table
        filterHotelDirectory(document.getElementById('directorySearchInput')?.value || '');
        showNotification('Hotel deleted from directory', 'info');
    }
}

// Initialize hotel directory on load
loadHotelDirectory();

// ============================================
// GUIDE SECTION - Multi-Guide Support
// ============================================
let bookingGuides = [];
let guideDirectory = [];
let currentBookingTravelDates = { startDate: '', endDate: '' };

// Load guide directory from localStorage
function loadGuideDirectory() {
    const saved = localStorage.getItem('guideDirectory');
    if (saved) {
        guideDirectory = JSON.parse(saved);
    } else {
        // Initialize with sample guides
        guideDirectory = [
            { id: 1, name: 'Somchai Thongdee', phone: '+66 81 234 5678', languages: ['Thai', 'English'], license: 'TG-001234', rating: 5 },
            { id: 2, name: 'Nattaya Srisawat', phone: '+66 89 876 5432', languages: ['Thai', 'English', 'Chinese'], license: 'TG-002345', rating: 5 },
            { id: 3, name: 'Prasert Wongchai', phone: '+66 86 111 2222', languages: ['Thai', 'English', 'Japanese'], license: 'TG-003456', rating: 4 },
            { id: 4, name: 'Kannika Chantara', phone: '+66 82 333 4444', languages: ['Thai', 'English', 'Korean'], license: 'TG-004567', rating: 5 },
            { id: 5, name: 'Wichai Sanitwong', phone: '+66 83 555 6666', languages: ['Thai', 'English', 'French'], license: 'TG-005678', rating: 4 }
        ];
        saveGuideDirectory();
    }
}

// Save guide directory
function saveGuideDirectory() {
    localStorage.setItem('guideDirectory', JSON.stringify(guideDirectory));
}

// Generate unique guide ID
function generateGuideId() {
    return 'guide_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// Add new empty guide
function addNewGuide() {
    const guide = {
        id: generateGuideId(),
        name: '',
        phone: '',
        languages: [],
        startDate: currentBookingTravelDates.startDate || '',
        endDate: currentBookingTravelDates.endDate || '',
        notes: ''
    };

    bookingGuides.push(guide);
    renderGuidesContainer();
    
    // Focus on the new guide name input
    setTimeout(() => {
        const input = document.getElementById(`guide_name_${guide.id}`);
        if (input) input.focus();
    }, 100);
}

// Remove guide from list
function removeGuide(guideId) {
    const guide = bookingGuides.find(g => g.id === guideId);
    if (guide && confirm(`Remove "${guide.name || 'this guide'}" from the booking?`)) {
        bookingGuides = bookingGuides.filter(g => g.id !== guideId);
        renderGuidesContainer();
        showNotification('Guide removed', 'info');
    }
}

// Update guide field
function updateGuideField(guideId, field, value) {
    const guide = bookingGuides.find(g => g.id === guideId);
    if (guide) {
        guide[field] = value;
    }
}

// Search guides in directory
function searchGuideDirectory(query) {
    if (!query || query.length < 2) return [];
    const q = query.toLowerCase();
    return guideDirectory.filter(g => 
        g.name.toLowerCase().includes(q) || 
        (g.languages && g.languages.some(l => l.toLowerCase().includes(q)))
    ).slice(0, 8);
}

// Show guide autocomplete
function showGuideAutocomplete(inputId, guideId) {
    const input = document.getElementById(inputId);
    if (!input) return;

    const query = input.value;
    const results = searchGuideDirectory(query);
    
    // Remove existing dropdown
    const existingDropdown = document.getElementById(`guide_autocomplete_${guideId}`);
    if (existingDropdown) existingDropdown.remove();

    if (results.length === 0) {
        if (query.length >= 3) {
            const dropdown = createGuideAutocompleteDropdown(guideId, input, [{
                isNew: true,
                name: `➕ Add "${query}" to directory...`
            }]);
            input.parentNode.appendChild(dropdown);
        }
        return;
    }

    const dropdown = createGuideAutocompleteDropdown(guideId, input, results);
    input.parentNode.appendChild(dropdown);
}

// Create guide autocomplete dropdown
function createGuideAutocompleteDropdown(guideId, input, results) {
    const dropdown = document.createElement('div');
    dropdown.id = `guide_autocomplete_${guideId}`;
    dropdown.style.cssText = `
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 1px solid #e2e8f0;
        border-top: none;
        border-radius: 0 0 8px 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        max-height: 250px;
        overflow-y: auto;
        z-index: 1000;
    `;

    results.forEach(guide => {
        const item = document.createElement('div');
        item.style.cssText = `
            padding: 10px 12px;
            cursor: pointer;
            border-bottom: 1px solid #f1f5f9;
            transition: background 0.15s;
        `;
        
        if (guide.isNew) {
            item.innerHTML = `<span style="color:#0ea5e9;font-weight:500;">${guide.name}</span>`;
            item.onclick = () => {
                hideGuideAutocomplete(guideId);
                showAddGuideDialog(guideId, input.value);
            };
        } else {
            const langDisplay = guide.languages ? guide.languages.join(', ') : '';
            const stars = '⭐'.repeat(guide.rating || 0);
            item.innerHTML = `
                <div style="font-weight:500;color:#1e293b;">${guide.name} ${stars}</div>
                <div style="font-size:12px;color:#64748b;margin-top:2px;">
                    <i class="fas fa-phone" style="margin-right:4px;"></i>${guide.phone} 
                    <span style="margin-left:8px;"><i class="fas fa-language" style="margin-right:4px;"></i>${langDisplay}</span>
                </div>
            `;
            item.onclick = () => selectGuideFromDirectory(guideId, guide);
        }
        
        item.onmouseover = () => item.style.background = '#f0f9ff';
        item.onmouseout = () => item.style.background = 'white';
        dropdown.appendChild(item);
    });

    return dropdown;
}

// Hide guide autocomplete
function hideGuideAutocomplete(guideId) {
    const dropdown = document.getElementById(`guide_autocomplete_${guideId}`);
    if (dropdown) dropdown.remove();
}

// Select guide from directory
function selectGuideFromDirectory(guideId, directoryGuide) {
    const guide = bookingGuides.find(g => g.id === guideId);
    if (!guide) return;

    guide.name = directoryGuide.name;
    guide.phone = directoryGuide.phone;
    guide.languages = directoryGuide.languages || [];
    guide.directory_id = directoryGuide.id;

    // Update form fields
    const nameInput = document.getElementById(`guide_name_${guideId}`);
    const phoneInput = document.getElementById(`guide_phone_${guideId}`);
    const langInput = document.getElementById(`guide_languages_${guideId}`);

    if (nameInput) nameInput.value = guide.name;
    if (phoneInput) phoneInput.value = guide.phone;
    if (langInput) langInput.value = guide.languages.join(', ');

    hideGuideAutocomplete(guideId);
    showNotification(`Guide "${directoryGuide.name}" selected`, 'success');
}

// Show add guide dialog
function showAddGuideDialog(guideId, guideName) {
    const modal = document.createElement('div');
    modal.id = 'addGuideModal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;padding:24px;width:450px;max-width:90%;box-shadow:0 20px 40px rgba(0,0,0,0.2);">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                <h3 style="margin:0;color:#1e293b;display:flex;align-items:center;gap:8px;">
                    <i class="fas fa-user-plus" style="color:#0ea5e9;"></i> Add Guide to Directory
                </h3>
                <button onclick="document.getElementById('addGuideModal').remove()" style="border:none;background:none;cursor:pointer;font-size:20px;color:#94a3b8;">&times;</button>
            </div>
            <div style="display:grid;gap:16px;">
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Guide Name *</label>
                    <input type="text" id="newGuideName" value="${guideName || ''}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Phone Number</label>
                        <input type="text" id="newGuidePhone" placeholder="+66 8x xxx xxxx" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">License No.</label>
                        <input type="text" id="newGuideLicense" placeholder="TG-XXXXXX" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                </div>
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Languages (comma separated)</label>
                    <input type="text" id="newGuideLanguages" placeholder="Thai, English, Chinese" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                </div>
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Rating</label>
                    <select id="newGuideRating" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                        <option value="3">⭐⭐⭐ Good</option>
                        <option value="4">⭐⭐⭐⭐ Very Good</option>
                        <option value="5" selected>⭐⭐⭐⭐⭐ Excellent</option>
                    </select>
                </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
                <button onclick="document.getElementById('addGuideModal').remove()" style="padding:10px 20px;background:#f1f5f9;color:#64748b;border:none;border-radius:6px;cursor:pointer;font-weight:500;">
                    Cancel
                </button>
                <button onclick="saveNewGuideToDirectory('${guideId}')" style="padding:10px 20px;background:#0ea5e9;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:500;display:flex;align-items:center;gap:6px;">
                    <i class="fas fa-save"></i> Save to Directory
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.getElementById('newGuideName').focus();
}

// Save new guide to directory
function saveNewGuideToDirectory(guideId) {
    const name = document.getElementById('newGuideName')?.value.trim();
    const phone = document.getElementById('newGuidePhone')?.value.trim();
    const license = document.getElementById('newGuideLicense')?.value.trim();
    const languagesStr = document.getElementById('newGuideLanguages')?.value.trim();
    const rating = parseInt(document.getElementById('newGuideRating')?.value) || 5;

    if (!name) {
        showNotification('Guide name is required', 'error');
        return;
    }

    const languages = languagesStr ? languagesStr.split(',').map(l => l.trim()).filter(l => l) : [];

    const newId = guideDirectory.length > 0 ? Math.max(...guideDirectory.map(g => g.id)) + 1 : 1;
    const newGuide = {
        id: newId,
        name: name,
        phone: phone || '',
        license: license || '',
        languages: languages,
        rating: rating
    };

    guideDirectory.push(newGuide);
    saveGuideDirectory();

    document.getElementById('addGuideModal')?.remove();

    if (guideId) {
        selectGuideFromDirectory(guideId, newGuide);
    }
    
    showNotification(`"${name}" added to guide directory!`, 'success');
}

// Render guides container
function renderGuidesContainer() {
    // Try both container IDs - booking-confirmation uses 'guidesContainer', operation-arrangement uses 'opGuidesContainer'
    let container = document.getElementById('guidesContainer');
    const isOperationPage = !container;
    if (!container) {
        container = document.getElementById('opGuidesContainer');
    }
    const noGuidesMessage = document.getElementById('noGuidesMessage');
    const guideCountEl = document.getElementById('guideCount');
    const opGuideBadge = document.getElementById('opGuideBadge');
    
    if (!container) return;

    if (bookingGuides.length === 0) {
        container.innerHTML = isOperationPage ? `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-user-tie" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No guides assigned yet</p>
            </div>
        ` : '';
        if (noGuidesMessage) noGuidesMessage.style.display = 'block';
        if (guideCountEl) guideCountEl.textContent = '0 Guides';
        if (opGuideBadge) opGuideBadge.textContent = '0';
        return;
    }

    if (noGuidesMessage) noGuidesMessage.style.display = 'none';
    if (guideCountEl) guideCountEl.textContent = `${bookingGuides.length} Guide${bookingGuides.length > 1 ? 's' : ''}`;
    if (opGuideBadge) opGuideBadge.textContent = bookingGuides.length;

    let html = '';
    bookingGuides.forEach((guide, index) => {
        html += `
            <div class="guide-card" style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:12px;padding:20px;position:relative;">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
                    <div style="display:flex;align-items:center;gap:12px;flex:1;">
                        <span style="background:#0ea5e9;color:white;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:14px;">
                            <i class="fas fa-user"></i>
                        </span>
                        <div style="position:relative;flex:1;max-width:300px;">
                            <input type="text" id="guide_name_${guide.id}" value="${guide.name}" 
                                   onchange="updateGuideField('${guide.id}', 'name', this.value)"
                                   oninput="showGuideAutocomplete('guide_name_${guide.id}', '${guide.id}')"
                                   onblur="setTimeout(() => hideGuideAutocomplete('${guide.id}'), 200)"
                                   placeholder="🔍 Type guide name to search..." 
                                   autocomplete="off"
                                   style="font-size:16px;font-weight:600;color:#1e293b;border:1px solid #bae6fd;background:white;outline:none;width:100%;padding:8px 12px;border-radius:8px;">
                            <i class="fas fa-search" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:#94a3b8;pointer-events:none;"></i>
                        </div>
                    </div>
                    <button onclick="removeGuide('${guide.id}')" style="width:28px;height:28px;border:none;background:#fee2e2;color:#dc2626;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;" title="Remove Guide">
                        <i class="fas fa-times"></i>
                    </button>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;">
                    <div>
                        <label style="font-size:11px;color:#0369a1;display:block;margin-bottom:4px;">Phone Number</label>
                        <input type="text" id="guide_phone_${guide.id}" value="${guide.phone || ''}" 
                               onchange="updateGuideField('${guide.id}', 'phone', this.value)"
                               placeholder="+66 8x xxx xxxx" 
                               style="width:100%;padding:8px;border:1px solid #bae6fd;border-radius:6px;font-size:13px;background:white;">
                    </div>
                    <div>
                        <label style="font-size:11px;color:#0369a1;display:block;margin-bottom:4px;">Languages</label>
                        <input type="text" id="guide_languages_${guide.id}" value="${Array.isArray(guide.languages) ? guide.languages.join(', ') : guide.languages || ''}" 
                               onchange="updateGuideField('${guide.id}', 'languages', this.value.split(',').map(l=>l.trim()))"
                               placeholder="Thai, English" 
                               style="width:100%;padding:8px;border:1px solid #bae6fd;border-radius:6px;font-size:13px;background:white;">
                    </div>
                    <div>
                        <label style="font-size:11px;color:#0369a1;display:block;margin-bottom:4px;">Start Date</label>
                        <input type="date" id="guide_startDate_${guide.id}" value="${guide.startDate || ''}" 
                               onchange="updateGuideField('${guide.id}', 'startDate', this.value)"
                               style="width:100%;padding:8px;border:1px solid #bae6fd;border-radius:6px;font-size:13px;background:white;">
                    </div>
                    <div>
                        <label style="font-size:11px;color:#0369a1;display:block;margin-bottom:4px;">End Date</label>
                        <input type="date" id="guide_endDate_${guide.id}" value="${guide.endDate || ''}" 
                               onchange="updateGuideField('${guide.id}', 'endDate', this.value)"
                               style="width:100%;padding:8px;border:1px solid #bae6fd;border-radius:6px;font-size:13px;background:white;">
                    </div>
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

// Initialize guides from booking data
function initBookingGuides(booking, fullData) {
    bookingGuides = [];
    
    // Store travel dates for auto-fill when adding new guides
    const arrivalDate = booking.travel_date || fullData.travel_date || fullData.arrival_date || '';
    const departureDate = booking.end_date || fullData.end_date || fullData.departure_date || '';
    currentBookingTravelDates = {
        startDate: arrivalDate ? new Date(arrivalDate).toISOString().split('T')[0] : '',
        endDate: departureDate ? new Date(departureDate).toISOString().split('T')[0] : ''
    };
    
    if (booking.guides && Array.isArray(booking.guides)) {
        bookingGuides = booking.guides;
    } else if (fullData.guides && Array.isArray(fullData.guides)) {
        bookingGuides = fullData.guides;
    }
    
    renderGuidesContainer();
}

// Save guide assignments
function saveGuideAssignments() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) {
        showNotification('No booking loaded', 'error');
        return;
    }

    const booking = JSON.parse(bookingData);
    booking.guides = bookingGuides;

    if (!booking.full_data) booking.full_data = {};
    booking.full_data.guides = bookingGuides;

    localStorage.setItem('currentBooking', JSON.stringify(booking));
    updateBookingInList(booking);

    // Save to Supabase
    saveGuidesToSupabase(booking);

    showNotification('Guide assignments saved!', 'success');
}

// Save guides to Supabase
async function saveGuidesToSupabase(booking) {
    try {
        const supabaseClient = window.supabaseClient;
        if (!supabaseClient) return;

        const { data, error } = await supabaseClient
            .from('bookings')
            .update({ guides: booking.guides || null })
            .eq('booking_number', booking.booking_id);

        if (error) {
            console.warn('Supabase: failed to update guides:', error.message);
        } else {
            console.log('✅ Supabase guides updated');
        }
    } catch (err) {
        console.error('Error saving guides to Supabase:', err);
    }
}

// Show guide directory manager
function showGuideDirectoryManager() {
    const modal = document.createElement('div');
    modal.id = 'guideDirectoryModal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;

    let guidesHtml = guideDirectory.map(g => `
        <tr style="border-bottom:1px solid #f1f5f9;">
            <td style="padding:12px 8px;font-weight:500;">${g.name} ${'⭐'.repeat(g.rating || 0)}</td>
            <td style="padding:12px 8px;color:#64748b;">${g.phone || '-'}</td>
            <td style="padding:12px 8px;color:#64748b;">${g.languages ? g.languages.join(', ') : '-'}</td>
            <td style="padding:12px 8px;color:#64748b;font-size:12px;">${g.license || '-'}</td>
            <td style="padding:12px 8px;text-align:center;">
                <button onclick="editGuideInDirectory(${g.id})" style="padding:4px 8px;background:#f1f5f9;border:none;border-radius:4px;cursor:pointer;margin-right:4px;" title="Edit">
                    <i class="fas fa-edit" style="color:#3b82f6;"></i>
                </button>
                <button onclick="deleteGuideFromDirectory(${g.id})" style="padding:4px 8px;background:#fee2e2;border:none;border-radius:4px;cursor:pointer;" title="Delete">
                    <i class="fas fa-trash" style="color:#dc2626;"></i>
                </button>
            </td>
        </tr>
    `).join('');

    modal.innerHTML = `
        <div style="background:white;border-radius:12px;width:800px;max-width:95%;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 40px rgba(0,0,0,0.2);">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid #e2e8f0;">
                <h3 style="margin:0;color:#1e293b;display:flex;align-items:center;gap:10px;">
                    <i class="fas fa-address-book" style="color:#0ea5e9;"></i> Guide Directory
                    <span style="background:#e0f2fe;color:#0284c7;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600;">${guideDirectory.length} Guides</span>
                </h3>
                <div style="display:flex;gap:12px;align-items:center;">
                    <button onclick="addGuideToDirectoryPrompt()" style="padding:8px 16px;background:#0ea5e9;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:500;display:flex;align-items:center;gap:6px;">
                        <i class="fas fa-plus"></i> Add Guide
                    </button>
                    <button onclick="document.getElementById('guideDirectoryModal').remove()" style="border:none;background:none;cursor:pointer;font-size:24px;color:#94a3b8;line-height:1;">&times;</button>
                </div>
            </div>
            <div style="flex:1;overflow-y:auto;padding:0;">
                <table style="width:100%;border-collapse:collapse;">
                    <thead>
                        <tr style="background:#f0f9ff;position:sticky;top:0;">
                            <th style="padding:12px 8px;text-align:left;font-weight:600;color:#0369a1;font-size:12px;text-transform:uppercase;">Guide Name</th>
                            <th style="padding:12px 8px;text-align:left;font-weight:600;color:#0369a1;font-size:12px;text-transform:uppercase;">Phone</th>
                            <th style="padding:12px 8px;text-align:left;font-weight:600;color:#0369a1;font-size:12px;text-transform:uppercase;">Languages</th>
                            <th style="padding:12px 8px;text-align:left;font-weight:600;color:#0369a1;font-size:12px;text-transform:uppercase;">License</th>
                            <th style="padding:12px 8px;text-align:center;font-weight:600;color:#0369a1;font-size:12px;text-transform:uppercase;width:100px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${guidesHtml || '<tr><td colspan="5" style="padding:40px;text-align:center;color:#94a3b8;">No guides in directory</td></tr>'}
                    </tbody>
                </table>
            </div>
            <div style="padding:16px 24px;border-top:1px solid #e2e8f0;background:#f0f9ff;display:flex;justify-content:flex-end;">
                <button onclick="document.getElementById('guideDirectoryModal').remove()" style="padding:10px 20px;background:#f1f5f9;color:#64748b;border:none;border-radius:6px;cursor:pointer;font-weight:500;">
                    Close
                </button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
}

// Add guide to directory prompt
function addGuideToDirectoryPrompt() {
    document.getElementById('guideDirectoryModal')?.remove();
    showAddGuideDialog('', '');
}

// Edit guide in directory
function editGuideInDirectory(guideId) {
    const guide = guideDirectory.find(g => g.id === guideId);
    if (!guide) return;

    document.getElementById('guideDirectoryModal')?.remove();

    const modal = document.createElement('div');
    modal.id = 'editGuideModal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;padding:24px;width:450px;max-width:90%;box-shadow:0 20px 40px rgba(0,0,0,0.2);">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                <h3 style="margin:0;color:#1e293b;display:flex;align-items:center;gap:8px;">
                    <i class="fas fa-edit" style="color:#3b82f6;"></i> Edit Guide
                </h3>
                <button onclick="document.getElementById('editGuideModal').remove(); showGuideDirectoryManager();" style="border:none;background:none;cursor:pointer;font-size:20px;color:#94a3b8;">&times;</button>
            </div>
            <div style="display:grid;gap:16px;">
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Guide Name *</label>
                    <input type="text" id="editGuideName" value="${guide.name}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Phone</label>
                        <input type="text" id="editGuidePhone" value="${guide.phone || ''}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                    <div>
                        <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">License No.</label>
                        <input type="text" id="editGuideLicense" value="${guide.license || ''}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                    </div>
                </div>
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Languages (comma separated)</label>
                    <input type="text" id="editGuideLanguages" value="${guide.languages ? guide.languages.join(', ') : ''}" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                </div>
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Rating</label>
                    <select id="editGuideRating" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">
                        <option value="3" ${guide.rating === 3 ? 'selected' : ''}>⭐⭐⭐ Good</option>
                        <option value="4" ${guide.rating === 4 ? 'selected' : ''}>⭐⭐⭐⭐ Very Good</option>
                        <option value="5" ${guide.rating === 5 ? 'selected' : ''}>⭐⭐⭐⭐⭐ Excellent</option>
                    </select>
                </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px;">
                <button onclick="document.getElementById('editGuideModal').remove(); showGuideDirectoryManager();" style="padding:10px 20px;background:#f1f5f9;color:#64748b;border:none;border-radius:6px;cursor:pointer;font-weight:500;">
                    Cancel
                </button>
                <button onclick="saveEditedGuide(${guide.id})" style="padding:10px 20px;background:#3b82f6;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:500;display:flex;align-items:center;gap:6px;">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Save edited guide
function saveEditedGuide(guideId) {
    const guide = guideDirectory.find(g => g.id === guideId);
    if (!guide) return;

    guide.name = document.getElementById('editGuideName')?.value.trim() || guide.name;
    guide.phone = document.getElementById('editGuidePhone')?.value.trim() || '';
    guide.license = document.getElementById('editGuideLicense')?.value.trim() || '';
    const langStr = document.getElementById('editGuideLanguages')?.value.trim() || '';
    guide.languages = langStr ? langStr.split(',').map(l => l.trim()).filter(l => l) : [];
    guide.rating = parseInt(document.getElementById('editGuideRating')?.value) || 5;

    saveGuideDirectory();

    document.getElementById('editGuideModal')?.remove();
    showGuideDirectoryManager();
    showNotification('Guide updated!', 'success');
}

// Delete guide from directory
function deleteGuideFromDirectory(guideId) {
    const guide = guideDirectory.find(g => g.id === guideId);
    if (!guide) return;

    if (confirm(`Delete "${guide.name}" from the directory?`)) {
        guideDirectory = guideDirectory.filter(g => g.id !== guideId);
        saveGuideDirectory();
        showGuideDirectoryManager();
        showNotification('Guide deleted from directory', 'info');
    }
}

// Initialize guide directory on load
loadGuideDirectory();

// ============================================
// TRANSPORTATION SECTION
// ============================================
let bookingTransports = [];
let transportDirectory = [];

function loadTransportDirectory() {
    const saved = localStorage.getItem('transportDirectory');
    if (saved) {
        transportDirectory = JSON.parse(saved);
    } else {
        transportDirectory = [
            { id: 1, company: 'Bangkok Van Service', vehicle_type: 'Van 10 Seats', driver: 'Mr. Somchai', phone: '+66 81 111 2222', license_plate: 'กข 1234' },
            { id: 2, company: 'Thai Luxury Coach', vehicle_type: 'Bus 40 Seats', driver: 'Mr. Prasert', phone: '+66 82 333 4444', license_plate: 'ขค 5678' },
            { id: 3, company: 'VIP Transport BKK', vehicle_type: 'Alphard 6 Seats', driver: 'Mr. Wichai', phone: '+66 83 555 6666', license_plate: 'คง 9012' },
            { id: 4, company: 'Phuket Transfer', vehicle_type: 'Van 10 Seats', driver: 'Mr. Anuchai', phone: '+66 84 777 8888', license_plate: 'จฉ 3456' },
            { id: 5, company: 'Chiang Mai Van', vehicle_type: 'Van 10 Seats', driver: 'Mr. Nattapong', phone: '+66 85 999 0000', license_plate: 'ชซ 7890' }
        ];
        saveTransportDirectory();
    }
}

function saveTransportDirectory() {
    localStorage.setItem('transportDirectory', JSON.stringify(transportDirectory));
}

function generateTransportId() {
    return 'transport_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function addNewTransport() {
    const transport = {
        id: generateTransportId(),
        company: '',
        vehicle_type: '',
        driver: '',
        phone: '',
        license_plate: '',
        days: '',
        pickup_time: '',
        notes: ''
    };
    bookingTransports.push(transport);
    renderTransportsContainer();
    setTimeout(() => {
        const input = document.getElementById(`transport_company_${transport.id}`);
        if (input) input.focus();
    }, 100);
}

function removeTransport(id) {
    const t = bookingTransports.find(x => x.id === id);
    if (t && confirm(`Remove "${t.company || 'this transport'}"?`)) {
        bookingTransports = bookingTransports.filter(x => x.id !== id);
        renderTransportsContainer();
        showNotification('Transport removed', 'info');
    }
}

function updateTransportField(id, field, value) {
    const t = bookingTransports.find(x => x.id === id);
    if (t) t[field] = value;
}

function searchTransportDirectory(query) {
    if (!query || query.length < 2) return [];
    const q = query.toLowerCase();
    return transportDirectory.filter(t => 
        t.company.toLowerCase().includes(q) || 
        t.vehicle_type.toLowerCase().includes(q) ||
        t.driver.toLowerCase().includes(q)
    ).slice(0, 8);
}

function showTransportAutocomplete(inputId, transportId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const query = input.value;
    const results = searchTransportDirectory(query);
    
    const existing = document.getElementById(`transport_autocomplete_${transportId}`);
    if (existing) existing.remove();

    if (results.length === 0) {
        if (query.length >= 3) {
            const dropdown = createTransportDropdown(transportId, input, [{ isNew: true, company: `➕ Add "${query}" to directory...` }]);
            input.parentNode.appendChild(dropdown);
        }
        return;
    }
    const dropdown = createTransportDropdown(transportId, input, results);
    input.parentNode.appendChild(dropdown);
}

function createTransportDropdown(transportId, input, results) {
    const dropdown = document.createElement('div');
    dropdown.id = `transport_autocomplete_${transportId}`;
    dropdown.style.cssText = 'position:absolute;top:100%;left:0;right:0;background:white;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);max-height:250px;overflow-y:auto;z-index:1000;';

    results.forEach(t => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 12px;cursor:pointer;border-bottom:1px solid #f1f5f9;';
        if (t.isNew) {
            item.innerHTML = `<span style="color:#f97316;font-weight:500;">${t.company}</span>`;
            item.onclick = () => { hideTransportAutocomplete(transportId); showAddTransportDialog(transportId, input.value); };
        } else {
            item.innerHTML = `<div style="font-weight:500;color:#1e293b;">${t.company}</div><div style="font-size:12px;color:#64748b;">${t.vehicle_type} • ${t.driver} • ${t.phone}</div>`;
            item.onclick = () => selectTransportFromDirectory(transportId, t);
        }
        item.onmouseover = () => item.style.background = '#fff7ed';
        item.onmouseout = () => item.style.background = 'white';
        dropdown.appendChild(item);
    });
    return dropdown;
}

function hideTransportAutocomplete(id) {
    const d = document.getElementById(`transport_autocomplete_${id}`);
    if (d) d.remove();
}

function selectTransportFromDirectory(transportId, dir) {
    const t = bookingTransports.find(x => x.id === transportId);
    if (!t) return;
    t.company = dir.company; t.vehicle_type = dir.vehicle_type; t.driver = dir.driver; t.phone = dir.phone; t.license_plate = dir.license_plate;
    
    ['company', 'vehicle_type', 'driver', 'phone', 'license_plate'].forEach(f => {
        const el = document.getElementById(`transport_${f}_${transportId}`);
        if (el) el.value = t[f] || '';
    });
    hideTransportAutocomplete(transportId);
    showNotification(`Transport "${dir.company}" selected`, 'success');
}

function showAddTransportDialog(transportId, name) {
    const modal = document.createElement('div');
    modal.id = 'addTransportModal';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:10000;';
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;padding:24px;width:450px;max-width:90%;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                <h3 style="margin:0;color:#1e293b;"><i class="fas fa-shuttle-van" style="color:#f97316;margin-right:8px;"></i>Add Transport</h3>
                <button onclick="document.getElementById('addTransportModal').remove()" style="border:none;background:none;font-size:20px;color:#94a3b8;cursor:pointer;">&times;</button>
            </div>
            <div style="display:grid;gap:12px;">
                <input type="text" id="newTransportCompany" value="${name||''}" placeholder="Company Name *" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <input type="text" id="newTransportVehicle" placeholder="Vehicle Type (e.g., Van 10)" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                    <input type="text" id="newTransportPlate" placeholder="License Plate" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <input type="text" id="newTransportDriver" placeholder="Driver Name" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                    <input type="text" id="newTransportPhone" placeholder="Phone" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:20px;">
                <button onclick="document.getElementById('addTransportModal').remove()" style="padding:10px 20px;background:#f1f5f9;border:none;border-radius:6px;cursor:pointer;">Cancel</button>
                <button onclick="saveNewTransportToDirectory('${transportId}')" style="padding:10px 20px;background:#f97316;color:white;border:none;border-radius:6px;cursor:pointer;"><i class="fas fa-save"></i> Save</button>
            </div>
        </div>`;
    document.body.appendChild(modal);
}

function saveNewTransportToDirectory(transportId) {
    const company = document.getElementById('newTransportCompany')?.value.trim();
    if (!company) { showNotification('Company name required', 'error'); return; }
    const newId = transportDirectory.length > 0 ? Math.max(...transportDirectory.map(t => t.id)) + 1 : 1;
    const newT = {
        id: newId, company,
        vehicle_type: document.getElementById('newTransportVehicle')?.value.trim() || '',
        driver: document.getElementById('newTransportDriver')?.value.trim() || '',
        phone: document.getElementById('newTransportPhone')?.value.trim() || '',
        license_plate: document.getElementById('newTransportPlate')?.value.trim() || ''
    };
    transportDirectory.push(newT);
    saveTransportDirectory();
    document.getElementById('addTransportModal')?.remove();
    if (transportId) selectTransportFromDirectory(transportId, newT);
    showNotification(`"${company}" added to directory!`, 'success');
}

function renderTransportsContainer() {
    // Try both container IDs - booking-confirmation uses 'transportsContainer', operation-arrangement uses 'opTransportsContainer'
    let container = document.getElementById('transportsContainer');
    const isOperationPage = !container;
    if (!container) {
        container = document.getElementById('opTransportsContainer');
    }
    const noMsg = document.getElementById('noTransportsMessage');
    const countEl = document.getElementById('transportCount');
    const opTransportBadge = document.getElementById('opTransportBadge');
    if (!container) return;

    if (bookingTransports.length === 0) {
        container.innerHTML = isOperationPage ? `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-shuttle-van" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No transport arranged yet</p>
            </div>
        ` : '';
        if (noMsg) noMsg.style.display = 'block';
        if (countEl) countEl.textContent = '0 Vehicles';
        if (opTransportBadge) opTransportBadge.textContent = '0';
        return;
    }
    if (noMsg) noMsg.style.display = 'none';
    if (countEl) countEl.textContent = `${bookingTransports.length} Vehicle${bookingTransports.length > 1 ? 's' : ''}`;
    if (opTransportBadge) opTransportBadge.textContent = bookingTransports.length;

    container.innerHTML = bookingTransports.map((t, i) => `
        <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:12px;padding:20px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
                <div style="display:flex;align-items:center;gap:12px;flex:1;">
                    <span style="background:#f97316;color:white;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;"><i class="fas fa-shuttle-van"></i></span>
                    <div style="position:relative;flex:1;max-width:300px;">
                        <input type="text" id="transport_company_${t.id}" value="${t.company||''}" onchange="updateTransportField('${t.id}','company',this.value)" oninput="showTransportAutocomplete('transport_company_${t.id}','${t.id}')" onblur="setTimeout(()=>hideTransportAutocomplete('${t.id}'),200)" placeholder="🔍 Search company..." autocomplete="off" style="width:100%;padding:8px 12px;border:1px solid #fed7aa;border-radius:8px;font-weight:600;">
                    </div>
                </div>
                <button onclick="removeTransport('${t.id}')" style="width:28px;height:28px;border:none;background:#fee2e2;color:#dc2626;border-radius:6px;cursor:pointer;"><i class="fas fa-times"></i></button>
            </div>
            <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;">
                <div><label style="font-size:11px;color:#c2410c;">Vehicle Type</label><input type="text" id="transport_vehicle_type_${t.id}" value="${t.vehicle_type||''}" onchange="updateTransportField('${t.id}','vehicle_type',this.value)" style="width:100%;padding:8px;border:1px solid #fed7aa;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#c2410c;">Driver</label><input type="text" id="transport_driver_${t.id}" value="${t.driver||''}" onchange="updateTransportField('${t.id}','driver',this.value)" style="width:100%;padding:8px;border:1px solid #fed7aa;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#c2410c;">Phone</label><input type="text" id="transport_phone_${t.id}" value="${t.phone||''}" onchange="updateTransportField('${t.id}','phone',this.value)" style="width:100%;padding:8px;border:1px solid #fed7aa;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#c2410c;">Days</label><input type="text" id="transport_days_${t.id}" value="${t.days||''}" onchange="updateTransportField('${t.id}','days',this.value)" placeholder="Day 1-3" style="width:100%;padding:8px;border:1px solid #fed7aa;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#c2410c;">Pickup Time</label><input type="text" id="transport_pickup_time_${t.id}" value="${t.pickup_time||''}" onchange="updateTransportField('${t.id}','pickup_time',this.value)" placeholder="08:00" style="width:100%;padding:8px;border:1px solid #fed7aa;border-radius:6px;font-size:13px;"></div>
            </div>
        </div>
    `).join('');
}

function initBookingTransports(booking, fullData) {
    bookingTransports = booking.transports || fullData.transports || [];
    renderTransportsContainer();
}

function saveTransportAssignments() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) { showNotification('No booking loaded', 'error'); return; }
    const booking = JSON.parse(bookingData);
    booking.transports = bookingTransports;
    if (!booking.full_data) booking.full_data = {};
    booking.full_data.transports = bookingTransports;
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    updateBookingInList(booking);
    
    // Sync to Supabase
    saveTransportsToSupabase(booking);
    
    showNotification('Transport saved!', 'success');
}

async function saveTransportsToSupabase(booking) {
    try {
        const supabaseClient = window.supabaseClient;
        if (!supabaseClient) return;

        const { data, error } = await supabaseClient
            .from('bookings')
            .update({ transports: booking.transports || [] })
            .eq('booking_number', booking.booking_id);

        if (error) {
            console.warn('Supabase: failed to update transports:', error.message);
        } else {
            console.log('✅ Supabase transports updated (' + (booking.transports?.length || 0) + ' vehicles)');
        }
    } catch (err) {
        console.error('Error saving transports to Supabase:', err);
    }
}

function showTransportDirectoryManager() {
    const modal = document.createElement('div');
    modal.id = 'transportDirectoryModal';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:10000;';
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;width:850px;max-width:95%;max-height:85vh;display:flex;flex-direction:column;">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid #e2e8f0;">
                <h3 style="margin:0;color:#1e293b;"><i class="fas fa-car" style="color:#f97316;margin-right:10px;"></i>Transport Directory <span style="background:#ffedd5;color:#c2410c;padding:2px 10px;border-radius:12px;font-size:12px;">${transportDirectory.length}</span></h3>
                <button onclick="document.getElementById('transportDirectoryModal').remove()" style="border:none;background:none;font-size:24px;color:#94a3b8;cursor:pointer;">&times;</button>
            </div>
            <div style="flex:1;overflow-y:auto;padding:0;">
                <table style="width:100%;border-collapse:collapse;">
                    <thead><tr style="background:#fff7ed;"><th style="padding:12px 8px;text-align:left;color:#c2410c;font-size:12px;">Company</th><th style="padding:12px 8px;text-align:left;color:#c2410c;font-size:12px;">Vehicle</th><th style="padding:12px 8px;text-align:left;color:#c2410c;font-size:12px;">Driver</th><th style="padding:12px 8px;text-align:left;color:#c2410c;font-size:12px;">Phone</th><th style="padding:12px 8px;text-align:left;color:#c2410c;font-size:12px;">Plate</th></tr></thead>
                    <tbody>${transportDirectory.map(t=>`<tr style="border-bottom:1px solid #f1f5f9;"><td style="padding:12px 8px;font-weight:500;">${t.company}</td><td style="padding:12px 8px;color:#64748b;">${t.vehicle_type}</td><td style="padding:12px 8px;color:#64748b;">${t.driver}</td><td style="padding:12px 8px;color:#64748b;">${t.phone}</td><td style="padding:12px 8px;color:#64748b;">${t.license_plate}</td></tr>`).join('')}</tbody>
                </table>
            </div>
            <div style="padding:16px 24px;border-top:1px solid #e2e8f0;display:flex;justify-content:flex-end;"><button onclick="document.getElementById('transportDirectoryModal').remove()" style="padding:10px 20px;background:#f1f5f9;border:none;border-radius:6px;cursor:pointer;">Close</button></div>
        </div>`;
    document.body.appendChild(modal);
}

loadTransportDirectory();

// ============================================
// RESTAURANT SECTION
// ============================================
let bookingRestaurants = [];
let restaurantDirectory = [];

function loadRestaurantDirectory() {
    const saved = localStorage.getItem('restaurantDirectory');
    if (saved) {
        restaurantDirectory = JSON.parse(saved);
    } else {
        restaurantDirectory = [
            { id: 1, name: 'Sala Rim Naam', cuisine: 'Thai', location: 'Bangkok', phone: '+66 2 659 9000', price_range: '$$$' },
            { id: 2, name: 'Blue Elephant', cuisine: 'Thai Fine Dining', location: 'Bangkok', phone: '+66 2 673 9353', price_range: '$$$' },
            { id: 3, name: 'Baan Khanitha', cuisine: 'Thai', location: 'Bangkok', phone: '+66 2 258 4181', price_range: '$$' },
            { id: 4, name: 'Khao Soi Khun Yai', cuisine: 'Northern Thai', location: 'Chiang Mai', phone: '+66 53 814 148', price_range: '$' },
            { id: 5, name: 'The Cliff', cuisine: 'Italian/Thai', location: 'Phuket', phone: '+66 76 344 254', price_range: '$$$' }
        ];
        saveRestaurantDirectory();
    }
}

function saveRestaurantDirectory() {
    localStorage.setItem('restaurantDirectory', JSON.stringify(restaurantDirectory));
}

function generateRestaurantId() {
    return 'restaurant_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function addNewRestaurant() {
    const r = { id: generateRestaurantId(), name: '', cuisine: '', location: '', phone: '', day: '', date: '', meal_type: 'Lunch', pax: '', notes: '' };
    bookingRestaurants.push(r);
    renderRestaurantsContainer();
    setTimeout(() => { const input = document.getElementById(`restaurant_name_${r.id}`); if (input) input.focus(); }, 100);
}

function removeRestaurant(id) {
    const r = bookingRestaurants.find(x => x.id === id);
    if (r && confirm(`Remove "${r.name || 'this restaurant'}"?`)) {
        bookingRestaurants = bookingRestaurants.filter(x => x.id !== id);
        renderRestaurantsContainer();
        showNotification('Restaurant removed', 'info');
    }
}

function updateRestaurantField(id, field, value) {
    const r = bookingRestaurants.find(x => x.id === id);
    if (r) r[field] = value;
}

function searchRestaurantDirectory(query) {
    if (!query || query.length < 2) return [];
    const q = query.toLowerCase();
    return restaurantDirectory.filter(r => r.name.toLowerCase().includes(q) || r.cuisine.toLowerCase().includes(q) || r.location.toLowerCase().includes(q)).slice(0, 8);
}

function showRestaurantAutocomplete(inputId, restaurantId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const query = input.value;
    const results = searchRestaurantDirectory(query);
    const existing = document.getElementById(`restaurant_autocomplete_${restaurantId}`);
    if (existing) existing.remove();
    if (results.length === 0) {
        if (query.length >= 3) {
            const dropdown = createRestaurantDropdown(restaurantId, input, [{ isNew: true, name: `➕ Add "${query}" to directory...` }]);
            input.parentNode.appendChild(dropdown);
        }
        return;
    }
    const dropdown = createRestaurantDropdown(restaurantId, input, results);
    input.parentNode.appendChild(dropdown);
}

function createRestaurantDropdown(restaurantId, input, results) {
    const dropdown = document.createElement('div');
    dropdown.id = `restaurant_autocomplete_${restaurantId}`;
    dropdown.style.cssText = 'position:absolute;top:100%;left:0;right:0;background:white;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);max-height:250px;overflow-y:auto;z-index:1000;';
    results.forEach(r => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 12px;cursor:pointer;border-bottom:1px solid #f1f5f9;';
        if (r.isNew) {
            item.innerHTML = `<span style="color:#ec4899;font-weight:500;">${r.name}</span>`;
            item.onclick = () => { hideRestaurantAutocomplete(restaurantId); showAddRestaurantDialog(restaurantId, input.value); };
        } else {
            item.innerHTML = `<div style="font-weight:500;color:#1e293b;">${r.name} <span style="color:#64748b;font-size:12px;">${r.price_range||''}</span></div><div style="font-size:12px;color:#64748b;">${r.cuisine} • ${r.location}</div>`;
            item.onclick = () => selectRestaurantFromDirectory(restaurantId, r);
        }
        item.onmouseover = () => item.style.background = '#fdf2f8';
        item.onmouseout = () => item.style.background = 'white';
        dropdown.appendChild(item);
    });
    return dropdown;
}

function hideRestaurantAutocomplete(id) {
    const d = document.getElementById(`restaurant_autocomplete_${id}`);
    if (d) d.remove();
}

function selectRestaurantFromDirectory(restaurantId, dir) {
    const r = bookingRestaurants.find(x => x.id === restaurantId);
    if (!r) return;
    r.name = dir.name; r.cuisine = dir.cuisine; r.location = dir.location; r.phone = dir.phone;
    ['name', 'cuisine', 'location', 'phone'].forEach(f => {
        const el = document.getElementById(`restaurant_${f}_${restaurantId}`);
        if (el) el.value = r[f] || '';
    });
    hideRestaurantAutocomplete(restaurantId);
    showNotification(`Restaurant "${dir.name}" selected`, 'success');
}

function showAddRestaurantDialog(restaurantId, name) {
    const modal = document.createElement('div');
    modal.id = 'addRestaurantModal';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:10000;';
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;padding:24px;width:450px;max-width:90%;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                <h3 style="margin:0;color:#1e293b;"><i class="fas fa-utensils" style="color:#ec4899;margin-right:8px;"></i>Add Restaurant</h3>
                <button onclick="document.getElementById('addRestaurantModal').remove()" style="border:none;background:none;font-size:20px;color:#94a3b8;cursor:pointer;">&times;</button>
            </div>
            <div style="display:grid;gap:12px;">
                <input type="text" id="newRestaurantName" value="${name||''}" placeholder="Restaurant Name *" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <input type="text" id="newRestaurantCuisine" placeholder="Cuisine (Thai, Chinese...)" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                    <input type="text" id="newRestaurantLocation" placeholder="Location" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <input type="text" id="newRestaurantPhone" placeholder="Phone" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                    <select id="newRestaurantPrice" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;"><option value="$">$ Budget</option><option value="$$" selected>$$ Mid-range</option><option value="$$$">$$$ Fine Dining</option></select>
                </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:20px;">
                <button onclick="document.getElementById('addRestaurantModal').remove()" style="padding:10px 20px;background:#f1f5f9;border:none;border-radius:6px;cursor:pointer;">Cancel</button>
                <button onclick="saveNewRestaurantToDirectory('${restaurantId}')" style="padding:10px 20px;background:#ec4899;color:white;border:none;border-radius:6px;cursor:pointer;"><i class="fas fa-save"></i> Save</button>
            </div>
        </div>`;
    document.body.appendChild(modal);
}

function saveNewRestaurantToDirectory(restaurantId) {
    const name = document.getElementById('newRestaurantName')?.value.trim();
    if (!name) { showNotification('Restaurant name required', 'error'); return; }
    const newId = restaurantDirectory.length > 0 ? Math.max(...restaurantDirectory.map(r => r.id)) + 1 : 1;
    const newR = {
        id: newId, name,
        cuisine: document.getElementById('newRestaurantCuisine')?.value.trim() || '',
        location: document.getElementById('newRestaurantLocation')?.value.trim() || '',
        phone: document.getElementById('newRestaurantPhone')?.value.trim() || '',
        price_range: document.getElementById('newRestaurantPrice')?.value || '$$'
    };
    restaurantDirectory.push(newR);
    saveRestaurantDirectory();
    document.getElementById('addRestaurantModal')?.remove();
    if (restaurantId) selectRestaurantFromDirectory(restaurantId, newR);
    showNotification(`"${name}" added to directory!`, 'success');
}

function renderRestaurantsContainer() {
    // Try both container IDs - booking-confirmation uses 'restaurantsContainer', operation-arrangement uses 'opRestaurantsContainer'
    let container = document.getElementById('restaurantsContainer');
    const isOperationPage = !container;
    if (!container) {
        container = document.getElementById('opRestaurantsContainer');
    }
    const noMsg = document.getElementById('noRestaurantsMessage');
    const countEl = document.getElementById('restaurantCount');
    const opRestaurantBadge = document.getElementById('opRestaurantBadge');
    if (!container) return;
    if (bookingRestaurants.length === 0) {
        container.innerHTML = isOperationPage ? `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-utensils" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No meals planned yet</p>
            </div>
        ` : '';
        if (noMsg) noMsg.style.display = 'block';
        if (countEl) countEl.textContent = '0 Meals';
        if (opRestaurantBadge) opRestaurantBadge.textContent = '0';
        return;
    }
    if (noMsg) noMsg.style.display = 'none';
    if (countEl) countEl.textContent = `${bookingRestaurants.length} Meal${bookingRestaurants.length > 1 ? 's' : ''}`;
    if (opRestaurantBadge) opRestaurantBadge.textContent = bookingRestaurants.length;

    container.innerHTML = bookingRestaurants.map((r, i) => `
        <div style="background:#fdf2f8;border:1px solid #fbcfe8;border-radius:12px;padding:20px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
                <div style="display:flex;align-items:center;gap:12px;flex:1;">
                    <span style="background:#ec4899;color:white;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;"><i class="fas fa-utensils"></i></span>
                    <div style="position:relative;flex:1;max-width:300px;">
                        <input type="text" id="restaurant_name_${r.id}" value="${r.name||''}" onchange="updateRestaurantField('${r.id}','name',this.value)" oninput="showRestaurantAutocomplete('restaurant_name_${r.id}','${r.id}')" onblur="setTimeout(()=>hideRestaurantAutocomplete('${r.id}'),200)" placeholder="🔍 Search restaurant..." autocomplete="off" style="width:100%;padding:8px 12px;border:1px solid #fbcfe8;border-radius:8px;font-weight:600;">
                    </div>
                </div>
                <button onclick="removeRestaurant('${r.id}')" style="width:28px;height:28px;border:none;background:#fee2e2;color:#dc2626;border-radius:6px;cursor:pointer;"><i class="fas fa-times"></i></button>
            </div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;">
                <div><label style="font-size:11px;color:#be185d;">Date</label><input type="date" id="restaurant_date_${r.id}" value="${r.date||''}" onchange="updateRestaurantField('${r.id}','date',this.value)" style="width:100%;padding:8px;border:1px solid #fbcfe8;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#be185d;">Meal Type</label><select id="restaurant_meal_type_${r.id}" onchange="updateRestaurantField('${r.id}','meal_type',this.value)" style="width:100%;padding:8px;border:1px solid #fbcfe8;border-radius:6px;font-size:13px;"><option ${r.meal_type==='Breakfast'?'selected':''}>Breakfast</option><option ${r.meal_type==='Lunch'||!r.meal_type?'selected':''}>Lunch</option><option ${r.meal_type==='Dinner'?'selected':''}>Dinner</option></select></div>
                <div><label style="font-size:11px;color:#be185d;">Phone</label><input type="tel" id="restaurant_phone_${r.id}" value="${r.phone||''}" onchange="updateRestaurantField('${r.id}','phone',this.value)" placeholder="Phone number" style="width:100%;padding:8px;border:1px solid #fbcfe8;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#be185d;">PAX</label><input type="text" id="restaurant_pax_${r.id}" value="${r.pax||''}" onchange="updateRestaurantField('${r.id}','pax',this.value)" style="width:100%;padding:8px;border:1px solid #fbcfe8;border-radius:6px;font-size:13px;"></div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px;">
                <div><label style="font-size:11px;color:#be185d;">Cuisine</label><input type="text" id="restaurant_cuisine_${r.id}" value="${r.cuisine||''}" onchange="updateRestaurantField('${r.id}','cuisine',this.value)" style="width:100%;padding:8px;border:1px solid #fbcfe8;border-radius:6px;font-size:13px;"></div>
                <div style="grid-column:span 2;"><label style="font-size:11px;color:#be185d;">Location</label><input type="text" id="restaurant_location_${r.id}" value="${r.location||''}" onchange="updateRestaurantField('${r.id}','location',this.value)" style="width:100%;padding:8px;border:1px solid #fbcfe8;border-radius:6px;font-size:13px;"></div>
            </div>
        </div>
    `).join('');
}

function initBookingRestaurants(booking, fullData) {
    bookingRestaurants = booking.restaurants || fullData.restaurants || [];
    renderRestaurantsContainer();
}

function saveRestaurantAssignments() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) { showNotification('No booking loaded', 'error'); return; }
    const booking = JSON.parse(bookingData);
    booking.restaurants = bookingRestaurants;
    if (!booking.full_data) booking.full_data = {};
    booking.full_data.restaurants = bookingRestaurants;
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    updateBookingInList(booking);
    
    // Sync to Supabase
    saveRestaurantsToSupabase(booking);
    
    showNotification('Restaurants saved!', 'success');
}

async function saveRestaurantsToSupabase(booking) {
    try {
        const supabaseClient = window.supabaseClient;
        if (!supabaseClient) return;

        const { data, error } = await supabaseClient
            .from('bookings')
            .update({ restaurants: booking.restaurants || [] })
            .eq('booking_number', booking.booking_id);

        if (error) {
            console.warn('Supabase: failed to update restaurants:', error.message);
        } else {
            console.log('✅ Supabase restaurants updated (' + (booking.restaurants?.length || 0) + ' meals)');
        }
    } catch (err) {
        console.error('Error saving restaurants to Supabase:', err);
    }
}

function showRestaurantDirectoryManager() {
    const modal = document.createElement('div');
    modal.id = 'restaurantDirectoryModal';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:10000;';
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;width:800px;max-width:95%;max-height:85vh;display:flex;flex-direction:column;">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid #e2e8f0;">
                <h3 style="margin:0;color:#1e293b;"><i class="fas fa-store" style="color:#ec4899;margin-right:10px;"></i>Restaurant Directory <span style="background:#fce7f3;color:#be185d;padding:2px 10px;border-radius:12px;font-size:12px;">${restaurantDirectory.length}</span></h3>
                <button onclick="document.getElementById('restaurantDirectoryModal').remove()" style="border:none;background:none;font-size:24px;color:#94a3b8;cursor:pointer;">&times;</button>
            </div>
            <div style="flex:1;overflow-y:auto;padding:0;">
                <table style="width:100%;border-collapse:collapse;">
                    <thead><tr style="background:#fdf2f8;"><th style="padding:12px 8px;text-align:left;color:#be185d;font-size:12px;">Name</th><th style="padding:12px 8px;text-align:left;color:#be185d;font-size:12px;">Cuisine</th><th style="padding:12px 8px;text-align:left;color:#be185d;font-size:12px;">Location</th><th style="padding:12px 8px;text-align:left;color:#be185d;font-size:12px;">Phone</th><th style="padding:12px 8px;text-align:left;color:#be185d;font-size:12px;">Price</th></tr></thead>
                    <tbody>${restaurantDirectory.map(r=>`<tr style="border-bottom:1px solid #f1f5f9;"><td style="padding:12px 8px;font-weight:500;">${r.name}</td><td style="padding:12px 8px;color:#64748b;">${r.cuisine}</td><td style="padding:12px 8px;color:#64748b;">${r.location}</td><td style="padding:12px 8px;color:#64748b;">${r.phone}</td><td style="padding:12px 8px;color:#64748b;">${r.price_range}</td></tr>`).join('')}</tbody>
                </table>
            </div>
            <div style="padding:16px 24px;border-top:1px solid #e2e8f0;display:flex;justify-content:flex-end;"><button onclick="document.getElementById('restaurantDirectoryModal').remove()" style="padding:10px 20px;background:#f1f5f9;border:none;border-radius:6px;cursor:pointer;">Close</button></div>
        </div>`;
    document.body.appendChild(modal);
}

loadRestaurantDirectory();

// ============================================
// ADMISSION SECTION
// ============================================
let bookingAdmissions = [];
let admissionDirectory = [];

function loadAdmissionDirectory() {
    const saved = localStorage.getItem('admissionDirectory');
    if (saved) {
        admissionDirectory = JSON.parse(saved);
    } else {
        admissionDirectory = [
            { id: 1, name: 'Grand Palace', location: 'Bangkok', adult_price: 500, child_price: 0, currency: 'THB' },
            { id: 2, name: 'Wat Pho', location: 'Bangkok', adult_price: 200, child_price: 0, currency: 'THB' },
            { id: 3, name: 'Safari World', location: 'Bangkok', adult_price: 1500, child_price: 1200, currency: 'THB' },
            { id: 4, name: 'Doi Suthep Temple', location: 'Chiang Mai', adult_price: 50, child_price: 20, currency: 'THB' },
            { id: 5, name: 'Phi Phi Islands Tour', location: 'Phuket', adult_price: 1800, child_price: 1200, currency: 'THB' },
            { id: 6, name: 'Elephant Sanctuary', location: 'Chiang Mai', adult_price: 2500, child_price: 1800, currency: 'THB' },
            { id: 7, name: 'Alcazar Cabaret Show', location: 'Pattaya', adult_price: 800, child_price: 600, currency: 'THB' }
        ];
        saveAdmissionDirectory();
    }
}

function saveAdmissionDirectory() {
    localStorage.setItem('admissionDirectory', JSON.stringify(admissionDirectory));
}

function generateAdmissionId() {
    return 'admission_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function addNewAdmission() {
    const a = { id: generateAdmissionId(), name: '', reservation_no: '', reservation_time: '', adult_price: 0, child_price: 0, date: '', adult_qty: 0, child_qty: 0, notes: '' };
    bookingAdmissions.push(a);
    renderAdmissionsContainer();
    setTimeout(() => { const input = document.getElementById(`admission_name_${a.id}`); if (input) input.focus(); }, 100);
}

function removeAdmission(id) {
    const a = bookingAdmissions.find(x => x.id === id);
    if (a && confirm(`Remove "${a.name || 'this admission'}"?`)) {
        bookingAdmissions = bookingAdmissions.filter(x => x.id !== id);
        renderAdmissionsContainer();
        showNotification('Admission removed', 'info');
    }
}

function updateAdmissionField(id, field, value) {
    const a = bookingAdmissions.find(x => x.id === id);
    if (a) a[field] = value;
}

function searchAdmissionDirectory(query) {
    if (!query || query.length < 2) return [];
    const q = query.toLowerCase();
    return admissionDirectory.filter(a => a.name.toLowerCase().includes(q) || a.location.toLowerCase().includes(q)).slice(0, 8);
}

function showAdmissionAutocomplete(inputId, admissionId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const query = input.value;
    const results = searchAdmissionDirectory(query);
    const existing = document.getElementById(`admission_autocomplete_${admissionId}`);
    if (existing) existing.remove();
    if (results.length === 0) {
        if (query.length >= 3) {
            const dropdown = createAdmissionDropdown(admissionId, input, [{ isNew: true, name: `➕ Add "${query}" to directory...` }]);
            input.parentNode.appendChild(dropdown);
        }
        return;
    }
    const dropdown = createAdmissionDropdown(admissionId, input, results);
    input.parentNode.appendChild(dropdown);
}

function createAdmissionDropdown(admissionId, input, results) {
    const dropdown = document.createElement('div');
    dropdown.id = `admission_autocomplete_${admissionId}`;
    dropdown.style.cssText = 'position:absolute;top:100%;left:0;right:0;background:white;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);max-height:250px;overflow-y:auto;z-index:1000;';
    results.forEach(a => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 12px;cursor:pointer;border-bottom:1px solid #f1f5f9;';
        if (a.isNew) {
            item.innerHTML = `<span style="color:#8b5cf6;font-weight:500;">${a.name}</span>`;
            item.onclick = () => { hideAdmissionAutocomplete(admissionId); showAddAdmissionDialog(admissionId, input.value); };
        } else {
            item.innerHTML = `<div style="font-weight:500;color:#1e293b;">${a.name}</div><div style="font-size:12px;color:#64748b;">${a.location} • Adult: ฿${a.adult_price} / Child: ฿${a.child_price}</div>`;
            item.onclick = () => selectAdmissionFromDirectory(admissionId, a);
        }
        item.onmouseover = () => item.style.background = '#f5f3ff';
        item.onmouseout = () => item.style.background = 'white';
        dropdown.appendChild(item);
    });
    return dropdown;
}

function hideAdmissionAutocomplete(id) {
    const d = document.getElementById(`admission_autocomplete_${id}`);
    if (d) d.remove();
}

function selectAdmissionFromDirectory(admissionId, dir) {
    const a = bookingAdmissions.find(x => x.id === admissionId);
    if (!a) return;
    a.name = dir.name; a.location = dir.location; a.adult_price = dir.adult_price; a.child_price = dir.child_price;
    ['name', 'location', 'adult_price', 'child_price'].forEach(f => {
        const el = document.getElementById(`admission_${f}_${admissionId}`);
        if (el) el.value = a[f] || '';
    });
    hideAdmissionAutocomplete(admissionId);
    showNotification(`Admission "${dir.name}" selected`, 'success');
}

function showAddAdmissionDialog(admissionId, name) {
    const modal = document.createElement('div');
    modal.id = 'addAdmissionModal';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:10000;';
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;padding:24px;width:450px;max-width:90%;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                <h3 style="margin:0;color:#1e293b;"><i class="fas fa-ticket-alt" style="color:#8b5cf6;margin-right:8px;"></i>Add Admission</h3>
                <button onclick="document.getElementById('addAdmissionModal').remove()" style="border:none;background:none;font-size:20px;color:#94a3b8;cursor:pointer;">&times;</button>
            </div>
            <div style="display:grid;gap:12px;">
                <input type="text" id="newAdmissionName" value="${name||''}" placeholder="Place/Attraction Name *" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                <input type="text" id="newAdmissionLocation" placeholder="Location" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <input type="number" id="newAdmissionAdultPrice" placeholder="Adult Price (THB)" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                    <input type="number" id="newAdmissionChildPrice" placeholder="Child Price (THB)" style="padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:20px;">
                <button onclick="document.getElementById('addAdmissionModal').remove()" style="padding:10px 20px;background:#f1f5f9;border:none;border-radius:6px;cursor:pointer;">Cancel</button>
                <button onclick="saveNewAdmissionToDirectory('${admissionId}')" style="padding:10px 20px;background:#8b5cf6;color:white;border:none;border-radius:6px;cursor:pointer;"><i class="fas fa-save"></i> Save</button>
            </div>
        </div>`;
    document.body.appendChild(modal);
}

function saveNewAdmissionToDirectory(admissionId) {
    const name = document.getElementById('newAdmissionName')?.value.trim();
    if (!name) { showNotification('Attraction name required', 'error'); return; }
    const newId = admissionDirectory.length > 0 ? Math.max(...admissionDirectory.map(a => a.id)) + 1 : 1;
    const newA = {
        id: newId, name,
        location: document.getElementById('newAdmissionLocation')?.value.trim() || '',
        adult_price: parseInt(document.getElementById('newAdmissionAdultPrice')?.value) || 0,
        child_price: parseInt(document.getElementById('newAdmissionChildPrice')?.value) || 0,
        currency: 'THB'
    };
    admissionDirectory.push(newA);
    saveAdmissionDirectory();
    document.getElementById('addAdmissionModal')?.remove();
    if (admissionId) selectAdmissionFromDirectory(admissionId, newA);
    showNotification(`"${name}" added to directory!`, 'success');
}

function renderAdmissionsContainer() {
    // Try both container IDs - booking-confirmation uses 'admissionsContainer', operation-arrangement uses 'opAdmissionsContainer'
    let container = document.getElementById('admissionsContainer');
    const isOperationPage = !container;
    if (!container) {
        container = document.getElementById('opAdmissionsContainer');
    }
    const noMsg = document.getElementById('noAdmissionsMessage');
    const countEl = document.getElementById('admissionCount');
    const opAdmissionBadge = document.getElementById('opAdmissionBadge');
    if (!container) return;
    if (bookingAdmissions.length === 0) {
        container.innerHTML = isOperationPage ? `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-ticket-alt" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No admissions arranged yet</p>
            </div>
        ` : '';
        if (noMsg) noMsg.style.display = 'block';
        if (countEl) countEl.textContent = '0 Tickets';
        if (opAdmissionBadge) opAdmissionBadge.textContent = '0';
        return;
    }
    if (noMsg) noMsg.style.display = 'none';
    if (countEl) countEl.textContent = `${bookingAdmissions.length} Ticket${bookingAdmissions.length > 1 ? 's' : ''}`;
    if (opAdmissionBadge) opAdmissionBadge.textContent = bookingAdmissions.length;

    container.innerHTML = bookingAdmissions.map((a, i) => `
        <div style="background:#f5f3ff;border:1px solid #ddd6fe;border-radius:12px;padding:20px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
                <div style="display:flex;align-items:center;gap:12px;flex:1;">
                    <span style="background:#8b5cf6;color:white;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;"><i class="fas fa-ticket-alt"></i></span>
                    <div style="position:relative;flex:1;max-width:300px;">
                        <input type="text" id="admission_name_${a.id}" value="${a.name||''}" onchange="updateAdmissionField('${a.id}','name',this.value)" oninput="showAdmissionAutocomplete('admission_name_${a.id}','${a.id}')" onblur="setTimeout(()=>hideAdmissionAutocomplete('${a.id}'),200)" placeholder="🔍 Search attraction..." autocomplete="off" style="width:100%;padding:8px 12px;border:1px solid #ddd6fe;border-radius:8px;font-weight:600;">
                    </div>
                </div>
                <button onclick="removeAdmission('${a.id}')" style="width:28px;height:28px;border:none;background:#fee2e2;color:#dc2626;border-radius:6px;cursor:pointer;"><i class="fas fa-times"></i></button>
            </div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;">
                <div><label style="font-size:11px;color:#6d28d9;">Date</label><input type="date" id="admission_date_${a.id}" value="${a.date||''}" onchange="updateAdmissionField('${a.id}','date',this.value)" style="width:100%;padding:8px;border:1px solid #ddd6fe;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#6d28d9;">Reservation No.</label><input type="text" id="admission_reservation_no_${a.id}" value="${a.reservation_no||''}" onchange="updateAdmissionField('${a.id}','reservation_no',this.value)" placeholder="Reservation #" style="width:100%;padding:8px;border:1px solid #ddd6fe;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#6d28d9;">Reservation Time</label><input type="time" id="admission_reservation_time_${a.id}" value="${a.reservation_time||''}" onchange="updateAdmissionField('${a.id}','reservation_time',this.value)" style="width:100%;padding:8px;border:1px solid #ddd6fe;border-radius:6px;font-size:13px;"></div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:12px;">
                <div><label style="font-size:11px;color:#6d28d9;">Adult Price</label><input type="number" id="admission_adult_price_${a.id}" value="${a.adult_price||0}" onchange="updateAdmissionField('${a.id}','adult_price',this.value)" style="width:100%;padding:8px;border:1px solid #ddd6fe;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#6d28d9;">Adult Qty</label><input type="number" id="admission_adult_qty_${a.id}" value="${a.adult_qty||0}" onchange="updateAdmissionField('${a.id}','adult_qty',this.value)" style="width:100%;padding:8px;border:1px solid #ddd6fe;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#6d28d9;">Child Price</label><input type="number" id="admission_child_price_${a.id}" value="${a.child_price||0}" onchange="updateAdmissionField('${a.id}','child_price',this.value)" style="width:100%;padding:8px;border:1px solid #ddd6fe;border-radius:6px;font-size:13px;"></div>
                <div><label style="font-size:11px;color:#6d28d9;">Child Qty</label><input type="number" id="admission_child_qty_${a.id}" value="${a.child_qty||0}" onchange="updateAdmissionField('${a.id}','child_qty',this.value)" style="width:100%;padding:8px;border:1px solid #ddd6fe;border-radius:6px;font-size:13px;"></div>
            </div>
        </div>
    `).join('');
}

function initBookingAdmissions(booking, fullData) {
    bookingAdmissions = booking.admissions || fullData.admissions || [];
    renderAdmissionsContainer();
}

function saveAdmissionAssignments() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) { showNotification('No booking loaded', 'error'); return; }
    const booking = JSON.parse(bookingData);
    booking.admissions = bookingAdmissions;
    if (!booking.full_data) booking.full_data = {};
    booking.full_data.admissions = bookingAdmissions;
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    updateBookingInList(booking);
    
    // Sync to Supabase
    saveAdmissionsToSupabase(booking);
    
    showNotification('Admissions saved!', 'success');
}

async function saveAdmissionsToSupabase(booking) {
    try {
        const supabaseClient = window.supabaseClient;
        if (!supabaseClient) return;

        const { data, error } = await supabaseClient
            .from('bookings')
            .update({ admissions: booking.admissions || [] })
            .eq('booking_number', booking.booking_id);

        if (error) {
            console.warn('Supabase: failed to update admissions:', error.message);
        } else {
            console.log('✅ Supabase admissions updated (' + (booking.admissions?.length || 0) + ' tickets)');
        }
    } catch (err) {
        console.error('Error saving admissions to Supabase:', err);
    }
}

function showAdmissionDirectoryManager() {
    const modal = document.createElement('div');
    modal.id = 'admissionDirectoryModal';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:10000;';
    modal.innerHTML = `
        <div style="background:white;border-radius:12px;width:800px;max-width:95%;max-height:85vh;display:flex;flex-direction:column;">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid #e2e8f0;">
                <h3 style="margin:0;color:#1e293b;"><i class="fas fa-landmark" style="color:#8b5cf6;margin-right:10px;"></i>Admission Directory <span style="background:#ede9fe;color:#6d28d9;padding:2px 10px;border-radius:12px;font-size:12px;">${admissionDirectory.length}</span></h3>
                <button onclick="document.getElementById('admissionDirectoryModal').remove()" style="border:none;background:none;font-size:24px;color:#94a3b8;cursor:pointer;">&times;</button>
            </div>
            <div style="flex:1;overflow-y:auto;padding:0;">
                <table style="width:100%;border-collapse:collapse;">
                    <thead><tr style="background:#f5f3ff;"><th style="padding:12px 8px;text-align:left;color:#6d28d9;font-size:12px;">Name</th><th style="padding:12px 8px;text-align:left;color:#6d28d9;font-size:12px;">Location</th><th style="padding:12px 8px;text-align:left;color:#6d28d9;font-size:12px;">Adult Price</th><th style="padding:12px 8px;text-align:left;color:#6d28d9;font-size:12px;">Child Price</th></tr></thead>
                    <tbody>${admissionDirectory.map(a=>`<tr style="border-bottom:1px solid #f1f5f9;"><td style="padding:12px 8px;font-weight:500;">${a.name}</td><td style="padding:12px 8px;color:#64748b;">${a.location}</td><td style="padding:12px 8px;color:#64748b;">฿${a.adult_price}</td><td style="padding:12px 8px;color:#64748b;">฿${a.child_price}</td></tr>`).join('')}</tbody>
                </table>
            </div>
            <div style="padding:16px 24px;border-top:1px solid #e2e8f0;display:flex;justify-content:flex-end;"><button onclick="document.getElementById('admissionDirectoryModal').remove()" style="padding:10px 20px;background:#f1f5f9;border:none;border-radius:6px;cursor:pointer;">Close</button></div>
        </div>`;
    document.body.appendChild(modal);
}

loadAdmissionDirectory();

// Generate unique hotel ID
function generateHotelId() {
    return 'hotel_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// Add hotel from quotation itinerary
function selectHotelFromItinerary(hotelName, roomType, daysRange) {
    // Check if hotel already added
    if (bookingHotels.some(h => h.name === hotelName)) {
        showNotification(`Hotel "${hotelName}" is already added`, 'warning');
        return;
    }

    const paxCountEl = document.getElementById('paxCount');
    const pax = parseInt(paxCountEl?.textContent) || 2;
    
    let twn = 0, dbl = 0, sgl = 0, trp = 0;
    if (roomType) {
        const rt = roomType.toUpperCase();
        if (rt.includes('TWN') || rt.includes('TWIN')) {
            twn = Math.ceil(pax / 2);
        } else if (rt.includes('DBL') || rt.includes('DOUBLE')) {
            dbl = Math.ceil(pax / 2);
        } else if (rt.includes('SGL') || rt.includes('SINGLE')) {
            sgl = pax;
        } else if (rt.includes('TRP') || rt.includes('TRIPLE')) {
            trp = Math.ceil(pax / 3);
        }
    }

    const hotel = {
        id: generateHotelId(),
        name: hotelName,
        confirmation_no: '',
        tel: '',
        address: '',
        days: daysRange || '',
        room_twn: twn,
        room_dbl: dbl,
        room_sgl: sgl,
        room_trp: trp,
        room_other: 0,
        status: 'draft',
        notes: ''
    };

    bookingHotels.push(hotel);
    renderHotelsContainer();
    showNotification(`Hotel "${hotelName}" added`, 'success');
}

// Add new empty hotel
function addNewHotel() {
    const hotel = {
        id: generateHotelId(),
        name: '',
        confirmation_no: '',
        tel: '',
        address: '',
        days: '',
        room_twn: 0,
        room_dbl: 0,
        room_sgl: 0,
        room_trp: 0,
        room_other: 0,
        status: 'draft',
        notes: ''
    };

    bookingHotels.push(hotel);
    renderHotelsContainer();
    
    // Focus on the new hotel name input
    setTimeout(() => {
        const input = document.getElementById(`hotel_name_${hotel.id}`);
        if (input) input.focus();
    }, 100);
}

// Remove hotel from list
function removeHotel(hotelId) {
    const hotel = bookingHotels.find(h => h.id === hotelId);
    if (hotel && confirm(`Remove "${hotel.name || 'this hotel'}" from the booking?`)) {
        bookingHotels = bookingHotels.filter(h => h.id !== hotelId);
        renderHotelsContainer();
        showNotification('Hotel removed', 'info');
    }
}

// Update hotel field
function updateHotelField(hotelId, field, value) {
    const hotel = bookingHotels.find(h => h.id === hotelId);
    if (hotel) {
        hotel[field] = value;
        // Recalculate total if room field
        if (field.startsWith('room_')) {
            const totalEl = document.getElementById(`hotel_room_total_${hotelId}`);
            if (totalEl) {
                const total = (parseInt(hotel.room_twn) || 0) + (parseInt(hotel.room_dbl) || 0) + 
                              (parseInt(hotel.room_sgl) || 0) + (parseInt(hotel.room_trp) || 0) + 
                              (parseInt(hotel.room_other) || 0);
                totalEl.textContent = total;
            }
        }
    }
}

// Render hotels container
function renderHotelsContainer() {
    // Try both container IDs - booking-confirmation uses 'hotelsContainer', operation-arrangement uses 'opHotelsContainer'
    let container = document.getElementById('hotelsContainer');
    const isOperationPage = !container;
    if (!container) {
        container = document.getElementById('opHotelsContainer');
    }
    const noHotelsMessage = document.getElementById('noHotelsMessage');
    const hotelCountEl = document.getElementById('hotelCount');
    const opHotelBadge = document.getElementById('opHotelBadge');
    
    if (!container) return;

    if (bookingHotels.length === 0) {
        container.innerHTML = isOperationPage ? `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-hotel" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No hotels arranged yet</p>
            </div>
        ` : '';
        if (noHotelsMessage) noHotelsMessage.style.display = 'block';
        if (hotelCountEl) hotelCountEl.textContent = '0 Hotels';
        if (opHotelBadge) opHotelBadge.textContent = '0';
        return;
    }

    if (noHotelsMessage) noHotelsMessage.style.display = 'none';
    if (hotelCountEl) hotelCountEl.textContent = `${bookingHotels.length} Hotel${bookingHotels.length > 1 ? 's' : ''}`;
    if (opHotelBadge) opHotelBadge.textContent = bookingHotels.length;

    let html = '';
    bookingHotels.forEach((hotel, index) => {
        const statusColors = {
            'draft': { bg: '#f1f5f9', color: '#64748b', icon: '📝' },
            'sent': { bg: '#dbeafe', color: '#2563eb', icon: '📤' },
            'waiting': { bg: '#fef3c7', color: '#d97706', icon: '⏳' },
            'confirmed': { bg: '#dcfce7', color: '#16a34a', icon: '✅' },
            'not_available': { bg: '#fee2e2', color: '#dc2626', icon: '❌' },
            'alternative': { bg: '#e0e7ff', color: '#4f46e5', icon: '🔄' }
        };
        const statusInfo = statusColors[hotel.status] || statusColors['draft'];
        const roomTotal = (parseInt(hotel.room_twn) || 0) + (parseInt(hotel.room_dbl) || 0) + 
                          (parseInt(hotel.room_sgl) || 0) + (parseInt(hotel.room_trp) || 0) + 
                          (parseInt(hotel.room_other) || 0);

        html += `
            <div class="hotel-card" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:20px;position:relative;">
                <!-- Hotel Header -->
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                    <div style="display:flex;align-items:center;gap:12px;position:relative;flex:1;">
                        <span style="background:#6366f1;color:white;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:14px;">${index + 1}</span>
                        <div style="position:relative;flex:1;max-width:350px;">
                            <input type="text" id="hotel_name_${hotel.id}" value="${hotel.name}" 
                                   onchange="updateHotelField('${hotel.id}', 'name', this.value)"
                                   oninput="showHotelAutocomplete('hotel_name_${hotel.id}', '${hotel.id}')"
                                   onblur="setTimeout(() => hideHotelAutocomplete('${hotel.id}'), 200)"
                                   placeholder="🔍 Type hotel name to search..." 
                                   autocomplete="off"
                                   style="font-size:16px;font-weight:600;color:#1e293b;border:1px solid #e2e8f0;background:white;outline:none;width:100%;padding:8px 12px;border-radius:8px;">
                            <i class="fas fa-search" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:#94a3b8;pointer-events:none;"></i>
                        </div>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="background:${statusInfo.bg};color:${statusInfo.color};padding:4px 12px;border-radius:12px;font-size:12px;font-weight:500;">
                            ${statusInfo.icon} ${hotel.status.replace('_', ' ').toUpperCase()}
                        </span>
                        <button onclick="removeHotel('${hotel.id}')" style="width:28px;height:28px;border:none;background:#fee2e2;color:#dc2626;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;" title="Remove Hotel">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>

                <!-- Hotel Details Grid -->
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;margin-bottom:16px;">
                    <div>
                        <label style="font-size:11px;color:#64748b;display:block;margin-bottom:4px;">Days</label>
                        <input type="text" id="hotel_days_${hotel.id}" value="${hotel.days}" 
                               onchange="updateHotelField('${hotel.id}', 'days', this.value)"
                               placeholder="e.g., Day 1-3" 
                               style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">
                    </div>
                    <div>
                        <label style="font-size:11px;color:#64748b;display:block;margin-bottom:4px;">Confirmation No.</label>
                        <input type="text" id="hotel_conf_${hotel.id}" value="${hotel.confirmation_no}" 
                               onchange="updateHotelField('${hotel.id}', 'confirmation_no', this.value)"
                               placeholder="Conf. No." 
                               style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">
                    </div>
                    <div>
                        <label style="font-size:11px;color:#64748b;display:block;margin-bottom:4px;">Tel</label>
                        <input type="text" id="hotel_tel_${hotel.id}" value="${hotel.tel}" 
                               onchange="updateHotelField('${hotel.id}', 'tel', this.value)"
                               placeholder="Phone" 
                               style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">
                    </div>
                    <div>
                        <label style="font-size:11px;color:#64748b;display:block;margin-bottom:4px;">Status</label>
                        <select id="hotel_status_${hotel.id}" 
                                onchange="updateHotelField('${hotel.id}', 'status', this.value); renderHotelsContainer();"
                                style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;cursor:pointer;">
                            <option value="draft" ${hotel.status === 'draft' ? 'selected' : ''}>📝 Draft</option>
                            <option value="sent" ${hotel.status === 'sent' ? 'selected' : ''}>📤 Sent</option>
                            <option value="waiting" ${hotel.status === 'waiting' ? 'selected' : ''}>⏳ Waiting</option>
                            <option value="confirmed" ${hotel.status === 'confirmed' ? 'selected' : ''}>✅ Confirmed</option>
                            <option value="not_available" ${hotel.status === 'not_available' ? 'selected' : ''}>❌ Not Available</option>
                            <option value="alternative" ${hotel.status === 'alternative' ? 'selected' : ''}>🔄 Alternative</option>
                        </select>
                    </div>
                </div>

                <!-- Address -->
                <div style="margin-bottom:16px;">
                    <label style="font-size:11px;color:#64748b;display:block;margin-bottom:4px;">Address</label>
                    <input type="text" id="hotel_address_${hotel.id}" value="${hotel.address}" 
                           onchange="updateHotelField('${hotel.id}', 'address', this.value)"
                           placeholder="Hotel Address" 
                           style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">
                </div>

                <!-- Room Breakdown -->
                <div style="background:white;padding:12px 16px;border-radius:8px;border:1px solid #e2e8f0;">
                    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                        <span style="font-size:12px;color:#64748b;font-weight:500;">Rooms:</span>
                        <div style="display:flex;align-items:center;gap:4px;">
                            <input type="number" min="0" value="${hotel.room_twn}" 
                                   onchange="updateHotelField('${hotel.id}', 'room_twn', parseInt(this.value)||0)"
                                   style="width:45px;padding:4px;border:1px solid #e2e8f0;border-radius:4px;text-align:center;font-size:13px;">
                            <span style="color:#64748b;font-size:12px;">TWN</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:4px;">
                            <input type="number" min="0" value="${hotel.room_dbl}" 
                                   onchange="updateHotelField('${hotel.id}', 'room_dbl', parseInt(this.value)||0)"
                                   style="width:45px;padding:4px;border:1px solid #e2e8f0;border-radius:4px;text-align:center;font-size:13px;">
                            <span style="color:#64748b;font-size:12px;">DBL</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:4px;">
                            <input type="number" min="0" value="${hotel.room_sgl}" 
                                   onchange="updateHotelField('${hotel.id}', 'room_sgl', parseInt(this.value)||0)"
                                   style="width:45px;padding:4px;border:1px solid #e2e8f0;border-radius:4px;text-align:center;font-size:13px;">
                            <span style="color:#64748b;font-size:12px;">SGL</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:4px;">
                            <input type="number" min="0" value="${hotel.room_trp}" 
                                   onchange="updateHotelField('${hotel.id}', 'room_trp', parseInt(this.value)||0)"
                                   style="width:45px;padding:4px;border:1px solid #e2e8f0;border-radius:4px;text-align:center;font-size:13px;">
                            <span style="color:#64748b;font-size:12px;">TRP</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:4px;">
                            <input type="number" min="0" value="${hotel.room_other}" 
                                   onchange="updateHotelField('${hotel.id}', 'room_other', parseInt(this.value)||0)"
                                   style="width:45px;padding:4px;border:1px solid #e2e8f0;border-radius:4px;text-align:center;font-size:13px;">
                            <span style="color:#64748b;font-size:12px;">OTHER</span>
                        </div>
                        <div style="margin-left:auto;display:flex;align-items:center;gap:6px;">
                            <span style="font-weight:600;color:#1e293b;font-size:16px;" id="hotel_room_total_${hotel.id}">${roomTotal}</span>
                            <span style="color:#64748b;font-size:12px;">Total</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

// Initialize hotels from booking data
function initBookingHotels(booking, fullData) {
    bookingHotels = [];
    
    // Load saved hotels array if exists
    if (booking.hotels && Array.isArray(booking.hotels)) {
        bookingHotels = booking.hotels;
    } else if (fullData.hotels && Array.isArray(fullData.hotels)) {
        bookingHotels = fullData.hotels;
    } else if (booking.hotel_name || fullData.hotel_name) {
        // Legacy single hotel - convert to array
        bookingHotels.push({
            id: generateHotelId(),
            name: booking.hotel_name || fullData.hotel_name || '',
            confirmation_no: booking.hotel_confirmation_no || fullData.hotel_confirmation_no || '',
            tel: booking.hotel_tel || fullData.hotel_tel || '',
            address: booking.hotel_address || fullData.hotel_address || '',
            days: '',
            room_twn: parseInt(booking.room_twn || fullData.room_twn) || 0,
            room_dbl: parseInt(booking.room_dbl || fullData.room_dbl) || 0,
            room_sgl: parseInt(booking.room_sgl || fullData.room_sgl) || 0,
            room_trp: parseInt(booking.room_trp || fullData.room_trp) || 0,
            room_other: parseInt(booking.room_other || fullData.room_other) || 0,
            status: booking.hotel_request_status || 'draft',
            notes: ''
        });
    }
    
    renderHotelsContainer();
}

function saveHotelRequest() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) {
        showNotification('No booking loaded', 'error');
        return;
    }

    const booking = JSON.parse(bookingData);

    // Get hotel workflow data
    const specialRequestsEl = document.getElementById('hotelSpecialRequests');

    booking.hotel_special_requests = specialRequestsEl?.value || '';
    
    // Save the multi-hotel array
    booking.hotels = bookingHotels;
    
    // Determine overall status based on individual hotel statuses
    const statuses = bookingHotels.map(h => h.status);
    if (statuses.every(s => s === 'confirmed')) {
        booking.hotel_request_status = 'confirmed';
    } else if (statuses.some(s => s === 'not_available')) {
        booking.hotel_request_status = 'not_available';
    } else if (statuses.some(s => s === 'waiting')) {
        booking.hotel_request_status = 'waiting';
    } else if (statuses.some(s => s === 'sent')) {
        booking.hotel_request_status = 'sent';
    } else {
        booking.hotel_request_status = 'draft';
    }

    // Legacy compatibility - save first hotel to single fields
    if (bookingHotels.length > 0) {
        const firstHotel = bookingHotels[0];
        booking.hotel_name = firstHotel.name || '';
        booking.hotel_confirmation_no = firstHotel.confirmation_no || '';
        booking.hotel_tel = firstHotel.tel || '';
        booking.hotel_address = firstHotel.address || '';
        booking.room_twn = firstHotel.room_twn || 0;
        booking.room_dbl = firstHotel.room_dbl || 0;
        booking.room_sgl = firstHotel.room_sgl || 0;
        booking.room_trp = firstHotel.room_trp || 0;
        booking.room_other = firstHotel.room_other || 0;
        booking.room_total = (firstHotel.room_twn || 0) + (firstHotel.room_dbl || 0) + 
                             (firstHotel.room_sgl || 0) + (firstHotel.room_trp || 0) + (firstHotel.room_other || 0);
    }

    // Update full_data
    if (!booking.full_data) booking.full_data = {};
    booking.full_data.hotels = bookingHotels;
    booking.full_data.hotel_request_status = booking.hotel_request_status;
    booking.full_data.hotel_special_requests = booking.hotel_special_requests;
    booking.full_data.hotel_messages = booking.hotel_messages;

    // Add status change message automatically
    if (!booking.hotel_messages) booking.hotel_messages = [];
    const now = new Date();
    const timeStr = now.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    const statusLabels = {
        'draft': 'Draft',
        'sent': 'Sent to Operation',
        'waiting': 'Waiting for Hotel Confirm',
        'confirmed': 'Hotel Confirmed',
        'not_available': 'Not Available',
        'alternative': 'Alternative Offered'
    };
    booking.hotel_messages.push({
        from: 'sales',
        text: `📋 Status changed to: ${statusLabels[booking.hotel_request_status] || booking.hotel_request_status}`,
        time: timeStr,
        timestamp: now.toISOString()
    });

    // Save
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    updateBookingInList(booking);

    // Update Supabase
    saveHotelToSupabase(booking);

    // Refresh display
    loadHotelMessages(booking);
    updateHotelStatusBadge();

    showNotification('Hotel request saved & sent!', 'success');
}

function updateBookingInList(booking) {
    try {
        let bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
        const idx = bookings.findIndex(b => b.booking_id === booking.booking_id);
        if (idx !== -1) {
            bookings[idx] = Object.assign({}, bookings[idx], booking);
            localStorage.setItem('bookingsList', JSON.stringify(bookings));
        }
    } catch (e) {
        console.error('Error updating bookingsList:', e);
    }
}

async function saveHotelToSupabase(booking) {
    try {
        const supabaseClient = window.supabaseClient;
        if (!supabaseClient) return;

        const updateObj = {
            hotel_name: booking.hotel_name || null,
            hotel_confirmation_no: booking.hotel_confirmation_no || null,
            hotel_tel: booking.hotel_tel || null,
            hotel_address: booking.hotel_address || null,
            room_twn: booking.room_twn || 0,
            room_dbl: booking.room_dbl || 0,
            room_sgl: booking.room_sgl || 0,
            room_trp: booking.room_trp || 0,
            room_other: booking.room_other || 0,
            room_total: booking.room_total || 0,
            hotel_request_status: booking.hotel_request_status || 'draft',
            hotel_special_requests: booking.hotel_special_requests || null,
            hotels: booking.hotels || null  // Store hotels array as JSON
        };

        const { data, error } = await supabaseClient
            .from('bookings')
            .update(updateObj)
            .eq('booking_number', booking.booking_id);

        if (error) {
            console.warn('Supabase: failed to update hotel request:', error.message);
        } else {
            console.log('✅ Supabase hotel request updated (' + (booking.hotels?.length || 0) + ' hotels)');
        }
    } catch (err) {
        console.error('Error saving hotel to Supabase:', err);
    }
}

// Enable editing on booking confirmation fields
function enableBookingEditing() {
    const editableIds = [
        'customerName','nationality','contactPerson','customerEmail',
        'tourName','duration','paxCount',
        'arrivalDate','departureDate','arrivalFlight','departureFlight',
        'hotelName','hotelConfirmationNo','hotelTel','hotelAddress',
        'roomTWN','roomDBL','roomSGL','roomTRP','roomOTHER',
        'netTotal','sellingPrice','profit'
    ];

    editableIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.contentEditable = 'true';
            el.style.outline = '2px dashed rgba(99,102,241,0.15)';
            el.style.padding = '2px 4px';
        }
    });

    const editBtn = document.getElementById('editBtn');
    const saveBtn = document.getElementById('saveBtn');
    if (editBtn) editBtn.style.display = 'none';
    if (saveBtn) saveBtn.style.display = 'inline-flex';

    showNotification('Edit mode enabled — make changes and click Save', 'info');
}

// Save edited booking fields back to localStorage and update bookings list
function saveBookingEdits() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) {
        showNotification('No booking loaded', 'error');
        return;
    }

    const booking = JSON.parse(bookingData);

    const getText = (id) => document.getElementById(id)?.textContent.trim() || '';

    // Update booking object fields
    booking.customer_name = getText('customerName') || booking.customer_name;
    booking.nationality = getText('nationality') || booking.nationality;
    booking.contact_person = getText('contactPerson') || booking.contact_person;
    booking.customer_email = getText('customerEmail') || booking.customer_email;
    booking.tour_name = getText('tourName') || booking.tour_name;
    // Do NOT allow editing of quotation number here; keep original
    booking.duration = getText('duration') || booking.duration;
    booking.pax_count = parseInt(getText('paxCount')) || booking.pax_count;

    // Try to parse dates from display (e.g., Apr 01, 2026)
    const parseDateDisplay = (txt) => {
        if (!txt || txt === '-' ) return null;
        const parsed = Date.parse(txt);
        if (!isNaN(parsed)) return new Date(parsed).toISOString();
        return null;
    };

    const arrivalIso = parseDateDisplay(getText('arrivalDate'));
    const departureIso = parseDateDisplay(getText('departureDate'));
    if (arrivalIso) booking.travel_date = arrivalIso;
    if (departureIso) booking.end_date = departureIso;

    // Flights
    booking.arrival_flight = getText('arrivalFlight') || booking.arrival_flight || '';
    booking.departure_flight = getText('departureFlight') || booking.departure_flight || '';

    // Hotel Booking fields
    booking.hotel_name = getText('hotelName') || booking.hotel_name || '';
    booking.hotel_confirmation_no = getText('hotelConfirmationNo') || booking.hotel_confirmation_no || '';
    booking.hotel_tel = getText('hotelTel') || booking.hotel_tel || '';
    booking.hotel_address = getText('hotelAddress') || booking.hotel_address || '';
    booking.room_twn = parseInt(getText('roomTWN')) || 0;
    booking.room_dbl = parseInt(getText('roomDBL')) || 0;
    booking.room_sgl = parseInt(getText('roomSGL')) || 0;
    booking.room_trp = parseInt(getText('roomTRP')) || 0;
    booking.room_other = parseInt(getText('roomOTHER')) || 0;
    booking.room_total = booking.room_twn + booking.room_dbl + booking.room_sgl + booking.room_trp + booking.room_other;

    // Also update full_data snapshot if present so UI components that read full_data show updated values
    if (!booking.full_data) booking.full_data = {};
    booking.full_data.arrival_flight = booking.arrival_flight;
    booking.full_data.departure_flight = booking.departure_flight;
    booking.full_data.duration = booking.duration;
    booking.full_data.hotel_name = booking.hotel_name;
    booking.full_data.hotel_confirmation_no = booking.hotel_confirmation_no;
    booking.full_data.hotel_tel = booking.hotel_tel;
    booking.full_data.hotel_address = booking.hotel_address;
    booking.full_data.room_twn = booking.room_twn;
    booking.full_data.room_dbl = booking.room_dbl;
    booking.full_data.room_sgl = booking.room_sgl;
    booking.full_data.room_trp = booking.room_trp;
    booking.full_data.room_other = booking.room_other;
    booking.full_data.room_total = booking.room_total;

    // Pricing fields (strip non-numeric)
    const parseMoney = (txt) => parseFloat((txt || '').replace(/[^0-9.-]+/g, '')) || 0;
    const net = parseMoney(getText('netTotal'));
    const sell = parseMoney(getText('sellingPrice'));
    booking.net_total = net;
    booking.selling_price = sell;
    booking.profit = sell - net;

    // Persist currentBooking
    localStorage.setItem('currentBooking', JSON.stringify(booking));

    // Update bookingsList if present
    try {
        let bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
        const idx = bookings.findIndex(b => b.booking_id === booking.booking_id);
        if (idx !== -1) {
            bookings[idx] = Object.assign({}, bookings[idx], {
                customer_name: booking.customer_name,
                nationality: booking.nationality,
                contact_person: booking.contact_person,
                customer_email: booking.customer_email,
                tour_name: booking.tour_name,
                quotation_number: booking.quotation_number,
                pax_count: booking.pax_count,
                duration: booking.duration || bookings[idx].duration,
                travel_date: booking.travel_date || bookings[idx].travel_date,
                end_date: booking.end_date || bookings[idx].end_date,
                arrival_flight: booking.arrival_flight || bookings[idx].arrival_flight,
                departure_flight: booking.departure_flight || bookings[idx].departure_flight,
                hotel_name: booking.hotel_name || bookings[idx].hotel_name,
                hotel_confirmation_no: booking.hotel_confirmation_no || bookings[idx].hotel_confirmation_no,
                hotel_tel: booking.hotel_tel || bookings[idx].hotel_tel,
                hotel_address: booking.hotel_address || bookings[idx].hotel_address,
                room_twn: booking.room_twn,
                room_dbl: booking.room_dbl,
                room_sgl: booking.room_sgl,
                room_trp: booking.room_trp,
                room_other: booking.room_other,
                room_total: booking.room_total,
                net_total: booking.net_total,
                selling_price: booking.selling_price,
                profit: booking.profit,
                full_data: booking.full_data || bookings[idx].full_data
            });
            localStorage.setItem('bookingsList', JSON.stringify(bookings));
        }
    } catch (e) {
        console.error('Error updating bookingsList:', e);
    }

    // Attempt to persist updated fields to Supabase (if client available)
    (async () => {
        try {
            const supabaseClient = window.supabaseClient;
            if (!supabaseClient) return;

            // Map local booking fields to DB column names used elsewhere in the app
            const updateObj = {
                arrival_flight: booking.arrival_flight || null,
                departure_flight: booking.departure_flight || null,
                duration: booking.duration || null,
                hotel_name: booking.hotel_name || null,
                hotel_confirmation_no: booking.hotel_confirmation_no || null,
                hotel_tel: booking.hotel_tel || null,
                hotel_address: booking.hotel_address || null,
                room_twn: booking.room_twn || 0,
                room_dbl: booking.room_dbl || 0,
                room_sgl: booking.room_sgl || 0,
                room_trp: booking.room_trp || 0,
                room_other: booking.room_other || 0,
                room_total: booking.room_total || 0,
                travel_start_date: booking.travel_date ? (new Date(booking.travel_date)).toISOString().split('T')[0] : null,
                travel_end_date: booking.end_date ? (new Date(booking.end_date)).toISOString().split('T')[0] : null,
                number_of_passengers: booking.pax_count || booking.number_of_passengers || null,
                total_amount: booking.selling_price || booking.total_amount || null
            };

            // Only keep keys with non-null values (avoid overwriting unintentionally)
            Object.keys(updateObj).forEach(k => { if (updateObj[k] === null) delete updateObj[k]; });

            if (Object.keys(updateObj).length === 0) return;

            // The app writes booking_number = bookingId when creating records in Supabase
            const bookingNumber = booking.booking_id;
            const { data, error } = await supabaseClient
                .from('bookings')
                .update(updateObj)
                .eq('booking_number', bookingNumber);

            if (error) {
                console.warn('Supabase: failed to update booking:', error.message || error);

                // If column missing, give actionable advice in console
                if (error.message && /column .* does not exist/i.test(error.message)) {
                    console.warn('Supabase bookings table may be missing arrival_flight/departure_flight columns. Run ALTER TABLE to add them.');
                }
            } else {
                console.log('✅ Supabase booking updated:', data);
            }
        } catch (err) {
            console.error('Error updating Supabase booking:', err);
        }
    })();

    // Remove editable state
    const editableIds = ['customerName','nationality','contactPerson','customerEmail','tourName','quotationNumber','duration','paxCount','arrivalDate','departureDate','arrivalFlight','departureFlight','netTotal','sellingPrice','profit'];
    editableIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.contentEditable = 'false';
            el.style.outline = 'none';
            el.style.padding = '';
        }
    });

    const editBtn = document.getElementById('editBtn');
    const saveBtn = document.getElementById('saveBtn');
    if (editBtn) editBtn.style.display = 'inline-flex';
    if (saveBtn) saveBtn.style.display = 'none';

    showNotification('Booking changes saved', 'success');

    // Refresh current page display (do NOT call loadBookings here — we're on confirmation page)
    initBookingConfirmationPage();
}

function updateStatusBanner(status) {
    const banner = document.getElementById('statusBanner');
    if (!banner) return;
    
    const statusConfig = {
        'confirmed': { gradient: 'linear-gradient(135deg,#f59e0b,#d97706)', icon: 'fa-inbox', text: 'Receive from OP' },
        'processing': { gradient: 'linear-gradient(135deg,#22c55e,#16a34a)', icon: 'fa-paper-plane', text: 'Send to Sales' },
        'completed': { gradient: 'linear-gradient(135deg,#3b82f6,#2563eb)', icon: 'fa-check-double', text: 'Sales Updated' },
        'cancelled': { gradient: 'linear-gradient(135deg,#ef4444,#dc2626)', icon: 'fa-ban', text: 'Booking Cancelled' }
    };
    
    const config = statusConfig[status] || statusConfig['confirmed'];
    banner.style.background = config.gradient;
    banner.querySelector('i').className = 'fas ' + config.icon;
    banner.querySelector('p').textContent = config.text;
}

function highlightCurrentStatusButton(status) {
    document.querySelectorAll('.status-btn').forEach(btn => {
        const btnStatus = btn.dataset.status;
        if (btnStatus === status) {
            btn.style.background = btn.style.borderColor;
            btn.style.color = 'white';
        } else {
            btn.style.background = 'white';
        }
    });
}

function updateBookingStatus(newStatus) {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) return;
    
    const booking = JSON.parse(bookingData);
    booking.status = newStatus;
    
    // Update in localStorage
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    
    // Update in bookingsList
    let bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const index = bookings.findIndex(b => b.booking_id === booking.booking_id);
    if (index !== -1) {
        bookings[index].status = newStatus;
        localStorage.setItem('bookingsList', JSON.stringify(bookings));
    }
    
    // Update UI
    updateStatusBanner(newStatus);
    highlightCurrentStatusButton(newStatus);
    showNotification(`Booking status updated to ${newStatus}`, 'success');
}

function printBookingConfirmation() {
    window.print();
}

function editOriginalQuotation() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) return;
    
    const booking = JSON.parse(bookingData);
    if (booking.full_data) {
        localStorage.setItem('currentQuotation', JSON.stringify(booking.full_data));
        if (booking.full_data.quotation_type === 'service') {
            loadContent('quotation-service');
        } else {
            loadContent('quotation-itinerary');
        }
    } else {
        showNotification('Original quotation data not available', 'error');
    }
}

function generateVoucher() {
    showNotification('Voucher generation coming soon', 'info');
}

function printConfirmation() {
    window.print();
}

function saveBookingNotes() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) {
        showNotification('No booking loaded', 'error');
        return;
    }
    
    const booking = JSON.parse(bookingData);
    const notesEl = document.getElementById('bookingNotes');
    
    if (notesEl) {
        booking.booking_notes = notesEl.value;
        
        // Update in localStorage
        localStorage.setItem('currentBooking', JSON.stringify(booking));
        
        // Update in bookingsList
        updateBookingInList(booking);
        
        showNotification('Notes saved', 'success');
    }
}

function sendConfirmationEmail() {
    showNotification('Email feature coming soon', 'info');
}

// ==========================================
// Print Confirmation Page Functions
// ==========================================

function printConfirmation() {
    // Navigate to print confirmation page
    loadContent('print-confirmation');
}

function initPrintConfirmation() {
    console.log('📄 Initializing Print Confirmation page');
    
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) {
        showNotification('No booking data found', 'error');
        loadContent('booking');
        return;
    }
    
    const booking = JSON.parse(bookingData);
    const fullData = booking.full_data || {};
    
    // Format date helper
    const formatDate = (dateStr) => {
        if (!dateStr) return '-';
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return '-';
        return date.toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' });
    };
    
    // Set confirmation date
    const confDateEl = document.getElementById('printConfirmationDate');
    if (confDateEl) confDateEl.textContent = new Date().toLocaleDateString('en-US', { day: '2-digit', month: 'long', year: 'numeric' });
    
    // Booking Reference
    const bookingRefEl = document.getElementById('printBookingRef');
    if (bookingRefEl) bookingRefEl.textContent = booking.booking_id || '-';
    
    // Header Info
    setElementText('printBookingNo', booking.booking_id || '-');
    setElementText('printDate', new Date().toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' }));
    setElementText('printQuoteRef', booking.quotation_number || '-');
    
    // Customer Information
    setElementText('printCustomerName', booking.customer_name || fullData.customer_name || '-');
    setElementText('printContactPerson', fullData.contact_person || '-');
    setElementText('printEmail', fullData.email || '-');
    setElementText('printPhone', fullData.phone || '-');
    
    // Tour Details
    setElementText('printTourName', booking.tour_name || fullData.tour_name || '-');
    setElementText('printDestination', booking.destination || fullData.destination || '-');
    
    // Travel dates with duration
    const startDate = booking.travel_date || fullData.travel_date;
    const endDate = booking.end_date || fullData.end_date;
    const duration = booking.duration || fullData.duration || '';
    let dateText = '-';
    if (startDate && endDate) {
        dateText = `${formatDate(startDate)} - ${formatDate(endDate)}`;
        if (duration) dateText += ` (${duration})`;
    }
    setElementText('printTravelDates', dateText);
    
    const pax = booking.pax_count || fullData.pax || '-';
    setElementText('printPaxCount', pax + ' Passengers');
    
    // Tour Guides
    renderPrintGuides(booking.guides || []);
    
    // Hotels
    renderPrintHotels(booking.hotels || []);
    
    // Transportation
    renderPrintTransports(booking.transports || []);
    
    // Itinerary
    renderPrintItinerary(fullData.itinerary || [], booking);
    
    // Restaurants
    renderPrintRestaurants(booking.restaurants || []);
}

function setElementText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

function renderPrintGuides(guides) {
    const tbody = document.getElementById('printGuidesTable');
    if (!tbody) return;
    
    if (guides.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="empty-state">No guides assigned</td></tr>';
        return;
    }
    
    tbody.innerHTML = guides.map(g => `
        <tr>
            <td class="editable" contenteditable="true">${g.name || '-'}</td>
            <td class="editable" contenteditable="true">${Array.isArray(g.languages) ? g.languages.join(', ') : g.languages || g.language || '-'}</td>
            <td class="editable" contenteditable="true">${g.phone || '-'}</td>
            <td class="editable" contenteditable="true">${g.startDate || '-'} → ${g.endDate || '-'}</td>
        </tr>
    `).join('');
}

function renderPrintHotels(hotels) {
    const tbody = document.getElementById('printHotelsTable');
    if (!tbody) return;
    
    if (hotels.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No hotels booked</td></tr>';
        return;
    }
    
    tbody.innerHTML = hotels.map(h => {
        const statusClass = h.status === 'confirmed' ? 'status-confirmed' : 'status-pending';
        const statusText = h.status === 'confirmed' ? 'Confirmed' : 'Pending';
        // Build room type string
        const roomTypes = [];
        if (h.room_twn > 0) roomTypes.push(`${h.room_twn} TWN`);
        if (h.room_dbl > 0) roomTypes.push(`${h.room_dbl} DBL`);
        if (h.room_sgl > 0) roomTypes.push(`${h.room_sgl} SGL`);
        if (h.room_trp > 0) roomTypes.push(`${h.room_trp} TRP`);
        if (h.room_other > 0) roomTypes.push(`${h.room_other} Other`);
        const roomStr = roomTypes.length > 0 ? roomTypes.join(', ') : '-';
        return `
            <tr>
                <td class="editable" contenteditable="true">${h.name || '-'}</td>
                <td class="editable" contenteditable="true">${roomStr}</td>
                <td class="editable" contenteditable="true">${h.checkIn || h.startDate || '-'}</td>
                <td class="editable" contenteditable="true">${h.checkOut || h.endDate || '-'}</td>
                <td class="editable" contenteditable="true">${h.confirmation_no || '-'}</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
            </tr>
        `;
    }).join('');
}

function renderPrintTransports(transports) {
    const tbody = document.getElementById('printTransportsTable');
    if (!tbody) return;
    
    if (transports.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No transport arranged</td></tr>';
        return;
    }
    
    tbody.innerHTML = transports.map(t => `
        <tr>
            <td class="editable" contenteditable="true">${t.vehicle_type || '-'}</td>
            <td class="editable" contenteditable="true">${t.company || '-'}</td>
            <td class="editable" contenteditable="true">${t.driver || '-'}</td>
            <td class="editable" contenteditable="true">${t.phone || '-'}</td>
            <td class="editable" contenteditable="true">${t.days || '-'}</td>
        </tr>
    `).join('');
}

function renderPrintItinerary(itinerary, booking) {
    const container = document.getElementById('printItineraryContent');
    if (!container) return;
    
    if (!itinerary || itinerary.length === 0) {
        container.innerHTML = '<div class="empty-state">No itinerary available</div>';
        return;
    }
    
    // Format date helper
    const formatDateShort = (dateStr) => {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return '';
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    };
    
    // Calculate date for each day based on travel date
    const travelDate = booking?.travel_date || booking?.full_data?.travel_date;
    
    container.innerHTML = itinerary.map((day, index) => {
        const dayNum = day.day || index + 1;
        let dayDate = day.date || '';
        
        // Calculate date if travel date exists
        if (travelDate && !dayDate) {
            const baseDate = new Date(travelDate);
            baseDate.setDate(baseDate.getDate() + index);
            dayDate = formatDateShort(baseDate);
        }
        
        // Get hotel for this day
        const hotel = booking?.hotels?.find(h => {
            // Match by day number or date range
            return true; // Show first hotel for simplicity
        });
        const hotelName = hotel ? hotel.name : '';
        
        return `
            <div class="itinerary-day">
                <div class="day-header">
                    <span class="day-badge">Day ${dayNum}</span>
                    <span class="day-date editable" contenteditable="true">${dayDate}</span>
                    <span class="day-title editable" contenteditable="true">Day ${dayNum}</span>
                </div>
                <div class="day-activities editable" contenteditable="true">${day.activities || day.description || day.title || '-'}</div>
                ${hotelName ? `<div class="day-hotel editable" contenteditable="true"><i class="fas fa-hotel"></i> ${hotelName}</div>` : ''}
            </div>
        `;
    }).join('');
}

function renderPrintRestaurants(restaurants) {
    const tbody = document.getElementById('printRestaurantsTable');
    if (!tbody) return;
    
    if (restaurants.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No meals planned</td></tr>';
        return;
    }
    
    tbody.innerHTML = restaurants.map(r => `
        <tr>
            <td class="editable" contenteditable="true">${r.name || '-'}</td>
            <td class="editable" contenteditable="true">${r.date || '-'}</td>
            <td class="editable" contenteditable="true">${r.meal_type || 'Lunch'}</td>
            <td class="editable" contenteditable="true">${r.cuisine || '-'}</td>
            <td class="editable" contenteditable="true">${r.pax || '-'}</td>
        </tr>
    `).join('');
}

function toggleSection(sectionId, isVisible) {
    const section = document.getElementById(sectionId);
    if (section) {
        if (isVisible) {
            section.classList.remove('hidden-print');
        } else {
            section.classList.add('hidden-print');
        }
    }
}

function goBackToBooking() {
    loadContent('booking-confirmation');
}

// Print Options Modal Functions
function openPrintOptions() {
    const overlay = document.getElementById('printOptionsOverlay');
    const modal = document.getElementById('printOptionsModal');
    if (overlay) overlay.classList.add('active');
    if (modal) modal.classList.add('active');
}

function closePrintOptions() {
    const overlay = document.getElementById('printOptionsOverlay');
    const modal = document.getElementById('printOptionsModal');
    if (overlay) overlay.classList.remove('active');
    if (modal) modal.classList.remove('active');
}

function toggleOptionItem(item) {
    const checkbox = item.querySelector('input[type="checkbox"]');
    if (checkbox.checked) {
        item.classList.add('checked');
    } else {
        item.classList.remove('checked');
    }
}

function togglePrintSection(sectionId, isVisible) {
    const section = document.getElementById(sectionId);
    if (section) {
        if (isVisible) {
            section.classList.remove('hidden-print');
            section.style.display = '';
        } else {
            section.classList.add('hidden-print');
            section.style.display = 'none';
        }
    }
}

function toggleEditMode() {
    const container = document.querySelector('.print-page');
    if (!container) {
        showNotification('Edit mode not available on this page', 'info');
        return;
    }
    
    const isEditing = container.classList.contains('editing-mode');
    const editBtn = document.querySelector('.print-action-btn:nth-child(2)');
    
    if (isEditing) {
        container.classList.remove('editing-mode');
        if (editBtn) {
            editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit';
            editBtn.style.background = 'white';
            editBtn.style.color = '#374151';
            editBtn.style.border = '1px solid #e5e7eb';
        }
        // Disable contenteditable highlight
        container.querySelectorAll('[contenteditable="true"]').forEach(el => {
            el.style.outline = '';
            el.style.background = '';
        });
        showNotification('Edit mode disabled', 'info');
    } else {
        container.classList.add('editing-mode');
        if (editBtn) {
            editBtn.innerHTML = '<i class="fas fa-check"></i> Done';
            editBtn.style.background = '#10b981';
            editBtn.style.color = 'white';
            editBtn.style.border = 'none';
        }
        // Highlight editable fields
        container.querySelectorAll('[contenteditable="true"]').forEach(el => {
            el.style.outline = '2px dashed #3b82f6';
            el.style.background = '#eff6ff';
        });
        showNotification('Click on any field to edit', 'info');
    }
}

function downloadConfirmationPDF() {
    const printElement = document.getElementById('printableConfirmation');
    if (!printElement) {
        showNotification('Print content not found', 'error');
        return;
    }
    
    // Check if html2pdf is loaded
    if (typeof html2pdf === 'undefined') {
        showNotification('Loading PDF generator...', 'info');
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
        script.onload = () => generateConfirmationPDF(printElement);
        script.onerror = () => {
            showNotification('Could not load PDF library. Using Print instead.', 'error');
            window.print();
        };
        document.head.appendChild(script);
    } else {
        generateConfirmationPDF(printElement);
    }
}

function generateConfirmationPDF(element) {
    const bookingNo = document.getElementById('printBookingNo')?.textContent || 'confirmation';
    const filename = `${bookingNo}.pdf`;
    
    showNotification('Generating PDF...', 'info');
    
    const opt = {
        margin: 10,
        filename: filename,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, letterRendering: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };
    
    html2pdf().set(opt).from(element).save().then(() => {
        showNotification('PDF downloaded successfully!', 'success');
    }).catch(err => {
        console.error('PDF generation error:', err);
        showNotification('Error generating PDF. Using Print instead.', 'error');
        window.print();
    });
}

function printConfirmationDoc() {
    window.print();
}

// Make print confirmation functions globally accessible
window.initPrintConfirmation = initPrintConfirmation;
window.toggleSection = toggleSection;
window.goBackToBooking = goBackToBooking;

// ==========================================
// Quotation by Service Page Functions
// ==========================================
let serviceItemCounter = 1;

function initQuoteServicePage() {
    try {
        // Check for saved quotation data (editing mode)
        const savedData = localStorage.getItem('currentQuotation');
        if (savedData) {
            const data = JSON.parse(savedData);
            console.log('Loading saved service quotation:', data.quotation_number);
            
            // Wait a bit for DOM to be ready, then populate
            setTimeout(() => {
                populateServiceForm(data);
            }, 100);
            
            return;
        }
        
        // New quotation - set defaults
        const today = new Date();
        const validDate = new Date(today);
        validDate.setMonth(validDate.getMonth() + 1);
        
        const quotationDate = document.getElementById('quotationDate');
        const validUntil = document.getElementById('validUntil');
        
        if (quotationDate) quotationDate.value = formatDateForInput(today);
        if (validUntil) validUntil.value = formatDateForInput(validDate);
        
        // Generate quotation number
        const quotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const quotationNumber = document.getElementById('quotationNumber');
        const displayQuoteId = document.getElementById('displayQuoteId');
        if (quotationNumber) quotationNumber.value = quotationNo;
        if (displayQuoteId) displayQuoteId.textContent = quotationNo;
        
        // Add input listeners to existing items
        const priceInputs = document.querySelectorAll('.item-price, .item-qty');
        priceInputs.forEach(input => {
            input.addEventListener('input', calculateServiceTotal);
        });
        
        // Add listener to pax count
        const paxInput = document.getElementById('paxCount');
        if (paxInput) {
            paxInput.addEventListener('input', calculateServiceTotal);
        }
        
        // Reset counter
        serviceItemCounter = document.querySelectorAll('.service-item').length || 1;
        
    } catch (err) {
        console.error('Error in initQuoteServicePage:', err);
    }
}

// Add new service item
function addServiceItem() {
    serviceItemCounter++;
    const container = document.getElementById('serviceItemsContainer');
    
    const itemHtml = `
        <div class="service-item" data-item="${serviceItemCounter}">
            <div class="service-item-header">
                <span class="item-number">Item ${serviceItemCounter}</span>
                <button type="button" class="btn-remove-item" onclick="removeServiceItem(this)" title="Remove">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
            <div class="service-item-body">
                <div class="form-grid cols-4">
                    <div class="form-group col-span-2">
                        <label>Description</label>
                        <input type="text" class="item-description" placeholder="Service description">
                    </div>
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" class="item-qty" value="1" min="1" oninput="calculateServiceTotal()">
                    </div>
                    <div class="form-group">
                        <label>Unit Price (USD)</label>
                        <input type="number" class="item-price" placeholder="0.00" step="0.01" oninput="calculateServiceTotal()">
                    </div>
                </div>
            </div>
        </div>
    `;
    
    container.insertAdjacentHTML('beforeend', itemHtml);
}

// Remove service item
function removeServiceItem(btn) {
    const item = btn.closest('.service-item');
    if (document.querySelectorAll('.service-item').length > 1) {
        item.remove();
        renumberServiceItems();
        calculateServiceTotal();
    } else {
        showNotification('At least one service item is required', 'warning');
    }
}

// Renumber service items
function renumberServiceItems() {
    const items = document.querySelectorAll('.service-item');
    items.forEach((item, index) => {
        item.dataset.item = index + 1;
        item.querySelector('.item-number').textContent = `Item ${index + 1}`;
    });
    serviceItemCounter = items.length;
}

// Calculate service total
// ==========================================
// COST ESTIMATION FORMULAS:
// ==========================================
// 1. SUBTOTAL = Σ (Quantity × Unit Price) for all service items
// 2. SGL SUPPLEMENT = SGL Room Count × SGL Rate per Room
// 3. AFTER SGL = SUBTOTAL + SGL SUPPLEMENT
// 4. HANDLING FEE = AFTER SGL × (Handling Fee % / 100)
// 5. AFTER HANDLING = AFTER SGL + HANDLING FEE
// 6. DISCOUNT = AFTER HANDLING × (Discount % / 100)
// 7. AFTER DISCOUNT = AFTER HANDLING - DISCOUNT
// 8. TAX = AFTER DISCOUNT × (Tax % / 100)
// 9. GRAND TOTAL = AFTER DISCOUNT + TAX
// 10. PER PERSON = GRAND TOTAL / Number of Passengers
// ==========================================
function calculateServiceTotal() {
    const items = document.querySelectorAll('.service-item');
    let subtotal = 0;
    
    // Step 1: Calculate Subtotal (sum of all service items)
    items.forEach(item => {
        const qty = parseFloat(item.querySelector('.item-qty').value) || 0;
        const price = parseFloat(item.querySelector('.item-price').value) || 0;
        subtotal += qty * price;
    });
    
    // Get optional fee values (only apply if row is visible)
    const sglChargeRow = document.getElementById('sglChargeRow');
    const handlingFeeRow = document.getElementById('handlingFeeRow');
    const discountRow = document.getElementById('discountRow');
    const taxRow = document.getElementById('taxRow');
    
    // Step 2: SGL Supplement calculation
    const sglCount = (sglChargeRow && sglChargeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('sglChargeCount')?.value) || 0) : 0;
    const sglRate = (sglChargeRow && sglChargeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('sglChargeAmount')?.value) || 0) : 0;
    const sglTotal = sglCount * sglRate;
    
    // Step 3: After SGL
    const afterSgl = subtotal + sglTotal;
    
    // Step 4 & 5: Handling Fee calculation
    const handlingFeePercent = (handlingFeeRow && handlingFeeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('handlingFeePercent')?.value) || 0) : 0;
    const handlingFeeAmount = afterSgl * (handlingFeePercent / 100);
    const afterHandling = afterSgl + handlingFeeAmount;
    
    // Step 6 & 7: Discount calculation
    const discountPercent = (discountRow && discountRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('discountPercent')?.value) || 0) : 0;
    const discountAmount = afterHandling * (discountPercent / 100);
    const afterDiscount = afterHandling - discountAmount;
    
    // Step 8: Tax calculation
    const taxPercent = (taxRow && taxRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('taxPercent')?.value) || 0) : 0;
    const taxAmount = afterDiscount * (taxPercent / 100);
    
    // Step 9: Grand Total
    const grandTotal = afterDiscount + taxAmount;
    
    // Step 10: Per Person
    const paxCount = parseInt(document.getElementById('paxCount')?.value) || 1;
    const perPersonUSD = grandTotal / paxCount;
    
    // Format numbers
    const formatUSD = (num) => '$' + num.toFixed(2);
    
    // Update display
    const subtotalEl = document.getElementById('subtotalAmount');
    const sglTotalEl = document.getElementById('sglTotalAmount');
    const handlingEl = document.getElementById('handlingFeeAmount');
    const discountEl = document.getElementById('discountAmount');
    const taxEl = document.getElementById('taxAmount');
    const grandTotalEl = document.getElementById('grandTotalUSD');
    const perPersonEl = document.getElementById('perPersonUSD');
    const paxDisplayEl = document.getElementById('paxDisplay');
    
    if (subtotalEl) subtotalEl.textContent = formatUSD(subtotal);
    if (sglTotalEl) sglTotalEl.textContent = formatUSD(sglTotal);
    if (handlingEl) handlingEl.textContent = formatUSD(handlingFeeAmount);
    if (discountEl) discountEl.textContent = '-' + formatUSD(discountAmount);
    if (taxEl) taxEl.textContent = formatUSD(taxAmount);
    if (grandTotalEl) grandTotalEl.textContent = formatUSD(grandTotal);
    if (perPersonEl) perPersonEl.textContent = formatUSD(perPersonUSD);
    if (paxDisplayEl) paxDisplayEl.textContent = paxCount;
}

// Toggle fee row visibility
function toggleFeeRow(rowId, show) {
    const row = document.getElementById(rowId);
    if (row) {
        row.style.display = show ? 'flex' : 'none';
        calculateServiceTotal();
    }
}

// Populate the service quotation summary page with saved data
function populateServiceSummaryPage() {
    const savedData = localStorage.getItem('currentQuotation');
    if (!savedData) return;
    
    const data = JSON.parse(savedData);
    
    // Helper function
    const setTextById = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value || '';
    };
    
    // Format date for display
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    };
    
    // Format USD
    const formatUSD = (num) => '$' + (parseFloat(num) || 0).toFixed(2);
    
    // Header info
    setTextById('printQuoteNo', data.quotation_number);
    setTextById('printQuoteDate', formatDate(data.quotation_date));
    setTextById('printValidUntil', formatDate(data.valid_until));
    setTextById('summaryQuoteId', data.quotation_number);
    
    // Customer info
    setTextById('printCustomerName', data.customer_name);
    setTextById('printNationality', data.nationality ? `Nationality: ${data.nationality}` : '');
    setTextById('printCustomerEmail', data.customer_email);
    setTextById('printCustomerPhone', data.customer_phone);
    
    // Service details
    setTextById('printServiceType', data.service_type || 'Service Quotation');
    if (data.service_date) {
        setTextById('printServiceDates', `Service Date: ${formatDate(data.service_date)}`);
    }
    if (data.pax_count) {
        setTextById('printPax', `${data.pax_count} Person(s)`);
        setTextById('printPaxCount', data.pax_count);
    }
    
    // Populate service items
    const itemsContainer = document.getElementById('printServiceItems');
    if (itemsContainer && data.service_items && data.service_items.length > 0) {
        itemsContainer.innerHTML = '';
        data.service_items.forEach((item, index) => {
            const qty = parseFloat(item.qty) || 0;
            const price = parseFloat(item.price) || 0;
            const amount = qty * price;
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${item.description || '-'}</td>
                <td class="text-center">${qty}</td>
                <td class="text-right">${formatUSD(price)}</td>
                <td class="text-right">${formatUSD(amount)}</td>
            `;
            itemsContainer.appendChild(row);
        });
    }
    
    // Pricing summary
    setTextById('printSubtotal', formatUSD(data.subtotal));
    
    // SGL Supplement
    if (data.sgl_count && parseFloat(data.sgl_count) > 0) {
        document.getElementById('printSglRow').style.display = '';
        setTextById('printSglCount', data.sgl_count);
        setTextById('printSglRate', parseFloat(data.sgl_rate).toFixed(2));
        setTextById('printSglTotal', formatUSD(data.sgl_total));
    }
    
    // Handling fee
    if (data.handling_fee_percent && parseFloat(data.handling_fee_percent) > 0) {
        document.getElementById('printHandlingRow').style.display = '';
        setTextById('printHandlingPercent', data.handling_fee_percent);
        setTextById('printHandlingAmount', formatUSD(data.handling_fee_amount));
    }
    
    // Discount
    if (data.discount_percent && parseFloat(data.discount_percent) > 0) {
        document.getElementById('printDiscountRow').style.display = '';
        setTextById('printDiscountPercent', data.discount_percent);
        setTextById('printDiscountAmount', '-' + formatUSD(data.discount_amount));
    }
    
    // Tax
    if (data.tax_percent && parseFloat(data.tax_percent) > 0) {
        document.getElementById('printTaxRow').style.display = '';
        setTextById('printTaxPercent', data.tax_percent);
        setTextById('printTaxAmount', formatUSD(data.tax_amount));
    }
    
    // Grand total and per person
    setTextById('printGrandTotal', formatUSD(data.grand_total));
    setTextById('printPerPerson', formatUSD(data.per_person));
    
    // Notes
    if (data.notes && data.notes.trim()) {
        document.getElementById('notesSection').style.display = '';
        setTextById('printNotes', data.notes);
    }
    
    // Terms
    if (data.terms && data.terms.trim()) {
        const termsEl = document.getElementById('printTerms');
        if (termsEl) {
            termsEl.innerHTML = `<div style="white-space: pre-line;">${data.terms}</div>`;
        }
    }
}

// Edit service quotation
function editServiceQuotation() {
    const savedData = localStorage.getItem('currentQuotation');
    if (savedData) {
        loadContent('quotation-service');
        // TODO: Populate form with saved data after page loads
    } else {
        showNotification('No quotation data found', 'error');
    }
}

// Populate the quotation summary page with saved data
function populateSummaryPage() {
    const savedData = localStorage.getItem('currentQuotation');
    if (!savedData) return;
    
    const data = JSON.parse(savedData);
    
    // Update quote info
    const setTextById = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value || '';
    };
    
    // Format date for display
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    };
    
    // Header info
    setTextById('printQuoteNo', data.quotation_number);
    setTextById('printQuoteDate', formatDate(data.quotation_date));
    setTextById('printValidUntil', formatDate(data.valid_until));
    
    // Also update the page header quote ID
    setTextById('summaryQuoteId', data.quotation_number);
    
    // Customer info
    setTextById('printCustomerName', data.customer_name);
    setTextById('printCustomerContact', data.contact_person);
    setTextById('printCustomerEmail', data.customer_email);
    setTextById('printCustomerPhone', data.customer_phone);
    
    // Tour details
    setTextById('printTourName', data.tour_name);
    setTextById('printDestination', data.destination);
    
    // Travel dates
    if (data.travel_date && data.num_days) {
        const startDate = new Date(data.travel_date);
        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + parseInt(data.num_days) - 1);
        const dateRange = `${formatDate(data.travel_date)} - ${formatDate(endDate.toISOString())} (${data.num_days} Days)`;
        setTextById('printTravelDates', dateRange);
    } else {
        setTextById('printTravelDates', '');
    }
    
    if (data.pax_count) {
        setTextById('printPax', `${data.pax_count} Passengers`);
    } else {
        setTextById('printPax', '');
    }
    
    // Populate itinerary with complete information
    const itineraryContainer = document.getElementById('printItinerary');
    if (itineraryContainer) {
        itineraryContainer.innerHTML = '';
        if (data.itinerary && data.itinerary.length > 0) {
            data.itinerary.forEach((day, index) => {
                const dayDate = day.date ? formatDate(day.date) : '';
                const activities = day.activities ? day.activities.join(' - ') : '';
                const meals = [];
                if (day.meals?.breakfast) meals.push('Breakfast');
                if (day.meals?.lunch) meals.push('Lunch');
                if (day.meals?.dinner) meals.push('Dinner');
                
                // Build hotel info string
                let hotelInfo = '';
                if (day.hotel) {
                    hotelInfo = day.hotel;
                    if (day.room_type) hotelInfo += ` (${day.room_type})`;
                }
                
                // Build meals string with icon
                let mealsHtml = '';
                if (meals.length > 0) {
                    mealsHtml = `<span class="detail-item"><i class="fas fa-utensils"></i> Meals: ${meals.join(', ')}</span>`;
                }
                
                const dayHtml = `
                    <div class="itinerary-day">
                        <div class="day-header">
                            <span class="day-badge">Day ${index + 1}</span>
                            <span class="day-date">${dayDate}</span>
                            <span class="day-title">${day.title || 'Day ' + (index + 1)}</span>
                        </div>
                        <div class="day-content">
                            <p class="day-description">${activities || 'Activities to be confirmed'}</p>
                            <div class="day-details">
                                ${hotelInfo ? `<span class="detail-item"><i class="fas fa-hotel"></i> ${hotelInfo}</span>` : ''}
                                ${mealsHtml}
                            </div>
                        </div>
                    </div>
                `;
                itineraryContainer.innerHTML += dayHtml;
            });
        }
    }
    
    // Populate optional activities if any - HIDE if no data
    const optionalSection = document.getElementById('optionalSection');
    const optionalContainer = document.getElementById('printOptionalActivities');
    if (optionalSection) {
        if (optionalContainer && data.optional_activities && Array.isArray(data.optional_activities) && data.optional_activities.length > 0) {
            optionalSection.style.display = 'block';
            optionalContainer.innerHTML = '';
            data.optional_activities.forEach(activity => {
                const li = document.createElement('li');
                li.textContent = activity.name + (activity.price ? ` - $${activity.price}` : '');
                optionalContainer.appendChild(li);
            });
        } else {
            // Hide if no optional activities
            optionalSection.style.display = 'none';
        }
    }
    
    // Populate notes if any
    const notesSection = document.getElementById('notesSection');
    const notesContainer = document.getElementById('printNotes');
    if (notesContainer && data.notes && data.notes.trim() !== '') {
        notesSection.style.display = 'block';
        notesContainer.innerHTML = `<p>${data.notes}</p>`;
    } else if (notesSection) {
        notesSection.style.display = 'none';
    }
    
    // Populate pricing table with complete information
    const pricingContainer = document.getElementById('printPricing');
    console.log('Pricing data:', data.pricing); // Debug log
    
    if (pricingContainer) {
        pricingContainer.innerHTML = '';
        
        if (data.pricing && Array.isArray(data.pricing) && data.pricing.length > 0) {
            data.pricing.forEach(p => {
                // Priority: sellingUSD > sellPriceUSD > price_usd
                let priceUSD = '-';
                
                // Check sellingUSD first (user input from Selling USD column)
                if (p.sellingUSD !== undefined && p.sellingUSD !== null && p.sellingUSD !== '') {
                    const numVal = parseFloat(String(p.sellingUSD).replace(/[^0-9.]/g, ''));
                    if (!isNaN(numVal)) {
                        priceUSD = '$' + numVal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                    }
                }
                // Fallback to sellPriceUSD (calculated Price USD column)
                if (priceUSD === '-' && p.sellPriceUSD) {
                    const numVal = parseFloat(String(p.sellPriceUSD).replace(/[^0-9.$]/g, ''));
                    if (!isNaN(numVal) && numVal > 0) {
                        priceUSD = '$' + numVal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                    } else {
                        priceUSD = p.sellPriceUSD;
                    }
                }
                
                // Format SGL charge
                let sglCharge = '-';
                if (p.sglCharge && p.sglCharge !== '' && p.sglCharge !== '-') {
                    const sglVal = parseFloat(String(p.sglCharge).replace(/[^0-9.]/g, ''));
                    if (!isNaN(sglVal) && sglVal > 0) {
                        sglCharge = '$' + sglVal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                    }
                }
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${p.pax} PAX</td>
                    <td class="text-center">${priceUSD}</td>
                    <td class="text-right">${sglCharge}</td>
                `;
                pricingContainer.appendChild(row);
            });
        } else {
            // No pricing data - show placeholder
            pricingContainer.innerHTML = `<tr><td colspan="3" class="text-center">Pricing to be confirmed</td></tr>`;
        }
    }
}

// Edit current quotation from summary page
function editCurrentQuotation() {
    const savedData = localStorage.getItem('currentQuotation');
    if (savedData) {
        loadContent('quotation-itinerary');
        // TODO: Populate form with saved data after page loads
    } else {
        showNotification('No quotation data found', 'error');
    }
}

// Confirm booking - convert quotation to booking
async function confirmBooking() {
    console.log('🔄 confirmBooking() called');
    
    let savedData;
    try {
        savedData = localStorage.getItem('currentQuotation');
        console.log('📦 currentQuotation data:', savedData ? 'Found' : 'Not found');
    } catch (e) {
        console.error('❌ localStorage error:', e);
        showNotification('Storage access blocked. Please disable tracking prevention.', 'error');
        return;
    }
    
    if (!savedData) {
        showNotification('No quotation data found', 'error');
        return;
    }
    
    const quotationData = JSON.parse(savedData);
    console.log('📋 Quotation:', quotationData.quotation_number);
    
    // Create booking from quotation
    const bookingId = 'BK-' + new Date().getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
    const today = new Date();
    
    const booking = {
        booking_id: bookingId,
        quotation_number: quotationData.quotation_number,
        customer_name: quotationData.customer_name,
        contact_person: quotationData.contact_person,
        customer_email: quotationData.customer_email,
        customer_phone: quotationData.customer_phone,
        nationality: quotationData.nationality || quotationData.customer_nationality || '',
        tour_name: quotationData.tour_name,
        destination: quotationData.destination,
        travel_date: quotationData.travel_date,
        end_date: quotationData.end_date || '',
        arrival_flight: quotationData.arrival_flight || '',
        departure_flight: quotationData.departure_flight || '',
        num_days: quotationData.num_days,
        pax_count: quotationData.pax_count || quotationData.number_of_passengers,
        tl_count: quotationData.tl_count || 1,
        pricing: quotationData.pricing,
        itinerary: quotationData.itinerary,
        status: 'confirmed',
        booking_date: today.toISOString(),
        created_at: today.toISOString(),
        full_data: quotationData
    };
    
    console.log('✅ Created booking object:', bookingId);
    
    // Save to bookings list (localStorage)
    try {
        let bookingsList = JSON.parse(localStorage.getItem('bookingsList') || '[]');
        bookingsList.unshift(booking);
        localStorage.setItem('bookingsList', JSON.stringify(bookingsList));
        console.log('💾 Saved to localStorage. Total bookings:', bookingsList.length);
    } catch (e) {
        console.error('❌ Failed to save to localStorage:', e);
    }
    
    // Update quotation status in localStorage
    try {
        let quotationsList = JSON.parse(localStorage.getItem('quotationsList') || '[]');
        const quotationIndex = quotationsList.findIndex(q => q.quotation_number === quotationData.quotation_number);
        if (quotationIndex !== -1) {
            quotationsList[quotationIndex].status = 'confirmed';
            localStorage.setItem('quotationsList', JSON.stringify(quotationsList));
            console.log('📝 Updated quotation status to confirmed');
        }
    } catch (e) {
        console.error('❌ Failed to update quotation status:', e);
    }
    
    // Also save to Supabase if available
    if (window.supabaseClient) {
        try {
            // Calculate total from pricing
            let totalAmount = 0;
            if (quotationData.pricing && quotationData.pricing.length > 0) {
                totalAmount = parseFloat(quotationData.pricing[0].sellPriceUSD) || 0;
            }
            
            const { error } = await window.supabaseClient
                .from('bookings')
                .insert({
                    booking_number: bookingId,
                    booking_date: today.toISOString().split('T')[0],
                    travel_start_date: quotationData.travel_date,
                    travel_end_date: quotationData.end_date || null,
                    number_of_passengers: quotationData.pax_count || quotationData.number_of_passengers || 1,
                    total_amount: totalAmount,
                    status: 'confirmed',
                    special_requests: JSON.stringify({
                        customer_name: quotationData.customer_name,
                        nationality: quotationData.nationality,
                        tour_name: quotationData.tour_name,
                        quotation_number: quotationData.quotation_number
                    })
                });
            
            if (error) {
                console.log('⚠️ Could not save to Supabase:', error.message);
            } else {
                console.log('✅ Booking saved to Supabase');
            }
            
            // Update quotation status in Supabase
            if (quotationData.quotation_number) {
                await window.supabaseClient
                    .from('quotations')
                    .update({ status: 'confirmed', confirmed_at: today.toISOString() })
                    .eq('quotation_number', quotationData.quotation_number);
            }
        } catch (err) {
            console.log('⚠️ Supabase error:', err.message);
        }
    }
    
    showNotification(`Booking confirmed! Booking ID: ${bookingId}`, 'success');
    
    // Redirect to bookings page
    setTimeout(() => {
        loadContent('booking');
    }, 1500);
}

// ==========================================
// Migrate localStorage to Supabase
// ==========================================
async function migrateLocalStorageToSupabase() {
    if (!window.supabaseClient || !db) {
        console.error('❌ Supabase not available');
        showNotification('Supabase not connected', 'error');
        return;
    }
    
    const quotationsList = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    
    if (quotationsList.length === 0) {
        console.log('📭 No quotations in localStorage to migrate');
        showNotification('No local data to migrate', 'info');
        return;
    }
    
    console.log(`🔄 Migrating ${quotationsList.length} quotations to Supabase...`);
    showNotification(`Migrating ${quotationsList.length} quotations...`, 'info');
    
    let successCount = 0;
    let errorCount = 0;
    
    for (const q of quotationsList) {
        try {
            // Get the full data (either from full_data property or the quotation itself)
            const quotationData = q.full_data || q;
            const isService = q.type === 'Service' || quotationData.quotation_type === 'service';
            
            if (isService) {
                const result = await db.saveQuotationService(quotationData, []);
                if (result.success) {
                    successCount++;
                    console.log(`✅ Migrated: ${q.quotation_number}`);
                } else {
                    errorCount++;
                    console.error(`❌ Failed: ${q.quotation_number}`, result.error);
                }
            } else {
                const result = await db.saveQuotationItinerary(
                    quotationData, 
                    quotationData.itinerary || [], 
                    quotationData.pricing || []
                );
                if (result.success) {
                    successCount++;
                    console.log(`✅ Migrated: ${q.quotation_number}`);
                } else {
                    errorCount++;
                    console.error(`❌ Failed: ${q.quotation_number}`, result.error);
                }
            }
        } catch (error) {
            errorCount++;
            console.error(`❌ Error migrating ${q.quotation_number}:`, error);
        }
    }
    
    console.log(`✅ Migration complete: ${successCount} success, ${errorCount} errors`);
    showNotification(`Migration complete: ${successCount} success, ${errorCount} errors`, successCount > 0 ? 'success' : 'error');
    
    // Reload the quotations list
    await loadQuotationsFromStorage();
}

// Force load from localStorage only (bypass Supabase)
function loadFromLocalStorageOnly() {
    const tbody = document.getElementById('quotationsBody');
    if (!tbody) {
        console.error('❌ quotationsBody not found');
        return;
    }
    
    // Check all possible localStorage keys
    console.log('🔍 Checking localStorage...');
    const quotationsList = localStorage.getItem('quotationsList');
    const currentQuotation = localStorage.getItem('currentQuotation');
    
    console.log('quotationsList:', quotationsList ? 'exists' : 'empty');
    console.log('currentQuotation:', currentQuotation ? 'exists' : 'empty');
    
    let savedQuotations = [];
    
    // Try quotationsList first
    if (quotationsList) {
        try {
            savedQuotations = JSON.parse(quotationsList);
            console.log(`📁 Found ${savedQuotations.length} quotations in quotationsList`);
        } catch (e) {
            console.error('Error parsing quotationsList:', e);
        }
    }
    
    // Also check currentQuotation
    if (currentQuotation) {
        try {
            const current = JSON.parse(currentQuotation);
            console.log('📄 Found currentQuotation:', current.quotation_number);
            
            // Add to list if not already there
            if (!savedQuotations.find(q => q.quotation_number === current.quotation_number)) {
                savedQuotations.unshift({
                    quotation_number: current.quotation_number,
                    program_name: current.tour_name || current.service_type || 'Untitled',
                    customer_name: current.customer_name || 'Unknown',
                    type: current.quotation_type === 'service' ? 'Service' : 'Itinerary',
                    sending_date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                    last_update: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                    status: current.status || 'draft',
                    full_data: current
                });
            }
        } catch (e) {
            console.error('Error parsing currentQuotation:', e);
        }
    }
    
    if (savedQuotations.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#64748b;">No quotations in localStorage. Try creating a new quotation first.</td></tr>';
        showNotification('No data found in localStorage', 'warning');
        return;
    }
    
    console.log(`📁 Displaying ${savedQuotations.length} quotations from localStorage`);
    displayQuotations(savedQuotations);
    showNotification(`Loaded ${savedQuotations.length} quotations from local storage`, 'success');
}

// Load saved quotations from localStorage into the table
async function loadQuotationsFromStorage() {
    const tbody = document.getElementById('quotationsBody');
    if (!tbody) {
        console.log('⚠️ quotationsBody not found - not on quotations page');
        return;
    }
    
    try {
        // Show loading state
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:20px;"><i class="fas fa-spinner fa-spin"></i> Loading quotations...</td></tr>';
        
        // Check Supabase availability
        console.log('🔍 Checking Supabase connection...');
        console.log('  - window.supabaseClient:', !!window.supabaseClient);
        console.log('  - db object:', !!db);
        console.log('  - db.getAllQuotations:', !!(db && db.getAllQuotations));
        
        // Try to load from Supabase first
        if (window.supabaseClient && db && db.getAllQuotations) {
            console.log('🔄 Connecting to Supabase...');
            try {
                const result = await db.getAllQuotations();
                console.log('📥 Supabase result:', result);
                
                if (result.success && result.data && result.data.length > 0) {
                    console.log(`✅ Loaded ${result.data.length} quotations from Supabase`);
                    
                    // Sync Supabase data to localStorage so copy/delete/highlight work
                    localStorage.setItem('quotationsList', JSON.stringify(result.data));
                    console.log('💾 Synced Supabase data to localStorage');
                    
                    displayQuotations(result.data);
                    return;
                } else if (result.error) {
                    console.error('❌ Supabase error:', result.error);
                } else {
                    console.log('📭 No quotations found in Supabase, checking localStorage...');
                }
            } catch (supabaseError) {
                console.error('❌ Supabase query failed:', supabaseError);
            }
        } else {
            console.log('⚠️ Supabase not available, using localStorage');
        }
        
        // Fallback to localStorage
        console.log('📁 Loading from localStorage...');
        const savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
        
        if (savedQuotations.length === 0) {
            // Also check currentQuotation
            const current = localStorage.getItem('currentQuotation');
            if (current) {
                const currentData = JSON.parse(current);
                console.log('📄 Found currentQuotation:', currentData.quotation_number);
                displayQuotations([{
                    quotation_number: currentData.quotation_number,
                    program_name: currentData.tour_name || currentData.service_type || 'Untitled',
                    customer_name: currentData.customer_name || 'Unknown',
                    type: currentData.quotation_type === 'service' ? 'Service' : 'Itinerary',
                    status: currentData.status || 'draft',
                    full_data: currentData
                }]);
                return;
            }
            
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#64748b;">No quotations yet. Create your first quotation!</td></tr>';
            return;
        }
        
        console.log(`📁 Loaded ${savedQuotations.length} quotations from localStorage`);
        displayQuotations(savedQuotations);
        
    } catch (error) {
        console.error('❌ Error loading quotations:', error);
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:40px;color:#ef4444;">Error loading: ${error.message}</td></tr>`;
    }
}

// Helper function to display quotations in the table
function displayQuotations(quotations) {
    console.log('📋 displayQuotations called with', quotations.length, 'items');
    
    const tbody = document.getElementById('quotationsBody');
    if (!tbody) {
        console.error('❌ quotationsBody not found!');
        return;
    }
    
    // Sort by last_update date descending (latest first)
    quotations.sort((a, b) => {
        const dateA = new Date(a.last_update || a.updated_at || a.sending_date || a.created_at || 0);
        const dateB = new Date(b.last_update || b.updated_at || b.sending_date || b.created_at || 0);
        return dateB - dateA;
    });
    
    // Clear existing rows first
    tbody.innerHTML = '';
    
    if (quotations.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#64748b;">No quotations yet. Create your first quotation!</td></tr>';
        return;
    }
    
    console.log('📋 Adding', quotations.length, 'rows to table...');
    
    // Add quotations to the table
    quotations.forEach((q, index) => {
        // Handle both Supabase format and localStorage format
        const programName = q.program_name || q.tour_name || q.service_type || 'Untitled';
        const customerName = q.customer_name || 'Unknown Customer';
        const quotationType = q.type || q.quotation_type || 'Itinerary';
        const sendingDate = q.sending_date || (q.created_at ? new Date(q.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '-');
        const lastUpdate = q.last_update || (q.updated_at ? new Date(q.updated_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : sendingDate);
        
        console.log(`  Row ${index + 1}: ${q.quotation_number} - ${programName}`);
        
        // Check if this quotation has been converted to a booking
        const bookingsList = JSON.parse(localStorage.getItem('bookingsList') || '[]');
        const isBooked = bookingsList.some(b => b.quotation_number === q.quotation_number);
        
        // Create new row
        const row = document.createElement('tr');
        row.dataset.status = q.status || 'draft';
        row.dataset.quotation = q.quotation_number;
        
        // Add green left border if booked
        if (isBooked) {
            row.style.cssText = 'border-left:4px solid #22c55e;background:#f0fdf4;';
        }
        
        row.innerHTML = `
            <td class="qt-number"><a href="#" class="qt-link" onclick="viewQuotation('${q.quotation_number}'); return false;">${q.quotation_number}</a></td>
            <td class="program-name">${programName}</td>
            <td>${customerName}</td>
            <td><span class="type-badge-sm ${quotationType.toLowerCase()}">${quotationType}</span></td>
            <td>${sendingDate}</td>
            <td>${lastUpdate}</td>
            <td>
                <select class="status-dropdown ${q.status || 'draft'}" onchange="updateQuotationStatus(this)">
                    <option value="draft" ${q.status === 'draft' ? 'selected' : ''}>Draft</option>
                    <option value="pending" ${q.status === 'pending' ? 'selected' : ''}>Pending</option>
                    <option value="sent" ${q.status === 'sent' ? 'selected' : ''}>Sent</option>
                    <option value="confirmed" ${q.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                    <option value="cancelled" ${q.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                </select>
            </td>
            <td class="action-btns">
                <button class="icon-btn small highlight-btn" title="Highlight" onclick="highlightQuotation(this, '${q.quotation_number}')"><i class="fas fa-highlighter"></i></button>
                <button class="icon-btn small" title="Copy" onclick="copyQuotation('${q.quotation_number}')"><i class="fas fa-copy"></i></button>
                <button class="icon-btn small delete-btn" title="Delete" onclick="deleteQuotation('${q.quotation_number}')"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // Update filter counts
    updateFilterCounts();
}

// Booking functions moved to booking.html inline script

// View quotation details
async function viewQuotation(quotationNumber) {
    // First try localStorage
    const savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    let quotation = savedQuotations.find(q => q.quotation_number === quotationNumber);
    
    // If not in localStorage or no full_data, try Supabase
    if ((!quotation || !quotation.full_data) && window.supabaseClient) {
        console.log('🔍 Quotation not in localStorage, checking Supabase...');
        try {
            const { data } = await window.supabaseClient
                .from('quotations')
                .select('*')
                .eq('quotation_number', quotationNumber)
                .single();
            
            if (data && data.full_data) {
                console.log('✅ Found quotation in Supabase with full_data');
                quotation = { full_data: data.full_data };
            }
        } catch (e) {
            console.error('Supabase lookup failed:', e);
        }
    }
    
    if (quotation && quotation.full_data) {
        localStorage.setItem('currentQuotation', JSON.stringify(quotation.full_data));
        
        // Navigate to appropriate summary based on quotation type
        if (quotation.full_data.quotation_type === 'service') {
            loadContent('quotation-service-summary');
        } else {
            loadContent('quotation-summary');
        }
    }
}

// Edit quotation
async function editQuotation(quotationNumber) {
    // First try localStorage
    const savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    let quotation = savedQuotations.find(q => q.quotation_number === quotationNumber);
    
    // If not in localStorage or no full_data, try Supabase
    if ((!quotation || !quotation.full_data) && window.supabaseClient && db) {
        console.log('🔍 Quotation not in localStorage, checking Supabase...');
        try {
            const { data, error } = await window.supabaseClient
                .from('quotations')
                .select('*')
                .eq('quotation_number', quotationNumber)
                .single();
            
            if (data && data.full_data) {
                console.log('✅ Found quotation in Supabase with full_data');
                quotation = { full_data: data.full_data, type: data.quotation_type };
            }
        } catch (e) {
            console.error('Supabase lookup failed:', e);
        }
    }
    
    if (quotation && quotation.full_data) {
        // Store the full data for the form to load
        localStorage.setItem('currentQuotation', JSON.stringify(quotation.full_data));
        
        console.log('Editing quotation:', quotationNumber);
        console.log('Data:', quotation.full_data);
        
        // Navigate to appropriate form based on quotation type
        if (quotation.full_data.quotation_type === 'service' || quotation.type === 'Service') {
            loadContent('quotation-service');
        } else {
            loadContent('quotation-itinerary');
        }
    } else {
        showNotification('Quotation data not found. It may not have been saved properly.', 'error');
        console.error('Quotation not found or missing full_data:', quotationNumber, quotation);
    }
}

// Highlight quotation row
function highlightQuotation(btn, quotationNumber) {
    const row = btn.closest('tr');
    if (row) {
        row.classList.toggle('highlighted');
        btn.classList.toggle('active');
        
        // Save highlight state
        let highlights = JSON.parse(localStorage.getItem('quotationHighlights') || '[]');
        if (row.classList.contains('highlighted')) {
            if (!highlights.includes(quotationNumber)) highlights.push(quotationNumber);
        } else {
            highlights = highlights.filter(q => q !== quotationNumber);
        }
        localStorage.setItem('quotationHighlights', JSON.stringify(highlights));
    }
}

// Copy quotation
// Track if copy is in progress to prevent duplicate copies
let copyInProgress = false;

async function copyQuotation(quotationNumber) {
    // Prevent duplicate copies if already in progress
    if (copyInProgress) {
        console.log('Copy already in progress, ignoring...');
        return;
    }
    copyInProgress = true;
    
    try {
        const savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
        const quotation = savedQuotations.find(q => q.quotation_number === quotationNumber);
        
        if (quotation) {
            // Create a copy with new quotation number
            const today = new Date();
            const newQuotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
            
            // Check if this quotation number already exists (prevent duplicates)
            if (savedQuotations.some(q => q.quotation_number === newQuotationNo)) {
                console.log('Quotation number already exists, skipping...');
                copyInProgress = false;
                return;
            }
            
            const copiedQuotation = JSON.parse(JSON.stringify(quotation));
            copiedQuotation.quotation_number = newQuotationNo;
            copiedQuotation.sending_date = today.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
            copiedQuotation.last_update = copiedQuotation.sending_date;
            copiedQuotation.program_name = quotation.program_name + ' (Copy)';
            copiedQuotation.status = 'draft';
            
            if (copiedQuotation.full_data) {
                copiedQuotation.full_data.quotation_number = newQuotationNo;
                copiedQuotation.full_data.tour_name = quotation.program_name + ' (Copy)';
                copiedQuotation.full_data.status = 'draft';
            }
            
            // Add to localStorage list
            savedQuotations.unshift(copiedQuotation);
            localStorage.setItem('quotationsList', JSON.stringify(savedQuotations));
            
            // Save to Supabase if available
            if (window.supabaseClient && db && copiedQuotation.full_data) {
                try {
                    const isServiceQuotation = copiedQuotation.full_data.quotation_type === 'service';
                    if (isServiceQuotation) {
                        await db.saveQuotationService(copiedQuotation.full_data, []);
                    } else {
                        await db.saveQuotationItinerary(copiedQuotation.full_data, copiedQuotation.full_data.itinerary || [], copiedQuotation.full_data.pricing || []);
                    }
                    console.log('✅ Copied quotation saved to Supabase:', newQuotationNo);
                } catch (error) {
                    console.error('Error saving copied quotation to Supabase:', error);
                }
            }
            
            showNotification('Quotation copied: ' + newQuotationNo, 'success');
            
            // Refresh the quotations list display
            setTimeout(() => {
                loadContent('quotations');
                copyInProgress = false;
            }, 200);
        } else {
            showNotification('Could not find quotation to copy', 'error');
            copyInProgress = false;
        }
    } catch (error) {
        console.error('Error copying quotation:', error);
        copyInProgress = false;
    }
}

// Delete quotation
function deleteQuotation(quotationNumber) {
    if (!confirm('Are you sure you want to delete quotation ' + quotationNumber + '?')) {
        return;
    }
    
    let savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    savedQuotations = savedQuotations.filter(q => q.quotation_number !== quotationNumber);
    localStorage.setItem('quotationsList', JSON.stringify(savedQuotations));
    
    // Remove from DOM
    const row = document.querySelector(`tr[data-quotation="${quotationNumber}"]`);
    if (row) {
        row.remove();
    }
    
    showNotification('Quotation deleted: ' + quotationNumber, 'success');
    
    // Update filter counts
    updateFilterCounts();
}

// ==========================================
// Quotation Page Functions (New Design)
// ==========================================
let dayCounter = 1;

function initQuotePage() {
    try {
        // Check for saved quotation data (editing mode)
        const savedData = localStorage.getItem('currentQuotation');
        if (savedData) {
            const data = JSON.parse(savedData);
            console.log('Loading saved quotation:', data.quotation_number);
            
            // Wait a bit for DOM to be ready, then populate
            setTimeout(() => {
                populateItineraryForm(data);
            }, 100);
            
            // Don't clear yet - will be cleared after successful population
            return;
        }
        
        // New quotation - set default values
        const today = new Date();
        const validDate = new Date(today);
        validDate.setMonth(validDate.getMonth() + 1); // 1 month after quote date
        
        // Set dates
        const qDate = document.getElementById('quotationDate');
        const vDate = document.getElementById('validUntil');
        const tDate = document.getElementById('travelDate');
        
        if (qDate) qDate.value = formatDateForInput(today);
        if (vDate) vDate.value = formatDateForInput(validDate);
        if (tDate) tDate.value = formatDateForInput(today);
        
        // Generate quote number
        const quoteNum = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const qNumField = document.getElementById('quotationNumber');
        const qNumDisplay = document.getElementById('displayQuoteId');
        if (qNumField) qNumField.value = quoteNum;
        if (qNumDisplay) qNumDisplay.textContent = quoteNum;
        
        // Set first day date
        const firstDayDate = document.querySelector('.itinerary-day .day-date');
        if (firstDayDate) {
            firstDayDate.value = formatDateForInput(today);
            updateDayDisplay(firstDayDate);
        }
        
        dayCounter = document.querySelectorAll('.itinerary-day').length || 1;
    } catch (err) {
        console.error('Error in initQuotePage:', err);
    }
}

function formatDateForInput(date) {
    return date.toISOString().split('T')[0];
}

function getDayName(dateStr) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[new Date(dateStr).getDay()];
}

function updateDayDisplay(input) {
    if (!input) return;
    const daySpan = input.parentElement?.querySelector('.day-name');
    if (input.value && daySpan) {
        daySpan.textContent = getDayName(input.value);
    }
}

function toggleMealDetail(checkbox, type) {
    const row = checkbox.closest('.day-row');
    if (!row) return;
    const detailInput = row.querySelector('.meal-' + type + '-detail');
    if (detailInput) {
        detailInput.disabled = !checkbox.checked;
        if (!checkbox.checked) detailInput.value = '';
    }
}

function addActivity(btn) {
    const container = btn.closest('.activities-container');
    if (!container) return;
    const items = container.querySelectorAll('.activity-item');
    const newNum = items.length + 1;
    
    const newItem = document.createElement('div');
    newItem.className = 'activity-item';
    newItem.innerHTML = `
        <span class="activity-num">${newNum}</span>
        <input type="text" class="activity-input" placeholder="Enter activity or sightseeing">
        <button type="button" class="activity-remove-btn" onclick="removeActivity(this)">
            <i class="fas fa-minus"></i>
        </button>
    `;
    container.appendChild(newItem);
}

function removeActivity(btn) {
    const item = btn.closest('.activity-item');
    const container = item?.closest('.activities-container');
    if (container && container.querySelectorAll('.activity-item').length > 1) {
        item.remove();
        container.querySelectorAll('.activity-item').forEach((el, i) => {
            el.querySelector('.activity-num').textContent = i + 1;
        });
    }
}

function addNewDay() {
    const container = document.getElementById('itineraryDays');
    if (!container) return;
    const days = container.querySelectorAll('.itinerary-day');
    dayCounter = days.length + 1;
    
    let nextDate = new Date();
    if (days.length > 0) {
        const lastDate = days[days.length - 1].querySelector('.day-date')?.value;
        if (lastDate) {
            nextDate = new Date(lastDate);
            nextDate.setDate(nextDate.getDate() + 1);
        }
    }
    
    const dayHtml = `
        <div class="itinerary-day" data-day="${dayCounter}">
            <div class="day-header-row">
                <div class="day-number">Day ${dayCounter}</div>
                <div class="day-date-input">
                    <input type="date" class="day-date" value="${formatDateForInput(nextDate)}" onchange="updateDayDisplay(this)">
                    <span class="day-name">${getDayName(nextDate)}</span>
                </div>
                <input type="text" class="day-title" placeholder="Day title">
                <button type="button" class="remove-day-btn" onclick="removeDay(this)" title="Remove Day">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
            <div class="day-content">
                <div class="day-row">
                    <div class="row-label"><i class="fas fa-bed"></i> Hotel</div>
                    <div class="row-inputs">
                        <input type="text" class="hotel-input" placeholder="Hotel name">
                        <select class="star-select">
                            <option value="">Rating</option>
                            <option value="2">2 Star</option>
                            <option value="3">3 Star</option>
                            <option value="4">4 Star</option>
                            <option value="5">5 Star</option>
                        </select>
                        <input type="text" class="room-type" placeholder="or similar">
                    </div>
                </div>
                <div class="day-row">
                    <div class="row-label"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="row-inputs meals-inputs">
                        <label class="meal-check">
                            <input type="checkbox" class="meal-b" onchange="toggleMealDetail(this, 'b')">
                            <span class="meal-badge">B</span>
                        </label>
                        <input type="text" class="meal-detail meal-b-detail" placeholder="Breakfast" disabled>
                        <label class="meal-check">
                            <input type="checkbox" class="meal-l" onchange="toggleMealDetail(this, 'l')">
                            <span class="meal-badge">L</span>
                        </label>
                        <input type="text" class="meal-detail meal-l-detail" placeholder="Lunch" disabled>
                        <label class="meal-check">
                            <input type="checkbox" class="meal-d" onchange="toggleMealDetail(this, 'd')">
                            <span class="meal-badge">D</span>
                        </label>
                        <input type="text" class="meal-detail meal-d-detail" placeholder="Dinner" disabled>
                    </div>
                </div>
                <div class="day-row activities-row">
                    <div class="row-label"><i class="fas fa-hiking"></i> Activities</div>
                    <div class="activities-container">
                        <div class="activity-item">
                            <span class="activity-num">1</span>
                            <input type="text" class="activity-input" placeholder="Enter activity">
                            <button type="button" class="activity-add-btn" onclick="addActivity(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', dayHtml);
}

function removeDay(btn) {
    const day = btn.closest('.itinerary-day');
    const container = document.getElementById('itineraryDays');
    if (container && container.querySelectorAll('.itinerary-day').length > 1) {
        day.remove();
        container.querySelectorAll('.itinerary-day').forEach((el, i) => {
            el.dataset.day = i + 1;
            el.querySelector('.day-number').textContent = 'Day ' + (i + 1);
        });
    }
}

// ==========================================
// COST ESTIMATION FUNCTIONS
// ==========================================

// Toggle category collapse
function toggleCategory(header) {
    const category = header.closest('.cost-category');
    if (category) {
        category.classList.toggle('collapsed');
    }
}

// Cost category configurations
const costConfigs = {
    hotel: {
        tableId: 'hotelTable',
        totalId: 'hotelTotal',
        template: `
            <td><input type="number" class="cost-day" value="1" min="1"></td>
            <td><input type="date" class="cost-date"></td>
            <td><input type="text" class="cost-name" placeholder="Hotel name"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('hotel')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('hotel')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'hotel')"><i class="fas fa-times"></i></button></td>
        `
    },
    meal: {
        tableId: 'mealTable',
        totalId: 'mealTotal',
        template: `
            <td><input type="number" class="cost-day" value="1" min="1"></td>
            <td><input type="date" class="cost-date"></td>
            <td>
                <select class="cost-type">
                    <option value="B">Breakfast</option>
                    <option value="L">Lunch</option>
                    <option value="D">Dinner</option>
                    <option value="O">Other</option>
                </select>
            </td>
            <td><input type="text" class="cost-name" placeholder="Meal description"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('meal')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('meal')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'meal')"><i class="fas fa-times"></i></button></td>
        `
    },
    admission: {
        tableId: 'admissionTable',
        totalId: 'admissionTotal',
        template: `
            <td><input type="number" class="cost-day" value="1" min="1"></td>
            <td><input type="date" class="cost-date"></td>
            <td><input type="text" class="cost-name" placeholder="Admission/Transfer"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('admission')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('admission')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'admission')"><i class="fas fa-times"></i></button></td>
        `
    },
    transport: {
        tableId: 'transportTable',
        totalId: 'transportTotal',
        template: `
            <td><input type="number" class="cost-day" value="1" min="1"></td>
            <td><input type="date" class="cost-date"></td>
            <td><input type="text" class="cost-name" placeholder="Bus/Van/Flight"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('transport')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('transport')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'transport')"><i class="fas fa-times"></i></button></td>
        `
    },
    guide: {
        tableId: 'guideTable',
        totalId: 'guideTotal',
        template: `
            <td>
                <select class="cost-type">
                    <option value="guide">Guide</option>
                    <option value="driver">Driver</option>
                    <option value="leader">Tour Leader</option>
                </select>
            </td>
            <td><input type="text" class="cost-name" placeholder="Service fee"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('guide')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('guide')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'guide')"><i class="fas fa-times"></i></button></td>
        `
    },
    other: {
        tableId: 'otherTable',
        totalId: 'otherTotal',
        template: `
            <td><input type="text" class="cost-name" placeholder="Other expense"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('other')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('other')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'other')"><i class="fas fa-times"></i></button></td>
        `
    }
};

// Add row to cost category
function addCostRow(category) {
    const config = costConfigs[category];
    if (!config) return;
    
    const table = document.getElementById(config.tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    const rows = tbody.querySelectorAll('tr');
    
    // Get the last row's date and day to auto-increment
    let lastDate = null;
    let lastDay = 1;
    if (rows.length > 0) {
        const lastRow = rows[rows.length - 1];
        const lastDateInput = lastRow.querySelector('.cost-date');
        const lastDayInput = lastRow.querySelector('.cost-day');
        if (lastDateInput && lastDateInput.value) {
            lastDate = new Date(lastDateInput.value);
        }
        if (lastDayInput && lastDayInput.value) {
            lastDay = parseInt(lastDayInput.value) || 1;
        }
    }
    
    const row = document.createElement('tr');
    row.innerHTML = config.template;
    tbody.appendChild(row);
    
    // Auto-set next day date for categories with date fields
    if ((category === 'hotel' || category === 'meal' || category === 'admission' || category === 'transport') && lastDate) {
        const nextDate = new Date(lastDate);
        nextDate.setDate(nextDate.getDate() + 1);
        const dateInput = row.querySelector('.cost-date');
        if (dateInput) {
            dateInput.value = nextDate.toISOString().split('T')[0];
        }
        // Increment the day number
        const dayInput = row.querySelector('.cost-day');
        if (dayInput) {
            dayInput.value = lastDay + 1;
        }
    }
}

// Remove cost row
function removeCostRow(btn, category) {
    const row = btn.closest('tr');
    const tbody = row?.closest('tbody');
    if (tbody && tbody.querySelectorAll('tr').length > 1) {
        row.remove();
        calcCategoryTotal(category);
    }
}

// Calculate category total
function calcCategoryTotal(category) {
    const config = costConfigs[category];
    if (!config) return;
    
    const table = document.getElementById(config.tableId);
    if (!table) return;
    
    let categoryTotal = 0;
    
    table.querySelectorAll('tbody tr').forEach(row => {
        const price = parseFloat(row.querySelector('.cost-price')?.value) || 0;
        const qty = parseFloat(row.querySelector('.cost-qty')?.value) || 1;
        const rowTotal = price * qty;
        
        const totalCell = row.querySelector('.cost-row-total');
        if (totalCell) totalCell.textContent = formatKRW(rowTotal);
        
        categoryTotal += rowTotal;
    });
    
    const totalEl = document.getElementById(config.totalId);
    if (totalEl) totalEl.textContent = formatKRW(categoryTotal);
    
    // Recalculate overall totals
    calcPricing();
}

// Calculate all pricing
function calcPricing() {
    // Group costs (divided by PAX later)
    const transportTotal = parseKRW(document.getElementById('transportTotal')?.textContent);
    const guideTotal = parseKRW(document.getElementById('guideTotal')?.textContent);
    const otherTotal = parseKRW(document.getElementById('otherTotal')?.textContent);
    
    // Per-person costs
    const hotelTotal = parseKRW(document.getElementById('hotelTotal')?.textContent);
    const mealTotal = parseKRW(document.getElementById('mealTotal')?.textContent);
    const admissionTotal = parseKRW(document.getElementById('admissionTotal')?.textContent);
    
    // Total Group Cost = Transport + Guide + Other
    const totalGroupCost = transportTotal + guideTotal + otherTotal;
    
    // Cost Per Person Base = (Hotel/2) + Meals + Admission
    const costPerPersonBase = (hotelTotal / 2) + mealTotal + admissionTotal;
    
    // Store costs for PAX calculation
    window.tourCosts = {
        totalGroupCost,       // Transport + Guide + Other (will be divided by PAX)
        costPerPersonBase,    // (Hotel/2) + Meals + Admission (per person)
        hotelTotal,
        mealTotal,
        admissionTotal,
        transportTotal,
        guideTotal,
        otherTotal
    };
    
    // Update summary
    // Cost Per Person in summary = (Hotel/2) + Meals + Admission (base only, no group cost)
    document.getElementById('totalGroupCost').textContent = formatKRW(totalGroupCost);
    document.getElementById('costPerPerson').textContent = formatKRW(costPerPersonBase);
    
    // Update PAX table
    calcPaxPricing();
}

// Mark SGL input as edited when user changes it
function markSglEdited(input) {
    input.dataset.edited = 'true';
}

// Update PAX row when PAX number or FOC changes
function updatePaxRow(input) {
    const row = input.closest('tr');
    if (!row) return;
    
    const paxInput = row.querySelector('.pax-number-input');
    if (paxInput) {
        row.dataset.pax = paxInput.value;
    }
    
    // Recalculate pricing
    calcPaxPricing();
}

// Calculate PAX-based pricing
// ==========================================
// COST ESTIMATION FORMULAS (Quotation with Itinerary):
// ==========================================
// 1. Total Group Cost = Transport + Guide + Other
// 2. Cost Per Person Base = (Hotel/2) + Meals + Admission
// 3. Group Cost (column) = Total Group Cost / PAX (divided by each row's PAX)
// 4. Cost Per Person = Cost Per Person Base + Group Cost (column)
// 5. Profit Amount = Cost Per Person × (Profit Margin % ÷ 100)
// 6. Selling Price (KRW) = Cost Per Person + Profit Amount
// 7. Selling Price (USD) = Selling Price (KRW) ÷ Currency Rate
// 8. SGL Charge = ((Hotel Total / 2) - 10%) / Currency Rate
// ==========================================
function calcPaxPricing() {
    if (!window.tourCosts) return;
    
    const profitMargin = parseFloat(document.getElementById('profitMargin')?.value) || 10;
    const currencyRate = parseFloat(document.getElementById('currencyRate')?.value) || 1350;
    
    // Auto-calculate SGL Charge: ((Hotel Total / 2) - 10%) / Currency Rate
    // = ((Hotel/2) * 90%) / Currency Rate
    const hotelTotal = window.tourCosts.hotelTotal || 0;
    const autoSglCharge = Math.round(((hotelTotal / 2) * 0.9) / currencyRate);
    
    const paxRows = document.querySelectorAll('#paxBody tr');
    
    // Total Group Cost = Transport + Guide + Other
    const totalGroupCost = window.tourCosts.totalGroupCost || 0;
    
    // Cost Per Person Base = (Hotel/2) + Meals + Admission (already calculated in calcPricing)
    const costPerPersonBase = window.tourCosts.costPerPersonBase || 0;
    
    paxRows.forEach(row => {
        // Get PAX from input or data attribute
        const paxInput = row.querySelector('.pax-number-input');
        const plusInput = row.querySelector('.pax-plus-input');
        const pax = paxInput ? parseInt(paxInput.value) || 10 : parseInt(row.dataset.pax) || 10;
        const plusOne = plusInput ? parseInt(plusInput.value) || 0 : 1; // FOC/Tour leader
        
        // Update data-pax attribute
        row.dataset.pax = pax;
        
        // Group Cost = Total Group Cost / PAX (divided by paying passengers)
        const groupCost = pax > 0 ? totalGroupCost / pax : 0;
        
        // Cost per person = Cost Per Person Base + Group Cost
        const costPerPerson = costPerPersonBase + groupCost;
        
        // Profit amount
        const profit = costPerPerson * (profitMargin / 100);
        
        // Selling price in KRW
        const sellPriceKRW = costPerPerson + profit;
        
        // Selling price in USD
        const sellPriceUSD = sellPriceKRW / currencyRate;
        
        // Update row cells
        row.querySelector('.pax-group-cost').textContent = formatKRW(groupCost);
        row.querySelector('.pax-cost-pp').textContent = formatKRW(costPerPerson);
        row.querySelector('.pax-profit').textContent = formatKRW(profit);
        row.querySelector('.pax-sell-krw').textContent = formatKRW(sellPriceKRW);
        
        // Update Price USD (calculated from KRW)
        const priceUsdCell = row.querySelector('.pax-price-usd');
        if (priceUsdCell) {
            priceUsdCell.textContent = formatUSD(sellPriceUSD);
        }
        
        // Selling USD - auto-fill with calculated value if empty
        const sellUsdInput = row.querySelector('.pax-usd-input');
        if (sellUsdInput) {
            // If empty or 0, auto-fill with calculated USD price
            if (!sellUsdInput.value || sellUsdInput.value === '' || sellUsdInput.value === '0') {
                sellUsdInput.value = Math.round(sellPriceUSD);
            }
        }
        
        // SGL Charge - auto-calculate but allow edit
        const sglInput = row.querySelector('.pax-sgl-input');
        if (sglInput) {
            // Only set if empty (first time) or value is 0
            if (!sglInput.dataset.edited && (sglInput.value === '' || sglInput.value === '0')) {
                sglInput.value = autoSglCharge;
            }
        }
    });
}

// Add PAX row
function addPaxRow() {
    const tbody = document.getElementById('paxBody');
    if (!tbody) return;
    
    // Find the highest current PAX and add 5
    const rows = tbody.querySelectorAll('tr');
    let maxPax = 0;
    rows.forEach(row => {
        const pax = parseInt(row.dataset.pax) || 0;
        if (pax > maxPax) maxPax = pax;
    });
    const newPax = maxPax + 5;
    
    const row = document.createElement('tr');
    row.dataset.pax = newPax;
    row.innerHTML = `
        <td><span class="pax-number">${newPax}</span><span class="pax-plus">+1</span></td>
        <td class="pax-group-cost">฿0</td>
        <td class="pax-cost-pp">฿0</td>
        <td class="pax-profit">฿0</td>
        <td class="pax-sell-krw">฿0</td>
        <td class="pax-sell-usd">$0</td>
        <td><button type="button" class="cost-remove-btn" onclick="removePaxRow(this)"><i class="fas fa-times"></i></button></td>
    `;
    tbody.appendChild(row);
    calcPaxPricing();
}

// Remove PAX row
function removePaxRow(btn) {
    const row = btn.closest('tr');
    const tbody = row?.closest('tbody');
    if (tbody && tbody.querySelectorAll('tr').length > 1) {
        row.remove();
    }
}

// Format KRW currency (Korean Won)
function formatKRW(amount) {
    return '₩' + Math.round(amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Parse KRW string to number
function parseKRW(str) {
    if (!str) return 0;
    return parseFloat(str.replace(/[₩,]/g, '')) || 0;
}

// Format USD currency
function formatUSD(amount) {
    return '$' + amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Legacy function for backwards compatibility
function addPriceItem() {
    // Redirect to first cost category
    addCostRow('hotel');
}

function removePriceRow(btn) {
    removeCostRow(btn, 'other');
}

function calcRowTotal(input) {
    const row = input.closest('tr');
    const category = row?.closest('table')?.id?.replace('Table', '');
    if (category) calcCategoryTotal(category);
}

function calcTotals() {
    calcPricing();
}

function formatCurrency(amount) {
    return '$' + amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// ==========================================
// QUOTATION STATUS & FILTER FUNCTIONS
// ==========================================

// Current filter state
let currentStatusFilter = 'all';

// Update quotation status from dropdown
function updateQuotationStatus(select) {
    const newStatus = select.value;
    const row = select.closest('tr');
    const quotationNo = row?.querySelector('.qt-number')?.textContent;
    
    // Remove all status classes and add new one
    select.classList.remove('draft', 'pending', 'sent', 'confirmed', 'cancelled');
    select.classList.add(newStatus);
    
    // Update row data-status attribute
    if (row) row.dataset.status = newStatus;
    
    // Update last update column to today
    const cells = row?.querySelectorAll('td');
    if (cells && cells.length >= 6) {
        const today = new Date();
        const formattedDate = today.toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric', 
            year: 'numeric' 
        });
        cells[5].textContent = formattedDate; // Last Update column
    }
    
    // Update filter counts
    updateFilterCounts();
    
    // Re-apply current filter
    filterByStatus(currentStatusFilter);
    
    // Show notification
    showNotification(`Status updated to "${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)}" for ${quotationNo}`, 'success');
    
    // TODO: Save to database
    // db.updateQuotationStatus(quotationNo, newStatus);
}

// Filter by status
function filterByStatus(status) {
    currentStatusFilter = status;
    const rows = document.querySelectorAll('#quotationsBody tr');
    const filterCards = document.querySelectorAll('.filter-stat-card');
    
    // Update active filter card
    filterCards.forEach(card => {
        card.classList.remove('active');
        if (card.dataset.filter === status) {
            card.classList.add('active');
        }
    });
    
    // Filter rows
    rows.forEach(row => {
        const rowStatus = row.dataset.status;
        if (status === 'all' || rowStatus === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Update filter counts
function updateFilterCounts() {
    const rows = document.querySelectorAll('#quotationsBody tr');
    const counts = {
        all: 0,
        draft: 0,
        sent: 0,
        pending: 0,
        confirmed: 0,
        cancelled: 0
    };
    
    rows.forEach(row => {
        const status = row.dataset.status;
        counts.all++;
        if (counts.hasOwnProperty(status)) {
            counts[status]++;
        }
    });
    
    // Update count displays
    const countAll = document.getElementById('countAll');
    const countSent = document.getElementById('countSent');
    const countPending = document.getElementById('countPending');
    const countConfirmed = document.getElementById('countConfirmed');
    const countCancelled = document.getElementById('countCancelled');
    
    if (countAll) countAll.textContent = counts.all;
    if (countSent) countSent.textContent = counts.sent;
    if (countPending) countPending.textContent = counts.pending;
    if (countConfirmed) countConfirmed.textContent = counts.confirmed;
    if (countCancelled) countCancelled.textContent = counts.cancelled;
}

// Search/filter quotations by text
function filterQuotations() {
    const searchInput = document.getElementById('quotationSearch');
    const searchText = searchInput?.value.toLowerCase() || '';
    const rows = document.querySelectorAll('#quotationsBody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const matchesSearch = text.includes(searchText);
        const matchesStatus = currentStatusFilter === 'all' || row.dataset.status === currentStatusFilter;
        
        if (matchesSearch && matchesStatus) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// ==========================================
// QUOTATION SAVE FUNCTIONS
// ==========================================

// Store quotation data temporarily for summary page
let currentQuotationData = null;

// Apply travel dates to itinerary days
function applyDatesToItinerary() {
    const travelDateInput = document.getElementById('travelDate');
    const numDaysInput = document.getElementById('numDays');
    
    if (!travelDateInput || !numDaysInput) {
        showNotification('Please fill in Travel Date and Number of Days', 'warning');
        return;
    }
    
    const travelDate = travelDateInput.value;
    const numDays = parseInt(numDaysInput.value) || 1;
    
    if (!travelDate) {
        showNotification('Please select a travel date first', 'warning');
        return;
    }
    
    const startDate = new Date(travelDate);
    const daysContainer = document.getElementById('itineraryDays');
    
    if (!daysContainer) {
        showNotification('Itinerary section not found', 'error');
        return;
    }
    
    // Get existing day items
    let dayItems = daysContainer.querySelectorAll('.itinerary-day');
    
    // If we need more day items than exist, add them
    while (dayItems.length < numDays) {
        addNewDay(); // This function adds new itinerary days
        dayItems = daysContainer.querySelectorAll('.itinerary-day');
    }
    
    // Update each day with the correct date
    for (let i = 0; i < numDays && i < dayItems.length; i++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(startDate.getDate() + i);
        
        const dayItem = dayItems[i];
        const dayNumber = i + 1;
        
        // Format date for display (e.g., "Mon")
        const dayName = currentDate.toLocaleDateString('en-US', { weekday: 'short' });
        
        // Update the date input
        const dateInput = dayItem.querySelector('.day-date');
        if (dateInput) {
            dateInput.value = currentDate.toISOString().split('T')[0];
        }
        
        // Update day name display
        const dayNameSpan = dayItem.querySelector('.day-name');
        if (dayNameSpan) {
            dayNameSpan.textContent = dayName;
        }
        
        // Update day number display
        const dayNumEl = dayItem.querySelector('.day-number');
        if (dayNumEl) {
            dayNumEl.textContent = `Day ${dayNumber}`;
        }
        
        // Update the data attribute
        dayItem.dataset.day = dayNumber;
        
        // Show this day
        dayItem.style.display = '';
    }
    
    // Hide extra day items if there are more than numDays
    for (let i = numDays; i < dayItems.length; i++) {
        dayItems[i].style.display = 'none';
    }
    
    // Also set the first date to all Cost Estimation sections
    applyCostEstimationDates(travelDate, numDays);
    
    showNotification(`Itinerary updated with ${numDays} days starting from ${startDate.toLocaleDateString()}`, 'success');
}

// Apply travel date to all Cost Estimation date fields
function applyCostEstimationDates(startDateStr, numDays) {
    const startDate = new Date(startDateStr);
    
    // Set first row date for each cost category
    const costTables = ['hotelTable', 'mealTable', 'admissionTable', 'transportTable', 'guideTable', 'otherTable'];
    
    costTables.forEach(tableId => {
        const table = document.getElementById(tableId);
        if (table) {
            const firstRow = table.querySelector('tbody tr');
            if (firstRow) {
                const dateInput = firstRow.querySelector('.cost-date');
                if (dateInput) {
                    dateInput.value = startDateStr;
                }
                // Also set day 1
                const dayInput = firstRow.querySelector('.cost-day');
                if (dayInput) {
                    dayInput.value = 1;
                }
            }
        }
    });
}

// Update validUntil when quotationDate changes (1 month after)
function updateValidUntil() {
    const quotationDate = document.getElementById('quotationDate');
    const validUntil = document.getElementById('validUntil');
    
    if (quotationDate && quotationDate.value && validUntil) {
        const qDate = new Date(quotationDate.value);
        qDate.setMonth(qDate.getMonth() + 1);
        validUntil.value = qDate.toISOString().split('T')[0];
    }
}

// Save quotation (just save, stay on page)
async function saveQuotationDraft() {
    try {
        const btn = event?.target;
        const originalText = btn?.innerHTML;
        if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        
        // Detect quotation type based on current page content
        const isServiceQuotation = document.getElementById('serviceItemsContainer') !== null;
        
        // Collect form data
        if (isServiceQuotation) {
            currentQuotationData = collectServiceQuotationData();
            currentQuotationData.quotation_type = 'service';
        } else {
            currentQuotationData = collectQuotationFormData();
            currentQuotationData.quotation_type = 'itinerary';
        }
        
        // Store in localStorage for quick access
        localStorage.setItem('currentQuotation', JSON.stringify(currentQuotationData));
        
        // Save to both Supabase and localStorage
        await saveToQuotationsList(currentQuotationData, 'draft');
        
        // Simulate save delay
        await new Promise(resolve => setTimeout(resolve, 300));
        
        if (btn) btn.innerHTML = originalText;
        showNotification('Quotation saved successfully!', 'success');
        
    } catch (error) {
        console.error('Error saving quotation:', error);
        showNotification('Error saving quotation', 'error');
    }
}

// Save quotation data to the quotations list
async function saveToQuotationsList(quotationData, status = 'draft') {
    try {
        // Save to Supabase first if available
        if (window.supabaseClient && db) {
            console.log('Saving to Supabase...');
            
            const isServiceQuotation = quotationData.quotation_type === 'service';
            
            if (isServiceQuotation) {
                // Pass service_items as pricing items for Service quotations
                const serviceItems = quotationData.service_items || [];
                const pricingItems = serviceItems.map(item => ({
                    description: item.description,
                    quantity: item.qty,
                    unit: 'pcs',
                    rate: item.price,
                    amount: (item.qty || 0) * (item.price || 0)
                }));
                await db.saveQuotationService(quotationData, pricingItems);
            } else {
                await db.saveQuotationItinerary(quotationData, quotationData.itinerary || [], quotationData.pricing || []);
            }
            
            console.log('✅ Saved to Supabase:', quotationData.quotation_number);
        }
    } catch (error) {
        console.error('Error saving to Supabase:', error);
        console.log('Falling back to localStorage only');
    }
    
    // Also save to localStorage as backup
    let quotationsList = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    
    // Check if this quotation already exists
    const existingIndex = quotationsList.findIndex(q => q.quotation_number === quotationData.quotation_number);
    
    // Determine quotation type and display name
    const isServiceQuotation = quotationData.quotation_type === 'service';
    
    // Create quotation record for the list
    const quotationRecord = {
        quotation_number: quotationData.quotation_number,
        program_name: isServiceQuotation 
            ? (quotationData.service_type || 'Service Quotation')
            : (quotationData.tour_name || 'Untitled Tour'),
        customer_name: quotationData.customer_name || 'Unknown Customer',
        type: isServiceQuotation ? 'Service' : 'Itinerary',
        sending_date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        last_update: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        status: status,
        full_data: quotationData
    };
    
    if (existingIndex >= 0) {
        // Update existing - preserve original sending_date
        quotationRecord.sending_date = quotationsList[existingIndex].sending_date;
        quotationsList[existingIndex] = quotationRecord;
        console.log('Updated existing quotation in localStorage');
    } else {
        // Add new at the top
        quotationsList.unshift(quotationRecord);
        console.log('Added new quotation to localStorage');
    }
    
    // Save back to localStorage
    localStorage.setItem('quotationsList', JSON.stringify(quotationsList));
    
    console.log('✅ Saved to localStorage:', quotationData.quotation_number);
}

// Save and go to summary page
async function saveAndShowSummary() {
    try {
        const btn = event?.target;
        const originalText = btn?.innerHTML;
        if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        
        // Detect quotation type based on current page content
        const isServiceQuotation = document.getElementById('serviceItemsContainer') !== null;
        
        // Collect form data based on type
        if (isServiceQuotation) {
            currentQuotationData = collectServiceQuotationData();
            currentQuotationData.quotation_type = 'service';
        } else {
            currentQuotationData = collectQuotationFormData();
            currentQuotationData.quotation_type = 'itinerary';
        }
        
        // Store in localStorage
        localStorage.setItem('currentQuotation', JSON.stringify(currentQuotationData));
        
        // Also save to quotationsList for persistence (AWAIT)
        await saveToQuotationsList(currentQuotationData, 'sent');
        
        // Simulate save delay
        await new Promise(resolve => setTimeout(resolve, 300));
        
        if (btn) btn.innerHTML = originalText;
        showNotification('Quotation saved!', 'success');
        
        // Navigate to appropriate summary page
        if (isServiceQuotation) {
            loadContent('quotation-service-summary');
        } else {
            loadContent('quotation-summary');
        }
        
    } catch (error) {
        console.error('Error saving quotation:', error);
        showNotification('Error saving quotation', 'error');
    }
}

// Collect service quotation form data
function collectServiceQuotationData() {
    // Get pricing values
    const subtotal = parseFloat(document.getElementById('subtotalAmount')?.textContent?.replace(/[$,]/g, '')) || 0;
    const sglChargeRow = document.getElementById('sglChargeRow');
    const handlingFeeRow = document.getElementById('handlingFeeRow');
    const discountRow = document.getElementById('discountRow');
    const taxRow = document.getElementById('taxRow');
    
    // SGL Supplement
    const sglCount = (sglChargeRow && sglChargeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('sglChargeCount')?.value) || 0) : 0;
    const sglRate = (sglChargeRow && sglChargeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('sglChargeAmount')?.value) || 0) : 0;
    const sglTotal = parseFloat(document.getElementById('sglTotalAmount')?.textContent?.replace(/[$,]/g, '')) || 0;
    
    const handlingFeePercent = (handlingFeeRow && handlingFeeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('handlingFeePercent')?.value) || 0) : 0;
    const handlingFeeAmount = parseFloat(document.getElementById('handlingFeeAmount')?.textContent?.replace(/[$,]/g, '')) || 0;
    
    const discountPercent = (discountRow && discountRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('discountPercent')?.value) || 0) : 0;
    const discountAmount = parseFloat(document.getElementById('discountAmount')?.textContent?.replace(/[-$,]/g, '')) || 0;
    
    const taxPercent = (taxRow && taxRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('taxPercent')?.value) || 0) : 0;
    const taxAmount = parseFloat(document.getElementById('taxAmount')?.textContent?.replace(/[$,]/g, '')) || 0;
    
    const grandTotal = parseFloat(document.getElementById('grandTotalUSD')?.textContent?.replace(/[$,]/g, '')) || 0;
    const perPerson = parseFloat(document.getElementById('perPersonUSD')?.textContent?.replace(/[$,]/g, '')) || 0;
    
    // Collect service items
    const serviceItems = [];
    document.querySelectorAll('.service-item').forEach((item, index) => {
        serviceItems.push({
            item_no: index + 1,
            description: item.querySelector('.item-description')?.value || '',
            qty: parseFloat(item.querySelector('.item-qty')?.value) || 0,
            price: parseFloat(item.querySelector('.item-price')?.value) || 0
        });
    });
    
    return {
        quotation_type: 'service',
        quotation_number: document.getElementById('quotationNumber')?.value || 'QT-2025-0001',
        quotation_date: document.getElementById('quotationDate')?.value,
        valid_until: document.getElementById('validUntil')?.value,
        
        // Customer Info
        customer_name: document.getElementById('customerName')?.value,
        contact_person: document.getElementById('contactPerson')?.value,
        customer_email: document.getElementById('customerEmail')?.value,
        customer_phone: document.getElementById('customerPhone')?.value,
        nationality: document.getElementById('customerNationality')?.value,
        
        // Service Info
        tour_name: document.getElementById('serviceName')?.value || document.getElementById('serviceType')?.value,
        service_name: document.getElementById('serviceName')?.value,
        service_type: document.getElementById('serviceType')?.value,
        destination: document.getElementById('destination')?.value,
        service_date: document.getElementById('serviceDate')?.value,
        pax_count: parseInt(document.getElementById('paxCount')?.value) || 1,
        number_of_passengers: parseInt(document.getElementById('paxCount')?.value) || 1,
        
        // Service Items
        service_items: serviceItems,
        
        // Pricing
        subtotal: subtotal,
        sgl_count: sglCount,
        sgl_rate: sglRate,
        sgl_total: sglTotal,
        handling_fee_percent: handlingFeePercent,
        handling_fee_amount: handlingFeeAmount,
        discount_percent: discountPercent,
        discount_amount: discountAmount,
        tax_percent: taxPercent,
        tax_amount: taxAmount,
        grand_total: grandTotal,
        per_person: perPerson,
        
        // Notes & Terms
        notes: document.getElementById('quotationNotes')?.value || '',
        terms: document.getElementById('quotationTerms')?.value || '',
        
        // Timestamps
        created_at: new Date().toISOString(),
        status: 'draft'
    };
}

// Populate itinerary form with saved data (for editing)
function populateItineraryForm(data) {
    if (!data) {
        console.error('No data to populate');
        return;
    }
    
    console.log('Populating form with data:', data);
    
    // Helper to set input value
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el && val !== undefined && val !== null) {
            el.value = val;
        }
    };
    
    // Basic Info
    setVal('quotationNumber', data.quotation_number);
    setVal('quotationDate', data.quotation_date);
    setVal('validUntil', data.valid_until);
    
    // Update display ID
    const displayQuoteId = document.getElementById('displayQuoteId');
    if (displayQuoteId) displayQuoteId.textContent = data.quotation_number;
    
    // Customer Info
    setVal('customerName', data.customer_name);
    setVal('contactPerson', data.contact_person);
    setVal('customerEmail', data.customer_email);
    setVal('customerPhone', data.customer_phone);
    setVal('customerNationality', data.customer_nationality);
    
    // Tour Info
    setVal('tourName', data.tour_name);
    setVal('destination', data.destination);
    setVal('travelDate', data.travel_date);
    setVal('numDays', data.num_days);
    setVal('paxCount', data.pax_count);
    
    // Pricing settings
    setVal('profitMargin', data.profit_margin);
    setVal('currencyRate', data.currency_rate);
    
    // Notes and Terms
    setVal('quotationNotes', data.notes);
    setVal('quotationTerms', data.terms);
    
    // Inclusions and Exclusions
    setVal('inclusions', data.inclusions);
    setVal('exclusions', data.exclusions);
    
    // ========================================
    // RESTORE ITINERARY DAYS
    // ========================================
    if (data.itinerary && Array.isArray(data.itinerary) && data.itinerary.length > 0) {
        restoreItineraryDays(data.itinerary);
    }
    
    // ========================================
    // RESTORE COST ESTIMATION DATA
    // ========================================
    // Restore window.tourCosts for calculations
    if (data.costs && typeof data.costs === 'object') {
        window.tourCosts = data.costs;
        console.log('Restored window.tourCosts:', window.tourCosts);
    }
    
    // Restore cost table values if costTableData exists
    if (data.costTableData && typeof data.costTableData === 'object') {
        console.log('Restoring cost table data:', data.costTableData);
        restoreCostTables(data.costTableData);
    }
    
    // Setup event listeners for pricing calculation
    setupPricingListeners();
    
    // Initialize day counter
    dayCounter = document.querySelectorAll('.itinerary-day').length || 1;
    
    // Trigger pricing recalculation after a short delay to ensure DOM is ready
    setTimeout(() => {
        calcPricing();
        
        // After calculation, restore PAX pricing inputs (Selling USD, SGL)
        if (data.pricing && Array.isArray(data.pricing)) {
            restorePaxPricingInputs(data.pricing);
        }
    }, 100);
    
    // DO NOT clear localStorage here - keep data until user saves or navigates away
    // The data will be updated when user clicks Save
    
    console.log('Successfully loaded quotation:', data.quotation_number);
    showNotification('Quotation loaded for editing', 'success');
}

// Restore PAX pricing inputs (Selling USD, SGL charge)
function restorePaxPricingInputs(pricingData) {
    if (!pricingData || !Array.isArray(pricingData)) return;
    
    const paxRows = document.querySelectorAll('#paxBody tr');
    
    pricingData.forEach((p, index) => {
        const row = paxRows[index];
        if (!row) return;
        
        // Restore Selling (USD) input
        const sellUsdInput = row.querySelector('.pax-usd-input');
        if (sellUsdInput && p.sellingUSD) {
            sellUsdInput.value = p.sellingUSD;
        }
        
        // Restore SGL charge input
        const sglInput = row.querySelector('.pax-sgl-input');
        if (sglInput && p.sglCharge) {
            // Extract number from "$50" format
            const sglValue = p.sglCharge.replace(/[^0-9.]/g, '');
            if (sglValue && sglValue !== '0') {
                sglInput.value = sglValue;
                sglInput.dataset.edited = 'true';
            }
        }
    });
    
    console.log('Restored PAX pricing inputs');
}

// Restore itinerary days from saved data
function restoreItineraryDays(itinerary) {
    const container = document.getElementById('itineraryDays');
    if (!container) {
        console.error('itineraryDays container not found');
        return;
    }
    
    // Clear existing days
    container.innerHTML = '';
    
    itinerary.forEach((dayData, index) => {
        const dayNum = index + 1;
        
        // Build activities HTML
        let activitiesHtml = '';
        const activities = dayData.activities || [];
        if (activities.length === 0) {
            activitiesHtml = `
                <div class="activity-item">
                    <span class="activity-num">1</span>
                    <input type="text" class="activity-input" placeholder="Enter activity or sightseeing">
                    <button type="button" class="activity-add-btn" onclick="addActivity(this)">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            `;
        } else {
            activities.forEach((activity, actIndex) => {
                activitiesHtml += `
                    <div class="activity-item">
                        <span class="activity-num">${actIndex + 1}</span>
                        <input type="text" class="activity-input" value="${escapeHtml(activity)}" placeholder="Enter activity or sightseeing">
                        ${actIndex === activities.length - 1 ? 
                            `<button type="button" class="activity-add-btn" onclick="addActivity(this)"><i class="fas fa-plus"></i></button>` :
                            `<button type="button" class="activity-remove-btn" onclick="removeActivity(this)"><i class="fas fa-times"></i></button>`
                        }
                    </div>
                `;
            });
        }
        
        // Build day HTML
        const dayHtml = `
            <div class="itinerary-day" data-day="${dayNum}">
                <div class="day-header-row">
                    <div class="day-number">Day ${dayNum}</div>
                    <div class="day-date-input">
                        <input type="date" class="day-date" value="${dayData.date || ''}" onchange="updateDayDisplay(this)">
                        <span class="day-name">${dayData.date ? getDayName(new Date(dayData.date)) : '-'}</span>
                    </div>
                    <input type="text" class="day-title" value="${escapeHtml(dayData.title || '')}" placeholder="Day title (e.g., Arrival in Bangkok)">
                    <button type="button" class="remove-day-btn" onclick="removeDay(this)" title="Remove Day">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
                
                <div class="day-content">
                    <!-- Accommodation -->
                    <div class="day-row">
                        <div class="row-label">
                            <i class="fas fa-bed"></i> Hotel
                        </div>
                        <div class="row-inputs">
                            <input type="text" class="hotel-input" value="${escapeHtml(dayData.hotel || '')}" placeholder="Hotel name">
                            <select class="star-select">
                                <option value="">Rating</option>
                                <option value="2" ${dayData.hotel_rating === '2' ? 'selected' : ''}>2 Star</option>
                                <option value="3" ${dayData.hotel_rating === '3' ? 'selected' : ''}>3 Star</option>
                                <option value="4" ${dayData.hotel_rating === '4' ? 'selected' : ''}>4 Star</option>
                                <option value="5" ${dayData.hotel_rating === '5' ? 'selected' : ''}>5 Star</option>
                            </select>
                            <input type="text" class="room-type" value="${escapeHtml(dayData.room_type || '')}" placeholder="or similar">
                        </div>
                    </div>
                    
                    <!-- Meals -->
                    <div class="day-row">
                        <div class="row-label">
                            <i class="fas fa-utensils"></i> Meals
                        </div>
                        <div class="row-inputs meals-inputs">
                            <label class="meal-check">
                                <input type="checkbox" class="meal-b" ${dayData.meals?.breakfast ? 'checked' : ''} onchange="toggleMealDetail(this, 'b')">
                                <span class="meal-badge">B</span>
                            </label>
                            <input type="text" class="meal-detail meal-b-detail" value="${escapeHtml(dayData.breakfast_detail || '')}" placeholder="Breakfast at hotel" ${dayData.meals?.breakfast ? '' : 'disabled'}>
                            
                            <label class="meal-check">
                                <input type="checkbox" class="meal-l" ${dayData.meals?.lunch ? 'checked' : ''} onchange="toggleMealDetail(this, 'l')">
                                <span class="meal-badge">L</span>
                            </label>
                            <input type="text" class="meal-detail meal-l-detail" value="${escapeHtml(dayData.lunch_detail || '')}" placeholder="Lunch venue" ${dayData.meals?.lunch ? '' : 'disabled'}>
                            
                            <label class="meal-check">
                                <input type="checkbox" class="meal-d" ${dayData.meals?.dinner ? 'checked' : ''} onchange="toggleMealDetail(this, 'd')">
                                <span class="meal-badge">D</span>
                            </label>
                            <input type="text" class="meal-detail meal-d-detail" value="${escapeHtml(dayData.dinner_detail || '')}" placeholder="Dinner venue" ${dayData.meals?.dinner ? '' : 'disabled'}>
                        </div>
                    </div>
                    
                    <!-- Activities -->
                    <div class="day-row activities-row">
                        <div class="row-label">
                            <i class="fas fa-hiking"></i> Activities
                        </div>
                        <div class="activities-container">
                            ${activitiesHtml}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', dayHtml);
    });
    
    dayCounter = itinerary.length;
    console.log('Restored', itinerary.length, 'itinerary days');
}

// Restore cost tables from saved data
function restoreCostTables(costTableData) {
    // Categories to restore: hotel, meal, admission, transport, guide, other
    const categories = ['hotel', 'meal', 'admission', 'transport', 'guide', 'other'];
    
    categories.forEach(category => {
        const rows = costTableData[category];
        if (!rows || !Array.isArray(rows)) return;
        
        const tableId = category + 'Table';
        const table = document.getElementById(tableId);
        if (!table) return;
        
        const tbody = table.querySelector('tbody');
        if (!tbody) return;
        
        // Clear existing rows except first one
        while (tbody.rows.length > 1) {
            tbody.deleteRow(1);
        }
        
        // Populate first row or add new rows
        rows.forEach((rowData, index) => {
            let row;
            if (index === 0 && tbody.rows.length > 0) {
                row = tbody.rows[0];
            } else {
                // Add new row
                addCostRow(category);
                row = tbody.rows[tbody.rows.length - 1];
            }
            
            // Populate row
            if (row) {
                const dayInput = row.querySelector('.cost-day');
                const dateInput = row.querySelector('.cost-date');
                const nameInput = row.querySelector('.cost-name');
                const typeSelect = row.querySelector('.cost-type');
                const priceInput = row.querySelector('.cost-price');
                const qtyInput = row.querySelector('.cost-qty');
                
                if (dayInput && rowData.day) dayInput.value = rowData.day;
                if (dateInput && rowData.date) dateInput.value = rowData.date;
                if (nameInput && rowData.name) nameInput.value = rowData.name;
                if (typeSelect && rowData.type) typeSelect.value = rowData.type;
                if (priceInput && rowData.price) priceInput.value = rowData.price;
                if (qtyInput && rowData.qty) qtyInput.value = rowData.qty;
            }
        });
        
        // Recalculate category total
        calcCategoryTotal(category);
    });
    
    console.log('Restored cost table data');
}

// Helper function to escape HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Collect all form data
function collectQuotationFormData() {
    return {
        // Basic Info
        quotation_number: document.getElementById('quotationNumber')?.value || 'QT-2025-0001',
        quotation_date: document.getElementById('quotationDate')?.value,
        valid_until: document.getElementById('validUntil')?.value,
        
        // Customer Info
        customer_name: document.getElementById('customerName')?.value,
        contact_person: document.getElementById('contactPerson')?.value,
        customer_email: document.getElementById('customerEmail')?.value,
        customer_phone: document.getElementById('customerPhone')?.value,
        customer_nationality: document.getElementById('customerNationality')?.value?.toUpperCase(),
        
        // Tour Info
        tour_name: document.getElementById('tourName')?.value,
        destination: document.getElementById('destination')?.value,
        travel_date: document.getElementById('travelDate')?.value,
        num_days: parseInt(document.getElementById('numDays')?.value) || 1,
        pax_count: parseInt(document.getElementById('paxCount')?.value) || 2,
        
        // Cost Data
        costs: window.tourCosts || {},
        costTableData: collectCostTableData(),
        profit_margin: parseFloat(document.getElementById('profitMargin')?.value) || 10,
        currency_rate: parseFloat(document.getElementById('currencyRate')?.value) || 1350,
        
        // Itinerary (collect from DOM)
        itinerary: collectItineraryData(),
        
        // Pricing by PAX
        pricing: collectPaxPricingData(),
        
        // Timestamps
        created_at: new Date().toISOString(),
        status: 'draft'
    };
}

// Collect cost table data from all cost estimation tables
function collectCostTableData() {
    const categories = ['hotel', 'meal', 'admission', 'transport', 'guide', 'other'];
    const costData = {};
    
    categories.forEach(category => {
        const tableId = category + 'Table';
        const table = document.getElementById(tableId);
        if (!table) return;
        
        const tbody = table.querySelector('tbody');
        if (!tbody) return;
        
        const rows = [];
        tbody.querySelectorAll('tr').forEach(row => {
            const rowData = {
                day: row.querySelector('.cost-day')?.value || '1',
                date: row.querySelector('.cost-date')?.value || '',
                name: row.querySelector('.cost-name')?.value || '',
                type: row.querySelector('.cost-type')?.value || '',
                price: row.querySelector('.cost-price')?.value || '0',
                qty: row.querySelector('.cost-qty')?.value || '1'
            };
            
            // Save all rows (including empty ones) to preserve structure
            rows.push(rowData);
        });
        
        // Always save, even if rows are empty - to preserve the category structure
        costData[category] = rows;
    });
    
    console.log('Collected cost table data:', costData);
    return costData;
}

// Collect itinerary data from form
function collectItineraryData() {
    const days = [];
    document.querySelectorAll('.itinerary-day').forEach((card, index) => {
        const dayNum = index + 1;
        
        // Collect activities
        const activities = [];
        card.querySelectorAll('.activity-input').forEach(input => {
            if (input.value.trim()) activities.push(input.value.trim());
        });
        
        days.push({
            day: dayNum,
            date: card.querySelector('.day-date')?.value || '',
            title: card.querySelector('.day-title')?.value || `Day ${dayNum}`,
            activities: activities,
            hotel: card.querySelector('.hotel-input')?.value || '',
            hotel_rating: card.querySelector('.star-select')?.value || '',
            room_type: card.querySelector('.room-type')?.value || '',
            meals: {
                breakfast: card.querySelector('.meal-b')?.checked || false,
                lunch: card.querySelector('.meal-l')?.checked || false,
                dinner: card.querySelector('.meal-d')?.checked || false
            },
            breakfast_detail: card.querySelector('.meal-b-detail')?.value || '',
            lunch_detail: card.querySelector('.meal-l-detail')?.value || '',
            dinner_detail: card.querySelector('.meal-d-detail')?.value || ''
        });
    });
    return days;
}

// Collect PAX pricing data
function collectPaxPricingData() {
    const pricing = [];
    document.querySelectorAll('#paxBody tr').forEach(row => {
        const pax = parseInt(row.dataset.pax) || 0;
        const sglInput = row.querySelector('.pax-sgl-input');
        const sglValue = sglInput ? sglInput.value : '0';
        
        // Get the editable Selling (USD) input value
        const sellUsdInput = row.querySelector('.pax-usd-input');
        let sellUsdValue = sellUsdInput ? sellUsdInput.value : '';
        
        // Get the calculated Price USD from the cell
        const priceUsdCell = row.querySelector('.pax-price-usd');
        const calculatedPriceUSD = priceUsdCell ? priceUsdCell.textContent : '$0';
        
        // If Selling USD is empty or 0, use the calculated Price USD value
        if (!sellUsdValue || sellUsdValue === '' || sellUsdValue === '0') {
            // Extract number from calculated price
            const calcNum = parseFloat(calculatedPriceUSD.replace(/[^0-9.]/g, ''));
            if (!isNaN(calcNum) && calcNum > 0) {
                sellUsdValue = Math.round(calcNum).toString();
            }
        }
        
        pricing.push({
            pax: pax,
            groupCost: row.querySelector('.pax-group-cost')?.textContent || '₩0',
            costPerPerson: row.querySelector('.pax-cost-pp')?.textContent || '₩0',
            profit: row.querySelector('.pax-profit')?.textContent || '₩0',
            sellPriceKRW: row.querySelector('.pax-sell-krw')?.textContent || '₩0',
            sellPriceUSD: calculatedPriceUSD,
            // Save the editable Selling (USD) input - with fallback to calculated
            sellingUSD: sellUsdValue,
            sglCharge: sglValue ? `$${sglValue}` : '-'
        });
    });
    console.log('Collected pricing data:', pricing);
    return pricing;
}

// Print quotation
function printQuotation() {
    // Add print class to body for styling
    document.body.classList.add('printing');
    
    // Small delay to ensure styles are applied
    setTimeout(() => {
        window.print();
        
        // Remove print class after printing
        setTimeout(() => {
            document.body.classList.remove('printing');
        }, 500);
    }, 100);
}

// Toggle print options panel
function togglePrintOptions() {
    const panel = document.getElementById('printOptionsPanel');
    if (panel) {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
}

// Toggle print section visibility
function togglePrintSection(sectionId, show) {
    const section = document.getElementById(sectionId);
    if (section) {
        // Special handling for notes section - only show if it has content
        if (sectionId === 'notesSection') {
            const notesContent = document.getElementById('printNotes');
            if (notesContent && notesContent.textContent.trim()) {
                section.style.display = show ? '' : 'none';
            }
        } else {
            section.style.display = show ? '' : 'none';
        }
    }
}

// Download as PDF using html2canvas and jsPDF
async function downloadPDF() {
    const printElement = document.getElementById('printableQuotation');
    if (!printElement) {
        showNotification('Print content not found', 'error');
        return;
    }
    
    // Check if html2pdf is loaded
    if (typeof html2pdf === 'undefined') {
        // Load html2pdf dynamically
        showNotification('Loading PDF generator...', 'info');
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
        script.onload = () => generatePDF(printElement);
        script.onerror = () => {
            showNotification('Could not load PDF library. Please try Print instead.', 'error');
        };
        document.head.appendChild(script);
    } else {
        generatePDF(printElement);
    }
}

// Generate and download PDF
function generatePDF(element) {
    const savedData = localStorage.getItem('currentQuotation');
    let filename = 'quotation.pdf';
    if (savedData) {
        const data = JSON.parse(savedData);
        filename = `${data.quotation_number || 'quotation'}.pdf`;
    }
    
    showNotification('Generating PDF...', 'info');
    
    // Set element width temporarily for PDF generation
    const originalWidth = element.style.width;
    element.style.width = '700px';
    
    const opt = {
        margin: [10, 10, 10, 10],
        filename: filename,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { 
            scale: 2,
            useCORS: true,
            width: 700
        },
        jsPDF: { 
            unit: 'mm', 
            format: 'a4', 
            orientation: 'portrait' 
        }
    };
    
    html2pdf().set(opt).from(element).save().then(() => {
        element.style.width = originalWidth;
        showNotification('PDF downloaded successfully!', 'success');
    }).catch(err => {
        element.style.width = originalWidth;
        console.error('PDF generation error:', err);
        showNotification('Error generating PDF', 'error');
    });
}

// Finish quotation and add to list
function finishQuotation() {
    // Get the saved quotation data
    const savedData = localStorage.getItem('currentQuotation');
    if (!savedData) {
        showNotification('No quotation data found. Please save the quotation first.', 'error');
        return;
    }
    
    const quotationData = JSON.parse(savedData);
    
    // Get existing quotations list or create new one
    let quotationsList = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    
    // Check if this quotation already exists (update) or is new (add)
    const existingIndex = quotationsList.findIndex(q => q.quotation_number === quotationData.quotation_number);
    
    // Determine quotation type and display name
    const isServiceQuotation = quotationData.quotation_type === 'service';
    
    // Create quotation record for the list
    const quotationRecord = {
        quotation_number: quotationData.quotation_number,
        program_name: isServiceQuotation 
            ? (quotationData.service_type || 'Service Quotation')
            : (quotationData.tour_name || 'Untitled Tour'),
        customer_name: quotationData.customer_name || 'Unknown Customer',
        type: isServiceQuotation ? 'Service' : 'Itinerary',
        sending_date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        last_update: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        status: 'sent',
        full_data: quotationData
    };
    
    if (existingIndex >= 0) {
        // Update existing
        quotationsList[existingIndex] = quotationRecord;
    } else {
        // Add new
        quotationsList.unshift(quotationRecord);
    }
    
    // Save back to localStorage
    localStorage.setItem('quotationsList', JSON.stringify(quotationsList));
    
    showNotification('Quotation finished and saved to list!', 'success');
    
    // Navigate back to quotations list after a short delay
    setTimeout(() => {
        loadContent('quotations');
    }, 1500);
}

// Legacy function compatibility
async function saveAsDraft() {
    await saveQuotationDraft();
}

async function saveQuotation(status = 'draft') {
    try {
        // Show loading indicator
        const btn = event?.target;
        const originalText = btn?.innerHTML;
        if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        
        // Get next quotation number from database
        const quotationNumber = await db.getNextQuotationNumber();
        
        // Collect form data
        const quotationData = {
            quotation_number: quotationNumber,
            quotation_date: document.getElementById('quotationDate')?.value,
            valid_until: document.getElementById('validUntil')?.value,
            customer_name: document.getElementById('customerName')?.value,
            contact_person: document.getElementById('contactPerson')?.value,
            customer_email: document.getElementById('customerEmail')?.value,
            customer_phone: document.getElementById('customerPhone')?.value,
            tour_name: document.getElementById('tourName')?.value,
            destination: document.getElementById('destination')?.value,
            travel_date: document.getElementById('travelDate')?.value,
            number_of_days: parseInt(document.getElementById('numberOfDays')?.value) || 0,
            number_of_passengers: parseInt(document.getElementById('numberOfPassengers')?.value) || 0,
            subtotal: parseFloat(document.getElementById('subtotalAmount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            discount_percent: parseFloat(document.getElementById('discountPercent')?.value) || 0,
            discount_amount: parseFloat(document.getElementById('discountAmount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            tax_percent: parseFloat(document.getElementById('taxPercent')?.value) || 0,
            tax_amount: parseFloat(document.getElementById('taxAmount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            grand_total: parseFloat(document.getElementById('grandTotal')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            per_person_price: parseFloat(document.getElementById('perPersonAmount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            inclusions: document.getElementById('inclusions')?.value,
            exclusions: document.getElementById('exclusions')?.value,
            terms_conditions: document.getElementById('termsConditions')?.value,
            internal_notes: document.getElementById('internalNotes')?.value,
            status: status
        };
        
        // Collect itinerary days
        const itineraryDays = [];
        document.querySelectorAll('.itinerary-day').forEach((dayCard, index) => {
            const day = {
                day_number: index + 1,
                day_date: dayCard.querySelector('.day-date')?.value,
                day_title: dayCard.querySelector('.day-title')?.value,
                hotel_name: dayCard.querySelector('[name="hotelName"]')?.value,
                hotel_star_rating: parseInt(dayCard.querySelector('[name="starRating"]')?.value) || null,
                room_type: dayCard.querySelector('[name="roomType"]')?.value,
                breakfast: dayCard.querySelector('.meal-breakfast')?.checked || false,
                breakfast_menu: dayCard.querySelector('.meal-b-detail')?.value,
                lunch: dayCard.querySelector('.meal-lunch')?.checked || false,
                lunch_menu: dayCard.querySelector('.meal-l-detail')?.value,
                dinner: dayCard.querySelector('.meal-dinner')?.checked || false,
                dinner_menu: dayCard.querySelector('.meal-d-detail')?.value,
                activities: []
            };
            
            // Collect activities
            dayCard.querySelectorAll('.activity-item').forEach((actItem, actIndex) => {
                const actDesc = actItem.querySelector('.activity-input')?.value;
                if (actDesc) {
                    day.activities.push({
                        activity_number: actIndex + 1,
                        activity_description: actDesc
                    });
                }
            });
            
            itineraryDays.push(day);
        });
        
        // Collect pricing items
        const pricingItems = [];
        document.querySelectorAll('#pricingBody tr').forEach((row, index) => {
            const desc = row.querySelector('.price-desc')?.value;
            const qty = parseInt(row.querySelector('.price-qty')?.value) || 0;
            const rate = parseFloat(row.querySelector('.price-rate')?.value) || 0;
            const amount = parseFloat(row.querySelector('.price-amount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0;
            
            if (desc) {
                pricingItems.push({
                    item_number: index + 1,
                    description: desc,
                    quantity: qty,
                    unit: row.querySelector('.price-unit')?.value || 'pcs',
                    rate: rate,
                    amount: amount
                });
            }
        });
        
        // Save to database
        const result = await db.saveQuotationItinerary(quotationData, itineraryDays, pricingItems);
        
        if (result.success) {
            // Update UI with saved quote number
            const qNumDisplay = document.getElementById('displayQuoteId');
            if (qNumDisplay) qNumDisplay.textContent = quotationNumber;
            const qNumField = document.getElementById('quotationNumber');
            if (qNumField) qNumField.value = quotationNumber;
            
            // Show success message
            showNotification('Quotation saved successfully!', 'success');
        } else {
            throw new Error(result.error || 'Failed to save quotation');
        }
        
    } catch (error) {
        console.error('Error saving quotation:', error);
        showNotification('Error saving quotation: ' + error.message, 'error');
    } finally {
        // Restore button
        if (btn && originalText) {
            btn.innerHTML = originalText;
        }
    }
}

function showNotification(message, type = 'info') {
    // Simple notification - you can enhance this later
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 24px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        font-size: 14px;
        font-weight: 500;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function showPreview() {
    generatePreviewContent();
    const modal = document.getElementById('printPreviewModal');
    if (modal) modal.classList.add('active');
}

function closePreview() {
    const modal = document.getElementById('printPreviewModal');
    if (modal) modal.classList.remove('active');
}

function generatePreviewContent() {
    const previewDiv = document.getElementById('previewContent');
    const printDiv = document.getElementById('printDocument');
    if (!previewDiv) return;
    
    const quoteNum = document.getElementById('quotationNumber')?.value || '-';
    const quoteDate = document.getElementById('quotationDate')?.value || '-';
    const validUntil = document.getElementById('validUntil')?.value || '-';
    const customerName = document.getElementById('customerName')?.value || '-';
    const contactPerson = document.getElementById('contactPerson')?.value || '-';
    const customerEmail = document.getElementById('customerEmail')?.value || '-';
    const customerPhone = document.getElementById('customerPhone')?.value || '-';
    const tourName = document.getElementById('tourName')?.value || '-';
    const destination = document.getElementById('destination')?.value || '-';
    const travelDate = document.getElementById('travelDate')?.value || '-';
    const paxCount = document.getElementById('paxCount')?.value || '-';
    
    // Build itinerary HTML
    let itineraryHtml = '';
    document.querySelectorAll('.itinerary-day').forEach(day => {
        const dayNum = day.querySelector('.day-number')?.textContent || '';
        const date = day.querySelector('.day-date')?.value || '';
        const dayName = day.querySelector('.day-name')?.textContent || '';
        const title = day.querySelector('.day-title')?.value || '';
        const hotel = day.querySelector('.hotel-input')?.value || '-';
        const stars = day.querySelector('.star-select')?.value;
        const starStr = stars ? '★'.repeat(parseInt(stars)) : '';
        
        const bChecked = day.querySelector('.meal-b')?.checked;
        const lChecked = day.querySelector('.meal-l')?.checked;
        const dChecked = day.querySelector('.meal-d')?.checked;
        const meals = [bChecked ? 'B' : '', lChecked ? 'L' : '', dChecked ? 'D' : ''].filter(m => m).join(' / ') || 'None';
        
        let activities = [];
        day.querySelectorAll('.activity-input').forEach(input => {
            if (input.value.trim()) activities.push(input.value.trim());
        });
        
        itineraryHtml += `
            <div class="day-block">
                <div class="day-title-print">${dayNum}: ${title || date} ${dayName ? '(' + dayName + ')' : ''}</div>
                <div class="day-details">
                    <p><strong>Hotel:</strong> ${hotel} ${starStr}</p>
                    <p><strong>Meals:</strong> ${meals}</p>
                    ${activities.length > 0 ? '<p><strong>Activities:</strong></p><ul>' + activities.map(a => '<li>' + a + '</li>').join('') + '</ul>' : ''}
                </div>
            </div>
        `;
    });
    
    // Build pricing table
    let pricingHtml = '';
    document.querySelectorAll('#pricingBody tr').forEach(row => {
        const desc = row.querySelector('.price-desc')?.value || '-';
        const qty = row.querySelector('.price-qty')?.value || '0';
        const unit = row.querySelector('.price-unit')?.value || '-';
        const rate = row.querySelector('.price-rate')?.value || '0';
        const total = row.querySelector('.row-total')?.textContent || '$0.00';
        pricingHtml += `<tr><td>${desc}</td><td>${qty}</td><td>${unit}</td><td class="amount-col">${formatCurrency(parseFloat(rate) || 0)}</td><td class="amount-col">${total}</td></tr>`;
    });
    
    const subtotal = document.getElementById('calcSubtotal')?.textContent || '$0.00';
    const discount = document.getElementById('calcDiscount')?.textContent || '$0.00';
    const tax = document.getElementById('calcTax')?.textContent || '$0.00';
    const grandTotal = document.getElementById('calcGrandTotal')?.textContent || '$0.00';
    const perPax = document.getElementById('calcPerPax')?.textContent || '$0.00';
    
    const inclusions = document.getElementById('inclusions')?.value || '';
    const exclusions = document.getElementById('exclusions')?.value || '';
    const terms = document.getElementById('termsText')?.value || '';
    
    const html = `
        <div class="print-doc">
            <div class="company-header">
                <h1 class="company-name">TOURIX</h1>
                <p class="company-tagline">Travel & Tours</p>
            </div>
            
            <div class="quote-title">QUOTATION</div>
            
            <div class="info-row">
                <div class="info-box">
                    <h4>Bill To</h4>
                    <p><strong>${customerName}</strong></p>
                    <p>Contact: ${contactPerson}</p>
                    <p>Email: ${customerEmail}</p>
                    <p>Phone: ${customerPhone}</p>
                </div>
                <div class="info-box" style="text-align: right;">
                    <h4>Quote Details</h4>
                    <p><strong>Quote #:</strong> ${quoteNum}</p>
                    <p><strong>Date:</strong> ${quoteDate}</p>
                    <p><strong>Valid Until:</strong> ${validUntil}</p>
                    <p><strong>Passengers:</strong> ${paxCount}</p>
                </div>
            </div>
            
            <h3 class="section-title">Tour: ${tourName}</h3>
            <p><strong>Destination:</strong> ${destination} | <strong>Travel Date:</strong> ${travelDate}</p>
            
            <h3 class="section-title">Itinerary</h3>
            ${itineraryHtml}
            
            <h3 class="section-title">Pricing</h3>
            <table class="price-table">
                <thead>
                    <tr><th>Description</th><th>Qty</th><th>Unit</th><th class="amount-col">Rate</th><th class="amount-col">Amount</th></tr>
                </thead>
                <tbody>${pricingHtml}</tbody>
            </table>
            
            <div class="totals-box">
                <div class="total-line"><span>Subtotal</span><span>${subtotal}</span></div>
                <div class="total-line"><span>Discount</span><span>${discount}</span></div>
                <div class="total-line"><span>Tax</span><span>${tax}</span></div>
                <div class="total-line grand-total"><span>Grand Total</span><span>${grandTotal}</span></div>
                <div class="total-line"><span>Per Person</span><span>${perPax}</span></div>
            </div>
            
            ${inclusions ? '<h3 class="section-title">Inclusions</h3><div style="white-space: pre-line;">' + inclusions + '</div>' : ''}
            ${exclusions ? '<h3 class="section-title">Exclusions</h3><div style="white-space: pre-line;">' + exclusions + '</div>' : ''}
            
            <div class="terms-section">
                <h4>Terms & Conditions</h4>
                <div style="white-space: pre-line;">${terms}</div>
            </div>
            
            <div class="signature-area">
                <div class="signature-box">
                    <div class="signature-line">Authorized Signature (Company)</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line">Customer Acceptance</div>
                </div>
            </div>
        </div>
    `;
    
    previewDiv.innerHTML = html;
    if (printDiv) printDiv.innerHTML = html;
}

function printDocument() {
    generatePreviewContent();
    window.print();
}

// Keep old function names as aliases for backward compatibility
function initQuotationItinerary() { initQuotePage(); }
function initQuotationService() { initQuotePage(); }

function setupQuotationEventListeners() {
    const servicesList = document.getElementById('servicesList');
    if (servicesList) {
        servicesList.addEventListener('input', function(e) {
            if (e.target.classList.contains('service-qty') || e.target.classList.contains('service-price')) {
                updateServiceTotal(e.target.closest('.service-item'));
                calculateTotals();
            }
        });
    }
    
    const discountPercent = document.getElementById('discountPercent');
    const taxPercent = document.getElementById('taxPercent');
    const passengerCount = document.getElementById('passengerCount');
    
    if (discountPercent) discountPercent.addEventListener('input', calculateTotals);
    if (taxPercent) taxPercent.addEventListener('input', calculateTotals);
    if (passengerCount) passengerCount.addEventListener('input', calculateTotals);
}

function updateServiceTotal(serviceItem) {
    if (!serviceItem) return;
    const qty = parseFloat(serviceItem.querySelector('.service-qty')?.value) || 0;
    const price = parseFloat(serviceItem.querySelector('.service-price')?.value) || 0;
    const total = qty * price;
    const totalEl = serviceItem.querySelector('.service-total');
    if (totalEl) totalEl.textContent = '$' + total.toFixed(2);
}

function calculateTotals() {
    let subtotal = 0;
    document.querySelectorAll('.service-item').forEach(item => {
        const qty = parseFloat(item.querySelector('.service-qty')?.value) || 0;
        const price = parseFloat(item.querySelector('.service-price')?.value) || 0;
        subtotal += qty * price;
    });
    
    const discountPercent = parseFloat(document.getElementById('discountPercent')?.value) || 0;
    const taxPercent = parseFloat(document.getElementById('taxPercent')?.value) || 0;
    const passengerCount = parseInt(document.getElementById('passengerCount')?.value) || 1;
    
    const discountAmount = subtotal * (discountPercent / 100);
    const afterDiscount = subtotal - discountAmount;
    const taxAmount = afterDiscount * (taxPercent / 100);
    const grandTotal = afterDiscount + taxAmount;
    const perPerson = grandTotal / passengerCount;
    
    const subtotalEl = document.getElementById('subtotal');
    const discountEl = document.getElementById('discountAmount');
    const taxEl = document.getElementById('taxAmount');
    const grandTotalEl = document.getElementById('grandTotal');
    const perPersonEl = document.getElementById('perPerson');
    const paxCountEl = document.getElementById('paxCount');
    
    if (subtotalEl) subtotalEl.textContent = '$' + subtotal.toFixed(2);
    if (discountEl) discountEl.textContent = '-$' + discountAmount.toFixed(2);
    if (taxEl) taxEl.textContent = '$' + taxAmount.toFixed(2);
    if (grandTotalEl) grandTotalEl.textContent = '$' + grandTotal.toFixed(2);
    if (perPersonEl) perPersonEl.textContent = '$' + perPerson.toFixed(2);
    if (paxCountEl) paxCountEl.textContent = passengerCount;
}

function addService() {
    const servicesList = document.getElementById('servicesList');
    if (!servicesList) return;
    
    const serviceHtml = `
        <div class="service-item">
            <select class="service-category">
                <option value="">Select Category</option>
                <option value="accommodation">Accommodation</option>
                <option value="transport">Transportation</option>
                <option value="transfer">Airport Transfer</option>
                <option value="tours">Tours & Activities</option>
                <option value="meals">Meals</option>
                <option value="guide">Guide Services</option>
                <option value="visa">Visa & Documents</option>
                <option value="insurance">Travel Insurance</option>
                <option value="other">Other</option>
            </select>
            <input type="text" class="service-name" placeholder="Service description">
            <input type="number" class="service-qty" value="1" min="1" placeholder="Qty">
            <input type="number" class="service-price" placeholder="Unit Price" step="0.01">
            <span class="service-total">$0.00</span>
            <button class="btn-icon remove-service" onclick="removeService(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    servicesList.insertAdjacentHTML('beforeend', serviceHtml);
}

function removeService(btn) {
    const serviceItem = btn.closest('.service-item');
    if (document.querySelectorAll('.service-item').length > 1) {
        serviceItem.remove();
        calculateTotals();
    }
}

function addItineraryDay() {
    dayCounter++;
    const itineraryList = document.getElementById('itineraryList');
    if (!itineraryList) return;
    
    const dayHtml = `
        <div class="itinerary-day-card" data-day="${dayCounter}">
            <div class="day-header-bar">
                <div class="day-number-badge">Day ${dayCounter}</div>
                <div class="day-date-picker">
                    <input type="date" class="day-date" onchange="updateDayOfWeek(this)">
                    <span class="day-of-week">Select date</span>
                </div>
                <input type="text" class="day-title-input" placeholder="Day title (e.g., City Tour)">
                <button type="button" class="btn-icon-delete" onclick="removeItineraryDay(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            
            <div class="day-body">
                <!-- Hotel Section -->
                <div class="day-section hotel-section">
                    <div class="section-label"><i class="fas fa-hotel"></i> Accommodation</div>
                    <div class="hotel-inputs">
                        <input type="text" class="hotel-name" placeholder="Hotel name">
                        <div class="hotel-grade">
                            <select class="star-rating">
                                <option value="">Star</option>
                                <option value="1">⭐</option>
                                <option value="2">⭐⭐</option>
                                <option value="3">⭐⭐⭐</option>
                                <option value="4">⭐⭐⭐⭐</option>
                                <option value="5">⭐⭐⭐⭐⭐</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Meals Section -->
                <div class="day-section meals-section">
                    <div class="section-label"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="meals-grid">
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="breakfast">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Breakfast</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="lunch">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Lunch</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="dinner">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Dinner</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                    </div>
                </div>

                <!-- Sightseeing & Activities Section -->
                <div class="day-section activities-section">
                    <div class="section-label"><i class="fas fa-camera"></i> Sightseeing & Activities</div>
                    <div class="activities-list">
                        <div class="activity-row">
                            <span class="activity-number">1</span>
                            <input type="text" class="activity-input" placeholder="Enter sightseeing or activity...">
                            <button type="button" class="btn-add-activity" onclick="addActivity(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    itineraryList.insertAdjacentHTML('beforeend', dayHtml);
    
    // Setup meal toggle listeners for new day
    setupMealToggles();
}

function removeItineraryDay(btn) {
    const dayItem = btn.closest('.itinerary-day-card');
    if (document.querySelectorAll('.itinerary-day-card').length > 1) {
        dayItem.remove();
        renumberDays();
    }
}

function renumberDays() {
    document.querySelectorAll('.itinerary-day-card').forEach((day, index) => {
        day.dataset.day = index + 1;
        day.querySelector('.day-number-badge').textContent = 'Day ' + (index + 1);
    });
    dayCounter = document.querySelectorAll('.itinerary-day-card').length;
}

// Update day of week when date is selected
function updateDayOfWeek(dateInput) {
    const dayCard = dateInput.closest('.itinerary-day-card');
    const dayOfWeekSpan = dayCard.querySelector('.day-of-week');
    
    if (dateInput.value) {
        const date = new Date(dateInput.value);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        dayOfWeekSpan.textContent = days[date.getDay()];
    } else {
        dayOfWeekSpan.textContent = 'Select date';
    }
}

// Setup meal toggles to enable/disable menu input
function setupMealToggles() {
    document.querySelectorAll('.meal-included').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const mealItem = this.closest('.meal-item');
            const menuInput = mealItem.querySelector('.meal-menu');
            menuInput.disabled = !this.checked;
            if (!this.checked) {
                menuInput.value = '';
            }
        });
    });
}

// Initialize meal toggles on page load
function initQuotationItinerary() {
    try {
        // Check for saved quotation data (editing mode)
        const savedData = localStorage.getItem('currentQuotation');
        if (savedData) {
            const data = JSON.parse(savedData);
            // Populate form with saved data
            populateItineraryForm(data);
            // Clear the saved data after loading
            localStorage.removeItem('currentQuotation');
            return;
        }
        
        // New quotation - set default dates
        const today = new Date();
        const validDate = new Date(today);
        validDate.setDate(validDate.getDate() + 30);
        
        const quotationDate = document.getElementById('quotationDate');
        const validUntil = document.getElementById('validUntil');
        
        if (quotationDate) quotationDate.value = formatDateForInput(today);
        if (validUntil) validUntil.value = formatDateForInput(validDate);
        
        // Generate quotation number
        const quotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const quotationNumber = document.getElementById('quotationNumber');
        if (quotationNumber) quotationNumber.value = quotationNo;
        
        // Setup event listeners for pricing calculation
        setupPricingListeners();
        
        // Reset day counter
        dayCounter = document.querySelectorAll('.day-card').length || 1;
        
        // Initialize first day date
        const firstDayDate = document.querySelector('.day-card .day-date');
        if (firstDayDate && !firstDayDate.value) {
            firstDayDate.value = formatDateForInput(today);
            updateDayOfWeekNew(firstDayDate);
        }
    } catch (err) {
        console.error('Error in initQuotationItinerary:', err);
    }
}

function initQuotationService() {
    try {
        // Check for saved quotation data (editing mode)
        const savedData = localStorage.getItem('currentQuotation');
        if (savedData) {
            const data = JSON.parse(savedData);
            // Populate form with saved data
            populateServiceForm(data);
            // Clear the saved data after loading
            localStorage.removeItem('currentQuotation');
            return;
        }
        
        // New quotation - set default dates
        const today = new Date();
        const validDate = new Date(today);
        validDate.setDate(validDate.getDate() + 30);
        
        const quotationDate = document.getElementById('quotationDate');
        const validUntil = document.getElementById('validUntil');
        
        if (quotationDate) quotationDate.value = formatDateForInput(today);
        if (validUntil) validUntil.value = formatDateForInput(validDate);
        
        // Generate quotation number
        const quotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const quotationNumber = document.getElementById('quotationNumber');
        if (quotationNumber) quotationNumber.value = quotationNo;
        
        // Setup event listeners for pricing calculation
        setupPricingListeners();
    } catch (err) {
        console.error('Error in initQuotationService:', err);
    }
}

// Populate service form with saved data (for editing)
function populateServiceForm(data) {
    if (!data) {
        console.error('No data to populate');
        return;
    }
    
    console.log('Populating service form with data:', data);
    
    // Helper to set input value
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el && val !== undefined && val !== null) {
            el.value = val;
            console.log('Set', id, '=', val);
        }
    };
    
    // Basic Info
    setVal('quotationNumber', data.quotation_number);
    setVal('quotationDate', data.quotation_date);
    setVal('validUntil', data.valid_until);
    
    // Update display ID
    const displayQuoteId = document.getElementById('displayQuoteId');
    if (displayQuoteId) displayQuoteId.textContent = data.quotation_number;
    
    // Customer Info
    setVal('customerName', data.customer_name);
    setVal('contactPerson', data.contact_person);
    setVal('customerEmail', data.customer_email);
    setVal('customerPhone', data.customer_phone);
    setVal('customerNationality', data.nationality);
    
    // Service Info
    setVal('serviceType', data.service_type);
    setVal('serviceDate', data.service_date);
    setVal('paxCount', data.pax_count);
    
    // Pricing settings
    setVal('discountPercent', data.discount_percent);
    setVal('taxPercent', data.tax_percent);
    setVal('handlingFeePercent', data.handling_fee_percent);
    
    // Notes and Terms
    setVal('quotationNotes', data.notes);
    setVal('quotationTerms', data.terms);
    
    // Setup event listeners for pricing calculation
    setupPricingListeners();
    
    // Clear localStorage after loading
    localStorage.removeItem('currentQuotation');
    
    console.log('Successfully loaded service quotation:', data.quotation_number);
    showNotification('Quotation loaded for editing', 'success');
}

// Setup pricing event listeners
function setupPricingListeners() {
    const discountInput = document.getElementById('discountPercent');
    const taxInput = document.getElementById('taxPercent');
    const paxInput = document.getElementById('paxCount');
    
    if (discountInput) discountInput.addEventListener('input', calculatePricingSummary);
    if (taxInput) taxInput.addEventListener('input', calculatePricingSummary);
    if (paxInput) paxInput.addEventListener('input', calculatePricingSummary);
}

// Update day of week for new structure
function updateDayOfWeekNew(dateInput) {
    if (!dateInput) return;
    const dayCard = dateInput.closest('.day-card');
    if (!dayCard) return;
    const dayOfWeekSpan = dayCard.querySelector('.day-of-week');
    if (!dayOfWeekSpan) return;
    
    if (dateInput.value) {
        const date = new Date(dateInput.value);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        dayOfWeekSpan.textContent = days[date.getDay()];
    } else {
        dayOfWeekSpan.textContent = 'Select date';
    }
}

// Add new day card
function addDayCard() {
    const daysContainer = document.getElementById('daysContainer');
    if (!daysContainer) return;
    
    const dayCards = daysContainer.querySelectorAll('.day-card');
    const newDayNum = dayCards.length + 1;
    
    // Calculate next date based on last day
    let nextDate = new Date();
    if (dayCards.length > 0) {
        const lastDayDate = dayCards[dayCards.length - 1].querySelector('.day-date')?.value;
        if (lastDayDate) {
            nextDate = new Date(lastDayDate);
            nextDate.setDate(nextDate.getDate() + 1);
        }
    }
    
    const dayHtml = `
        <div class="day-card" data-day="${newDayNum}">
            <div class="day-header">
                <div class="day-badge">Day ${newDayNum}</div>
                <div class="day-date-group">
                    <input type="date" class="day-date" value="${formatDateForInput(nextDate)}" onchange="updateDayOfWeekNew(this)">
                    <span class="day-of-week">${getDayName(nextDate)}</span>
                </div>
                <button type="button" class="btn-remove-day" onclick="removeDayCard(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            
            <div class="day-body">
                <!-- Hotel Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-hotel"></i> Accommodation</div>
                    <div class="hotel-row">
                        <input type="text" class="hotel-name" placeholder="Hotel name">
                        <select class="hotel-star">
                            <option value="">Star Rating</option>
                            <option value="1">★</option>
                            <option value="2">★★</option>
                            <option value="3">★★★</option>
                            <option value="4">★★★★</option>
                            <option value="5">★★★★★</option>
                        </select>
                    </div>
                </div>
                
                <!-- Meals Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="meals-row">
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-breakfast" onchange="toggleMealInput(this)">
                                <span class="meal-name">Breakfast</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-lunch" onchange="toggleMealInput(this)">
                                <span class="meal-name">Lunch</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-dinner" onchange="toggleMealInput(this)">
                                <span class="meal-name">Dinner</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                    </div>
                </div>
                
                <!-- Activities Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-camera"></i> Sightseeing & Activities</div>
                    <div class="activities-list">
                        <div class="activity-row">
                            <span class="activity-num">1</span>
                            <input type="text" class="activity-input" placeholder="Enter sightseeing or activity...">
                            <button type="button" class="btn-add-activity" onclick="addActivityLine(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    daysContainer.insertAdjacentHTML('beforeend', dayHtml);
}

// Get day name from date
function getDayName(date) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[date.getDay()];
}

// Remove day card
function removeDayCard(btn) {
    const dayCard = btn.closest('.day-card');
    const container = dayCard.closest('#daysContainer');
    
    if (container.querySelectorAll('.day-card').length > 1) {
        dayCard.remove();
        // Renumber days
        container.querySelectorAll('.day-card').forEach((card, i) => {
            card.dataset.day = i + 1;
            card.querySelector('.day-badge').textContent = 'Day ' + (i + 1);
        });
    }
}

// ==========================================
// Dashboard Charts
// ==========================================
function initDashboardCharts() {
    // Quotations Chart
    const quotationsCtx = document.getElementById('quotationsChart');
    if (quotationsCtx) {
        new Chart(quotationsCtx, {
            type: 'doughnut',
            data: {
                labels: ['Sent', 'Confirmed', 'Cancelled'],
                datasets: [{
                    data: [45, 28, 12],
                    backgroundColor: ['#2563EB', '#10B981', '#EF4444'],
                    borderWidth: 0,
                    cutout: '75%'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
}

// ==========================================
// Contact Filters
// ==========================================
function initContactFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const contactCards = document.querySelectorAll('.contact-card');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const filter = this.dataset.filter;
            contactCards.forEach(card => {
                if (filter === 'all' || card.dataset.type === filter) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// ==========================================
// Dark Mode Toggle
// ==========================================
const darkModeToggle = document.getElementById('darkModeToggle');
const body = document.body;

// Check for saved dark mode preference
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    body.classList.add('dark-mode');
    if (darkModeToggle) darkModeToggle.checked = true;
}

if (darkModeToggle) {
    darkModeToggle.addEventListener('change', () => {
        body.classList.toggle('dark-mode');
        const theme = body.classList.contains('dark-mode') ? 'dark' : 'light';
        localStorage.setItem('theme', theme);
    });
}

// ==========================================
// Update Current Date
// ==========================================
function updateDate() {
    const dateElement = document.getElementById('currentDate');
    if (dateElement) {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        const currentDate = new Date().toLocaleDateString('en-US', options);
        dateElement.textContent = currentDate;
    }
}
updateDate();

// ==========================================
// Navigation Event Listeners
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    // Handle sidebar navigation clicks
    const navItems = document.querySelectorAll('.nav-menu .nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            if (page) {
                loadContent(page);
                // Close sidebar on mobile after navigation
                if (window.innerWidth <= 768) {
                    document.querySelector('.sidebar').classList.remove('active');
                    document.body.classList.remove('sidebar-open');
                }
            }
        });
    });
    
    // Hamburger menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            document.body.classList.toggle('sidebar-open');
        });
    }
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            const sidebar = document.querySelector('.sidebar');
            const menuToggle = document.getElementById('menuToggle');
            
            if (sidebar.classList.contains('active') && 
                !sidebar.contains(e.target) && 
                !menuToggle.contains(e.target)) {
                sidebar.classList.remove('active');
                document.body.classList.remove('sidebar-open');
            }
        }
    });
    
    // Load initial content - check URL hash or localStorage first
    const hashPage = window.location.hash.replace('#', '');
    const savedPage = localStorage.getItem('currentPage');
    const initialPage = hashPage || savedPage || 'dashboard';
    
    // Valid pages list
    const validPages = ['dashboard', 'quotations', 'quotation-itinerary', 'quotation-service', 
                        'quotation-summary', 'quotation-service-summary', 'booking', 'booking-confirmation',
                        'print-confirmation', 'operation', 'operation-arrangement', 'tour-product', 'financial', 'directory'];
    
    // Load the page if valid, otherwise default to dashboard
    if (validPages.includes(initialPage)) {
        loadContent(initialPage);
    } else {
        loadContent('dashboard');
    }
});

// Handle browser back/forward buttons
window.addEventListener('hashchange', function() {
    const page = window.location.hash.replace('#', '');
    if (page && page !== currentPage) {
        loadContent(page);
    }
});

// ==========================================
// Filter Tabs Functionality
// ==========================================
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('tab')) {
        const tabs = e.target.parentElement.querySelectorAll('.tab');
        tabs.forEach(t => t.classList.remove('active'));
        e.target.classList.add('active');
    }
});

// ==========================================
// Icon Button Animations
// ==========================================
// Icon Button Animations
// ==========================================
document.addEventListener('click', function(e) {
    if (e.target.closest('.icon-btn')) {
        const btn = e.target.closest('.icon-btn');
        btn.style.transform = 'scale(0.95)';
        setTimeout(() => {
            btn.style.transform = '';
        }, 150);
    }
});

// ==========================================
// Loading Spinner Styles
// ==========================================
const spinnerStyles = document.createElement('style');
spinnerStyles.textContent = `
    .loading-spinner {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 300px;
        color: var(--text-secondary);
    }
    .loading-spinner i {
        font-size: 40px;
        color: var(--primary-blue);
        margin-bottom: 16px;
    }
    .error-message {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 300px;
        text-align: center;
        color: var(--text-secondary);
    }
    .error-message i {
        font-size: 48px;
        color: #F59E0B;
        margin-bottom: 16px;
    }
    .error-message h3 {
        color: var(--text-primary);
        margin-bottom: 8px;
    }
    .error-message button {
        margin-top: 20px;
    }
`;
document.head.appendChild(spinnerStyles);

// Console welcome message
console.log('%c🎯 TOURIX Dashboard v1.0', 'color: #4F46E5; font-size: 20px; font-weight: bold;');
console.log('%cDeveloped for tour and travel management', 'color: #6B7280; font-size: 12px;');

// =============================================
// OPERATION TIMELINE FUNCTIONS
// =============================================

function initOperationTimeline() {
    // Timeline state
    window.timelineStartDate = new Date();
    window.timelineDays = 30;
    
    function getStartOfWeek(date) {
        const d = new Date(date);
        const day = d.getDay();
        const diff = d.getDate() - day + (day === 0 ? -6 : 1);
        d.setDate(diff);
        d.setHours(0, 0, 0, 0);
        return d;
    }
    
    // Initialize year selector with range of years
    function initYearSelector() {
        const yearSelect = document.getElementById('yearSelector');
        if (!yearSelect) return;
        
        const currentYear = new Date().getFullYear();
        yearSelect.innerHTML = '';
        
        // Add years from 2 years ago to 3 years in future
        for (let year = currentYear - 2; year <= currentYear + 3; year++) {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            if (year === currentYear) option.selected = true;
            yearSelect.appendChild(option);
        }
    }
    
    // Update all controls to reflect current date
    function updateControls() {
        const monthSelect = document.getElementById('monthSelector');
        const yearSelect = document.getElementById('yearSelector');
        const datePicker = document.getElementById('startDatePicker');
        
        if (monthSelect) {
            monthSelect.value = window.timelineStartDate.getMonth();
        }
        if (yearSelect) {
            yearSelect.value = window.timelineStartDate.getFullYear();
        }
        if (datePicker) {
            datePicker.value = window.timelineStartDate.toISOString().split('T')[0];
        }
    }
    
    window.updateDateDisplay = function() {
        const endDate = new Date(window.timelineStartDate);
        endDate.setDate(endDate.getDate() + window.timelineDays - 1);
        
        const startStr = window.timelineStartDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        const endStr = endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        
        document.getElementById('currentDateDisplay').textContent = `${startStr} - ${endStr}`;
        updateControls();
    };
    
    window.navigateDates = function(direction) {
        const moveBy = Math.floor(window.timelineDays / 2);
        window.timelineStartDate.setDate(window.timelineStartDate.getDate() + (direction * moveBy));
        window.updateDateDisplay();
        renderAllTimelines();
    };
    
    window.navigateMonth = function(direction) {
        window.timelineStartDate.setMonth(window.timelineStartDate.getMonth() + direction);
        window.updateDateDisplay();
        renderAllTimelines();
    };
    
    window.goToMonth = function() {
        const month = parseInt(document.getElementById('monthSelector').value);
        const year = parseInt(document.getElementById('yearSelector').value);
        
        window.timelineStartDate = new Date(year, month, 1);
        window.updateDateDisplay();
        renderAllTimelines();
    };
    
    window.goToSelectedDate = function() {
        const datePicker = document.getElementById('startDatePicker');
        if (datePicker && datePicker.value) {
            window.timelineStartDate = new Date(datePicker.value);
            window.updateDateDisplay();
            renderAllTimelines();
        }
    };
    
    window.goToToday = function() {
        window.timelineStartDate = getStartOfWeek(new Date());
        window.updateDateDisplay();
        renderAllTimelines();
    };
    
    window.changeDateRange = function() {
        window.timelineDays = parseInt(document.getElementById('dateRangeSelect').value);
        window.updateDateDisplay();
        renderAllTimelines();
    };
    
    function renderAllTimelines() {
        renderHotelTimeline();
        renderTransportTimeline();
        renderGuideTimeline();
    }
    
    function generateDateHeaders() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        let html = '<div class="date-headers">';
        
        for (let i = 0; i < window.timelineDays; i++) {
            const date = new Date(window.timelineStartDate);
            date.setDate(date.getDate() + i);
            
            const isWeekend = date.getDay() === 0 || date.getDay() === 6;
            const isToday = date.getTime() === today.getTime();
            const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            
            let cellClass = 'date-cell-header';
            if (isWeekend) cellClass += ' weekend';
            if (isToday) cellClass += ' today';
            
            html += `
                <div class="${cellClass}">
                    <span class="day-name">${dayNames[date.getDay()]}</span>
                    <span class="day-num">${date.getDate()}</span>
                    <span class="month">${monthNames[date.getMonth()]}</span>
                </div>
            `;
        }
        
        html += '</div>';
        return html;
    }
    
    function generateDateCells() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        let html = '';
        
        for (let i = 0; i < window.timelineDays; i++) {
            const date = new Date(window.timelineStartDate);
            date.setDate(date.getDate() + i);
            
            const isWeekend = date.getDay() === 0 || date.getDay() === 6;
            const isToday = date.getTime() === today.getTime();
            
            let cellClass = 'date-cell';
            if (isWeekend) cellClass += ' weekend';
            if (isToday) cellClass += ' today';
            
            const dateStr = date.toISOString().split('T')[0];
            html += `<div class="${cellClass}" data-date="${dateStr}"></div>`;
        }
        
        return html;
    }
    
    function getDatePosition(dateStr) {
        const date = new Date(dateStr);
        date.setHours(0, 0, 0, 0);
        
        const start = new Date(window.timelineStartDate);
        start.setHours(0, 0, 0, 0);
        
        const diffTime = date.getTime() - start.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        return diffDays;
    }
    
    function getBarStyle(checkIn, checkOut) {
        const startPos = getDatePosition(checkIn);
        const endPos = getDatePosition(checkOut);
        
        // Check if bar is visible in current range
        if (endPos < 0 || startPos >= window.timelineDays) {
            return null;
        }
        
        const visibleStart = Math.max(0, startPos);
        const visibleEnd = Math.min(window.timelineDays - 1, endPos);
        const duration = visibleEnd - visibleStart + 1;
        
        return {
            left: (visibleStart * 40) + 4,
            width: (duration * 40) - 8
        };
    }
    
    // Hotel Timeline
    function renderHotelTimeline() {
        const container = document.getElementById('hotelTimelineContainer');
        const bookings = JSON.parse(localStorage.getItem('tourixBookings') || '[]');
        
        // Collect all hotels with their bookings
        const hotelBookings = {};
        let totalBookings = 0;
        
        bookings.forEach(booking => {
            if (!booking.hotels || booking.hotels.length === 0) return;
            
            booking.hotels.forEach(hotel => {
                if (!hotel.hotelName) return;
                
                const key = hotel.hotelName;
                if (!hotelBookings[key]) {
                    hotelBookings[key] = [];
                }
                
                hotelBookings[key].push({
                    bookingId: booking.id,
                    bookingRef: booking.bookingRef || booking.id,
                    tourName: booking.tourName,
                    checkIn: hotel.checkIn,
                    checkOut: hotel.checkOut,
                    roomType: hotel.roomType,
                    rooms: hotel.rooms || 1,
                    status: booking.status || 'pending',
                    pax: booking.pax
                });
                totalBookings++;
            });
        });
        
        document.getElementById('hotelCount').textContent = `${totalBookings} bookings`;
        
        if (Object.keys(hotelBookings).length === 0) {
            container.innerHTML = '<div class="no-data-message">No hotel bookings found</div>';
            return;
        }
        
        // Build timeline HTML
        let html = '<div class="timeline-grid">';
        
        // Labels column
        html += '<div class="timeline-labels">';
        html += '<div class="label-header">Hotel Name</div>';
        
        Object.keys(hotelBookings).sort().forEach(hotelName => {
            html += `<div class="label-row" title="${hotelName}">${hotelName}</div>`;
        });
        
        html += '</div>';
        
        // Dates section
        html += '<div class="timeline-dates">';
        html += generateDateHeaders();
        
        // Rows with bookings
        Object.keys(hotelBookings).sort().forEach(hotelName => {
            html += '<div class="timeline-row">';
            html += generateDateCells();
            
            // Check for conflicts (overlapping bookings)
            const bookingsForHotel = hotelBookings[hotelName];
            const conflicts = detectConflicts(bookingsForHotel);
            
            // Render booking bars
            bookingsForHotel.forEach((booking, idx) => {
                const barStyle = getBarStyle(booking.checkIn, booking.checkOut);
                if (!barStyle) return;
                
                const hasConflict = conflicts.includes(idx);
                const statusClass = hasConflict ? 'conflict' : getStatusClass(booking.status);
                
                const tooltip = `${booking.tourName} | ${booking.bookingRef}`;
                
                html += `
                    <div class="booking-bar ${statusClass}" 
                         style="left: ${barStyle.left}px; width: ${barStyle.width}px;"
                         title="${tooltip}"
                         onclick='showBookingModal("hotel", ${JSON.stringify(booking).replace(/'/g, "&#39;")})'>
                        ${booking.tourName || booking.bookingRef}
                    </div>
                `;
            });
            
            html += '</div>';
        });
        
        html += '</div></div>';
        container.innerHTML = html;
    }
    
    // Transport Timeline
    function renderTransportTimeline() {
        const container = document.getElementById('transportTimelineContainer');
        const bookings = JSON.parse(localStorage.getItem('tourixBookings') || '[]');
        
        // Collect all transports by company/vehicle
        const transportSchedule = {};
        let totalAssignments = 0;
        
        bookings.forEach(booking => {
            if (!booking.transports || booking.transports.length === 0) return;
            
            booking.transports.forEach(transport => {
                if (!transport.company) return;
                
                const key = `${transport.company} - ${transport.vehicleType || 'Vehicle'}`;
                if (!transportSchedule[key]) {
                    transportSchedule[key] = [];
                }
                
                // Parse days
                const days = parseDays(transport.days || '', booking);
                days.forEach(day => {
                    transportSchedule[key].push({
                        bookingId: booking.id,
                        bookingRef: booking.bookingRef || booking.id,
                        tourName: booking.tourName,
                        date: day,
                        route: transport.route,
                        pickupTime: transport.pickupTime,
                        status: booking.status || 'pending',
                        pax: booking.pax
                    });
                    totalAssignments++;
                });
            });
        });
        
        document.getElementById('transportCount').textContent = `${totalAssignments} assignments`;
        
        if (Object.keys(transportSchedule).length === 0) {
            container.innerHTML = '<div class="no-data-message">No transport assignments found</div>';
            return;
        }
        
        renderSingleDayTimeline(container, transportSchedule, 'Transport', 'transport');
    }
    
    // Guide Timeline
    function renderGuideTimeline() {
        const container = document.getElementById('guideTimelineContainer');
        const bookings = JSON.parse(localStorage.getItem('tourixBookings') || '[]');
        
        // Collect all guides
        const guideSchedule = {};
        let totalAssignments = 0;
        
        bookings.forEach(booking => {
            if (!booking.guides || booking.guides.length === 0) return;
            
            booking.guides.forEach(guide => {
                if (!guide.name) return;
                
                const key = guide.name;
                if (!guideSchedule[key]) {
                    guideSchedule[key] = [];
                }
                
                // Use startDate/endDate if available, otherwise fall back to days parsing
                let days = [];
                if (guide.startDate && guide.endDate) {
                    // Generate date range from startDate to endDate
                    const start = new Date(guide.startDate);
                    const end = new Date(guide.endDate);
                    if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
                        let current = new Date(start);
                        while (current <= end) {
                            days.push(current.toISOString().split('T')[0]);
                            current.setDate(current.getDate() + 1);
                        }
                    }
                } else if (guide.days) {
                    // Legacy: parse days string
                    days = parseDays(guide.days, booking);
                }
                
                days.forEach(day => {
                    guideSchedule[key].push({
                        bookingId: booking.id,
                        bookingRef: booking.bookingRef || booking.id,
                        tourName: booking.tourName,
                        date: day,
                        language: guide.language || (Array.isArray(guide.languages) ? guide.languages.join(', ') : guide.languages),
                        status: booking.status || 'pending',
                        pax: booking.pax
                    });
                    totalAssignments++;
                });
            });
        });
        
        document.getElementById('guideCount').textContent = `${totalAssignments} assignments`;
        
        if (Object.keys(guideSchedule).length === 0) {
            container.innerHTML = '<div class="no-data-message">No guide assignments found</div>';
            return;
        }
        
        renderSingleDayTimeline(container, guideSchedule, 'Guide', 'guide');
    }
    
    function renderSingleDayTimeline(container, schedule, labelText, type) {
        let html = '<div class="timeline-grid">';
        
        // Labels column
        html += '<div class="timeline-labels">';
        html += `<div class="label-header">${labelText}</div>`;
        
        Object.keys(schedule).sort().forEach(name => {
            html += `<div class="label-row" title="${name}">${name}</div>`;
        });
        
        html += '</div>';
        
        // Dates section
        html += '<div class="timeline-dates">';
        html += generateDateHeaders();
        
        // Rows
        Object.keys(schedule).sort().forEach(name => {
            html += '<div class="timeline-row">';
            html += generateDateCells();
            
            const assignments = schedule[name];
            
            // Group by date to detect conflicts
            const dateGroups = {};
            assignments.forEach((assignment, idx) => {
                const dateKey = assignment.date;
                if (!dateGroups[dateKey]) {
                    dateGroups[dateKey] = [];
                }
                dateGroups[dateKey].push({ ...assignment, idx });
            });
            
            // Render markers
            Object.entries(dateGroups).forEach(([dateKey, dateAssignments]) => {
                const pos = getDatePosition(dateKey);
                if (pos < 0 || pos >= window.timelineDays) return;
                
                const hasConflict = dateAssignments.length > 1;
                
                dateAssignments.forEach((assignment, stackIdx) => {
                    const statusClass = hasConflict ? 'conflict' : getStatusClass(assignment.status);
                    const offsetTop = stackIdx * 3;
                    
                    const tooltip = `${assignment.tourName} | ${assignment.bookingRef}`;
                    
                    html += `
                        <div class="single-day-marker ${statusClass}" 
                             style="left: ${(pos * 40) + 4}px; top: ${9 + offsetTop}px;"
                             title="${tooltip}"
                             onclick='showBookingModal("${type}", ${JSON.stringify(assignment).replace(/'/g, "&#39;")})'>
                            ${hasConflict ? dateAssignments.length : '✓'}
                        </div>
                    `;
                });
            });
            
            html += '</div>';
        });
        
        html += '</div></div>';
        container.innerHTML = html;
    }
    
    function parseDays(daysStr, booking) {
        const dates = [];
        
        if (!daysStr && booking.travelDates) {
            // Default: use travel date range
            const start = new Date(booking.travelDates.startDate || booking.travelDates.from);
            const end = new Date(booking.travelDates.endDate || booking.travelDates.to);
            
            if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
                let current = new Date(start);
                while (current <= end) {
                    dates.push(current.toISOString().split('T')[0]);
                    current.setDate(current.getDate() + 1);
                }
            }
            return dates;
        }
        
        // Parse day numbers like "1,2,3" or "1-5"
        const parts = daysStr.split(',');
        const startDate = new Date(booking.travelDates?.startDate || booking.travelDates?.from);
        
        if (isNaN(startDate.getTime())) return dates;
        
        parts.forEach(part => {
            part = part.trim();
            if (part.includes('-')) {
                const [start, end] = part.split('-').map(n => parseInt(n.trim()));
                for (let d = start; d <= end; d++) {
                    const date = new Date(startDate);
                    date.setDate(date.getDate() + d - 1);
                    dates.push(date.toISOString().split('T')[0]);
                }
            } else {
                const dayNum = parseInt(part);
                if (!isNaN(dayNum)) {
                    const date = new Date(startDate);
                    date.setDate(date.getDate() + dayNum - 1);
                    dates.push(date.toISOString().split('T')[0]);
                }
            }
        });
        
        return dates;
    }
    
    function detectConflicts(bookings) {
        const conflicts = [];
        
        for (let i = 0; i < bookings.length; i++) {
            for (let j = i + 1; j < bookings.length; j++) {
                const a = bookings[i];
                const b = bookings[j];
                
                const aStart = new Date(a.checkIn);
                const aEnd = new Date(a.checkOut);
                const bStart = new Date(b.checkIn);
                const bEnd = new Date(b.checkOut);
                
                // Check overlap
                if (aStart < bEnd && bStart < aEnd) {
                    if (!conflicts.includes(i)) conflicts.push(i);
                    if (!conflicts.includes(j)) conflicts.push(j);
                }
            }
        }
        
        return conflicts;
    }
    
    function getStatusClass(status) {
        switch (status) {
            case 'completed': return 'confirmed';
            case 'confirmed': return 'received';
            case 'processing': return 'processing';
            default: return 'processing';
        }
    }
    
    function formatDate(dateStr) {
        if (!dateStr) return '-';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { 
            weekday: 'short', 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
    }
    
    function getStatusLabel(status) {
        switch (status) {
            case 'completed': return 'Confirmed';
            case 'confirmed': return 'Received';
            case 'processing': return 'Processing';
            default: return 'Processing';
        }
    }
    
    function showBookingModal(type, data) {
        const modal = document.getElementById('bookingModalOverlay');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');
        
        let html = '';
        
        if (type === 'hotel') {
            title.textContent = 'Hotel Booking Details';
            html = `
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Booking Ref:</span>
                    <span class="booking-detail-value">${data.bookingRef}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Tour:</span>
                    <span class="booking-detail-value">${data.tourName || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Check-in:</span>
                    <span class="booking-detail-value">${formatDate(data.checkIn)}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Check-out:</span>
                    <span class="booking-detail-value">${formatDate(data.checkOut)}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Room Type:</span>
                    <span class="booking-detail-value">${data.roomType || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Rooms:</span>
                    <span class="booking-detail-value">${data.rooms || 1}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Pax:</span>
                    <span class="booking-detail-value">${data.pax || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Status:</span>
                    <span class="booking-detail-value">${getStatusLabel(data.status)}</span>
                </div>
            `;
        } else if (type === 'transport') {
            title.textContent = 'Transport Assignment Details';
            html = `
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Booking Ref:</span>
                    <span class="booking-detail-value">${data.bookingRef}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Tour:</span>
                    <span class="booking-detail-value">${data.tourName || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Date:</span>
                    <span class="booking-detail-value">${formatDate(data.date)}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Route:</span>
                    <span class="booking-detail-value">${data.route || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Pickup Time:</span>
                    <span class="booking-detail-value">${data.pickupTime || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Pax:</span>
                    <span class="booking-detail-value">${data.pax || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Status:</span>
                    <span class="booking-detail-value">${getStatusLabel(data.status)}</span>
                </div>
            `;
        } else if (type === 'guide') {
            title.textContent = 'Guide Assignment Details';
            html = `
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Booking Ref:</span>
                    <span class="booking-detail-value">${data.bookingRef}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Tour:</span>
                    <span class="booking-detail-value">${data.tourName || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Date:</span>
                    <span class="booking-detail-value">${formatDate(data.date)}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Language:</span>
                    <span class="booking-detail-value">${data.language || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Pax:</span>
                    <span class="booking-detail-value">${data.pax || '-'}</span>
                </div>
                <div class="booking-detail-row">
                    <span class="booking-detail-label">Status:</span>
                    <span class="booking-detail-value">${getStatusLabel(data.status)}</span>
                </div>
            `;
        }
        
        html += `
            <div style="margin-top: 20px; text-align: center;">
                <button class="date-nav-btn" onclick="openBookingDetails('${data.bookingId}')">
                    <i class="fas fa-external-link-alt"></i> Open Booking
                </button>
            </div>
        `;
        
        content.innerHTML = html;
        modal.classList.add('show');
    }
    
    window.showBookingModal = showBookingModal;
    
    window.closeBookingModal = function(event) {
        if (event && event.target !== event.currentTarget) return;
        document.getElementById('bookingModalOverlay').classList.remove('show');
    };
    
    window.openBookingDetails = function(bookingId) {
        window.closeBookingModal();
        // Navigate to booking confirmation
        if (window.loadContent) {
            window.currentBookingId = bookingId;
            window.loadContent('booking-confirmation');
        }
    };
    
    window.exportTimeline = function() {
        const bookings = JSON.parse(localStorage.getItem('tourixBookings') || '[]');
        
        let csv = 'Type,Resource,Booking Ref,Tour Name,Start Date,End Date,Status,Pax\n';
        
        bookings.forEach(booking => {
            // Hotels
            if (booking.hotels) {
                booking.hotels.forEach(hotel => {
                    csv += `Hotel,"${hotel.hotelName || ''}","${booking.bookingRef || booking.id}","${booking.tourName || ''}",${hotel.checkIn || ''},${hotel.checkOut || ''},${booking.status || ''},${booking.pax || ''}\n`;
                });
            }
            
            // Transports
            if (booking.transports) {
                booking.transports.forEach(transport => {
                    const days = parseDays(transport.days || '', booking);
                    days.forEach(day => {
                        csv += `Transport,"${transport.company || ''}","${booking.bookingRef || booking.id}","${booking.tourName || ''}",${day},,${booking.status || ''},${booking.pax || ''}\n`;
                    });
                });
            }
            
            // Guides
            if (booking.guides) {
                booking.guides.forEach(guide => {
                    const days = parseDays(guide.days || '', booking);
                    days.forEach(day => {
                        csv += `Guide,"${guide.name || ''}","${booking.bookingRef || booking.id}","${booking.tourName || ''}",${day},,${booking.status || ''},${booking.pax || ''}\n`;
                    });
                });
            }
        });
        
        // Download
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `operation-timeline-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };
    
    window.loadSampleData = function() {
        const today = new Date();
        const formatDateStr = (d) => d.toISOString().split('T')[0];
        
        // Helper to add days
        const addDays = (date, days) => {
            const result = new Date(date);
            result.setDate(result.getDate() + days);
            return result;
        };
        
        const sampleBookings = [
            {
                id: 'SAMPLE-001',
                bookingRef: 'TRX-2024-001',
                tourName: 'Classic Japan 7D6N',
                status: 'completed',
                pax: 4,
                travelDates: {
                    startDate: formatDateStr(addDays(today, 2)),
                    endDate: formatDateStr(addDays(today, 8))
                },
                hotels: [
                    {
                        hotelName: 'Hotel Gracery Shinjuku',
                        checkIn: formatDateStr(addDays(today, 2)),
                        checkOut: formatDateStr(addDays(today, 5)),
                        roomType: 'Twin Room',
                        rooms: 2
                    },
                    {
                        hotelName: 'Kyoto Brighton Hotel',
                        checkIn: formatDateStr(addDays(today, 5)),
                        checkOut: formatDateStr(addDays(today, 8)),
                        roomType: 'Superior Twin',
                        rooms: 2
                    }
                ],
                guides: [
                    { name: 'Mr. Tanaka Hiroshi', language: 'English', days: '1,2,3' },
                    { name: 'Ms. Sato Yuki', language: 'English', days: '4,5,6,7' }
                ],
                transports: [
                    { company: 'JR Bus Kanto', vehicleType: '45-Seater Bus', route: 'Narita Airport → Shinjuku', days: '1', pickupTime: '10:00' },
                    { company: 'Nippon Express', vehicleType: 'Minivan', route: 'Tokyo → Kyoto', days: '4', pickupTime: '08:30' },
                    { company: 'MK Taxi Kyoto', vehicleType: 'Sedan', route: 'Kyoto → Kansai Airport', days: '7', pickupTime: '14:00' }
                ]
            },
            {
                id: 'SAMPLE-002',
                bookingRef: 'TRX-2024-002',
                tourName: 'Korea Winter Special',
                status: 'confirmed',
                pax: 6,
                travelDates: {
                    startDate: formatDateStr(addDays(today, 5)),
                    endDate: formatDateStr(addDays(today, 10))
                },
                hotels: [
                    {
                        hotelName: 'Lotte Hotel Seoul',
                        checkIn: formatDateStr(addDays(today, 5)),
                        checkOut: formatDateStr(addDays(today, 8)),
                        roomType: 'Deluxe Room',
                        rooms: 3
                    },
                    {
                        hotelName: 'Paradise Hotel Busan',
                        checkIn: formatDateStr(addDays(today, 8)),
                        checkOut: formatDateStr(addDays(today, 10)),
                        roomType: 'Ocean View',
                        rooms: 3
                    }
                ],
                guides: [
                    { name: 'Mr. Kim Jong-su', language: 'English', days: '1-5' }
                ],
                transports: [
                    { company: 'Seoul City Bus', vehicleType: '25-Seater', route: 'Incheon Airport → Seoul', days: '1', pickupTime: '11:00' },
                    { company: 'KTX Transfer', vehicleType: 'Van', route: 'Seoul Station → Busan', days: '4', pickupTime: '09:00' }
                ]
            },
            {
                id: 'SAMPLE-003',
                bookingRef: 'TRX-2024-003',
                tourName: 'Thailand Explorer',
                status: 'processing',
                pax: 2,
                travelDates: {
                    startDate: formatDateStr(addDays(today, -2)),
                    endDate: formatDateStr(addDays(today, 4))
                },
                hotels: [
                    {
                        hotelName: 'Hotel Gracery Shinjuku',
                        checkIn: formatDateStr(addDays(today, 3)),
                        checkOut: formatDateStr(addDays(today, 6)),
                        roomType: 'Standard Twin',
                        rooms: 1
                    }
                ],
                guides: [
                    { name: 'Ms. Somchai Pattaya', language: 'English', days: '1-6' }
                ],
                transports: [
                    { company: 'Bangkok Limousine', vehicleType: 'Sedan', route: 'BKK Airport → Hotel', days: '1', pickupTime: '15:00' },
                    { company: 'Thai Van Service', vehicleType: 'Minivan', route: 'Full Day Tour', days: '2,3,4', pickupTime: '08:00' }
                ]
            },
            {
                id: 'SAMPLE-004',
                bookingRef: 'TRX-2024-004',
                tourName: 'Vietnam Heritage',
                status: 'completed',
                pax: 8,
                travelDates: {
                    startDate: formatDateStr(addDays(today, 10)),
                    endDate: formatDateStr(addDays(today, 17))
                },
                hotels: [
                    {
                        hotelName: 'Sofitel Legend Metropole',
                        checkIn: formatDateStr(addDays(today, 10)),
                        checkOut: formatDateStr(addDays(today, 13)),
                        roomType: 'Premium Room',
                        rooms: 4
                    },
                    {
                        hotelName: 'La Siesta Hoi An',
                        checkIn: formatDateStr(addDays(today, 13)),
                        checkOut: formatDateStr(addDays(today, 17)),
                        roomType: 'Suite',
                        rooms: 4
                    }
                ],
                guides: [
                    { name: 'Mr. Nguyen Van Minh', language: 'English', days: '1-4' },
                    { name: 'Ms. Tran Thi Lan', language: 'English', days: '4-8' }
                ],
                transports: [
                    { company: 'Vietnam Airlines Transfer', vehicleType: '35-Seater Bus', route: 'Hanoi Airport → Hotel', days: '1', pickupTime: '09:30' },
                    { company: 'Halong Bay Cruise', vehicleType: 'Cruise Ship', route: 'Hanoi → Halong Bay', days: '2,3', pickupTime: '07:00' }
                ]
            },
            {
                id: 'SAMPLE-005',
                bookingRef: 'TRX-2024-005',
                tourName: 'Bali Paradise',
                status: 'confirmed',
                pax: 4,
                travelDates: {
                    startDate: formatDateStr(addDays(today, 7)),
                    endDate: formatDateStr(addDays(today, 12))
                },
                hotels: [
                    {
                        hotelName: 'Kyoto Brighton Hotel',
                        checkIn: formatDateStr(addDays(today, 6)),
                        checkOut: formatDateStr(addDays(today, 9)),
                        roomType: 'Garden View',
                        rooms: 2
                    }
                ],
                guides: [
                    { name: 'Mr. Tanaka Hiroshi', language: 'English', days: '1-5' }
                ],
                transports: [
                    { company: 'Bali Transport', vehicleType: 'Minivan', route: 'Ngurah Rai → Ubud', days: '1', pickupTime: '12:00' },
                    { company: 'Bali Transport', vehicleType: 'Minivan', route: 'Daily Tours', days: '2,3,4', pickupTime: '09:00' }
                ]
            }
        ];
        
        // Get existing bookings
        let existingBookings = JSON.parse(localStorage.getItem('tourixBookings') || '[]');
        
        // Remove any previous sample data
        existingBookings = existingBookings.filter(b => !b.id.startsWith('SAMPLE-'));
        
        // Add sample bookings
        existingBookings = [...existingBookings, ...sampleBookings];
        
        // Save to localStorage
        localStorage.setItem('tourixBookings', JSON.stringify(existingBookings));
        
        // Refresh timelines
        renderAllTimelines();
        
        alert('Sample data loaded! The timeline now shows 5 sample bookings with hotels, guides, and transports.');
    };
    
    // Initialize timeline
    initYearSelector();
    window.timelineStartDate = getStartOfWeek(new Date());
    window.updateDateDisplay();
    renderAllTimelines();
}

// =============================================
// OPERATION ARRANGEMENT FUNCTIONS
// =============================================

function initOperationArrangement(attempt = 0) {
    console.log('initOperationArrangement called, attempt:', attempt + 1);
    
    // Check if DOM elements are ready
    const listView = document.getElementById('operationListView');
    const tbody = document.getElementById('operationsTableBody');
    
    if (!listView || !tbody) {
        if (attempt < 5) {
            console.log('DOM not ready, retrying in 150ms...');
            setTimeout(() => initOperationArrangement(attempt + 1), 150);
            return;
        }
        console.error('Could not find operation arrangement elements - may be on wrong page');
        return;
    }
    
    console.log('DOM ready, loading operations table');
    loadOperationsTable();
    updateOperationStats();
    
    // Check if we should open detail view directly (coming from booking-confirmation or clicking on booking ref)
    const shouldOpenDetail = localStorage.getItem('openOperationDetail');
    const operationBooking = localStorage.getItem('currentOperationBooking');
    
    console.log('shouldOpenDetail:', shouldOpenDetail);
    console.log('operationBooking exists:', !!operationBooking);
    
    if (shouldOpenDetail === 'true' && operationBooking) {
        localStorage.removeItem('openOperationDetail');
        const booking = JSON.parse(operationBooking);
        console.log('Opening detail view for booking:', booking.booking_id);
        showOperationDetailView(booking);
    }
    
    // Setup modal functions
    window.showArrangementModal = function(type) {
        const modal = document.getElementById('arrangementModalOverlay');
        const title = document.getElementById('arrangementModalTitle');
        const content = document.getElementById('arrangementModalContent');
        
        let html = '';
        
        if (type === 'hotel') {
            title.textContent = 'Arrange Hotel';
            html = `
                <div class="form-group">
                    <label>Select Booking</label>
                    <select id="arrangeBookingSelect">
                        <option value="">-- Select Booking --</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Hotel Name</label>
                    <input type="text" id="arrangeHotelName" placeholder="Enter hotel name">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Check-in Date</label>
                        <input type="date" id="arrangeCheckIn">
                    </div>
                    <div class="form-group">
                        <label>Check-out Date</label>
                        <input type="date" id="arrangeCheckOut">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Room Type</label>
                        <select id="arrangeRoomType">
                            <option value="Standard">Standard</option>
                            <option value="Superior">Superior</option>
                            <option value="Deluxe">Deluxe</option>
                            <option value="Suite">Suite</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Number of Rooms</label>
                        <input type="number" id="arrangeRooms" value="1" min="1">
                    </div>
                </div>
                <div class="form-group">
                    <label>Notes</label>
                    <textarea id="arrangeNotes" rows="3" placeholder="Special requests or notes..."></textarea>
                </div>
            `;
        } else if (type === 'transport') {
            title.textContent = 'Arrange Transport';
            html = `
                <div class="form-group">
                    <label>Select Booking</label>
                    <select id="arrangeBookingSelect">
                        <option value="">-- Select Booking --</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Transport Company</label>
                    <input type="text" id="arrangeCompany" placeholder="Enter company name">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Vehicle Type</label>
                        <select id="arrangeVehicle">
                            <option value="Sedan">Sedan</option>
                            <option value="Minivan">Minivan</option>
                            <option value="Van">Van</option>
                            <option value="25-Seater Bus">25-Seater Bus</option>
                            <option value="45-Seater Bus">45-Seater Bus</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Service Days</label>
                        <input type="text" id="arrangeDays" placeholder="e.g. 1,2,3 or 1-5">
                    </div>
                </div>
                <div class="form-group">
                    <label>Route / Description</label>
                    <input type="text" id="arrangeRoute" placeholder="e.g. Airport → Hotel">
                </div>
                <div class="form-group">
                    <label>Pickup Time</label>
                    <input type="time" id="arrangePickupTime">
                </div>
            `;
        } else if (type === 'guide') {
            title.textContent = 'Assign Guide';
            html = `
                <div class="form-group">
                    <label>Select Booking</label>
                    <select id="arrangeBookingSelect">
                        <option value="">-- Select Booking --</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Guide Name</label>
                    <input type="text" id="arrangeGuideName" placeholder="Enter guide name">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Language</label>
                        <select id="arrangeLanguage">
                            <option value="English">English</option>
                            <option value="Chinese">Chinese</option>
                            <option value="Japanese">Japanese</option>
                            <option value="Korean">Korean</option>
                            <option value="Thai">Thai</option>
                            <option value="Spanish">Spanish</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Service Days</label>
                        <input type="text" id="arrangeGuideDays" placeholder="e.g. 1,2,3 or 1-5">
                    </div>
                </div>
                <div class="form-group">
                    <label>Contact Number</label>
                    <input type="tel" id="arrangeGuidePhone" placeholder="Enter phone number">
                </div>
            `;
        } else if (type === 'restaurant') {
            title.textContent = 'Book Restaurant';
            html = `
                <div class="form-group">
                    <label>Select Booking</label>
                    <select id="arrangeBookingSelect">
                        <option value="">-- Select Booking --</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Restaurant Name</label>
                    <input type="text" id="arrangeRestaurant" placeholder="Enter restaurant name">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Date</label>
                        <input type="date" id="arrangeRestDate">
                    </div>
                    <div class="form-group">
                        <label>Time</label>
                        <input type="time" id="arrangeRestTime">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Meal Type</label>
                        <select id="arrangeMealType">
                            <option value="Breakfast">Breakfast</option>
                            <option value="Lunch">Lunch</option>
                            <option value="Dinner">Dinner</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Number of Pax</label>
                        <input type="number" id="arrangeRestPax" value="1" min="1">
                    </div>
                </div>
                <div class="form-group">
                    <label>Special Requests</label>
                    <textarea id="arrangeRestNotes" rows="2" placeholder="Dietary requirements, etc."></textarea>
                </div>
            `;
        }
        
        html += `
            <div class="modal-actions">
                <button class="btn-cancel" onclick="closeArrangementModal()">Cancel</button>
                <button class="btn-save" onclick="saveArrangement('${type}')">Save Arrangement</button>
            </div>
        `;
        
        content.innerHTML = html;
        modal.classList.add('show');
        
        // Populate booking dropdown
        populateBookingDropdown();
    };
    
    window.closeArrangementModal = function(event) {
        if (event && event.target !== event.currentTarget) return;
        document.getElementById('arrangementModalOverlay').classList.remove('show');
    };
    
    window.saveArrangement = function(type) {
        alert(`${type.charAt(0).toUpperCase() + type.slice(1)} arrangement saved! (Demo)`);
        closeArrangementModal();
    };
    
    window.filterOperations = function() {
        loadOperationsTable();
    };
    
    window.viewOperationDetails = function(bookingId) {
        window.currentBookingId = bookingId;
        loadContent('booking-confirmation');
    };
    
    window.editOperation = function(bookingId) {
        window.currentBookingId = bookingId;
        loadContent('booking-confirmation');
    };
}

function populateBookingDropdown() {
    const select = document.getElementById('arrangeBookingSelect');
    if (!select) return;
    
    // Use same data source as Booking page
    const bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    
    bookings.forEach(booking => {
        const option = document.createElement('option');
        option.value = booking.booking_id;
        option.textContent = `${booking.booking_id} - ${booking.customer_name || 'Unknown'} (${booking.tour_name || 'Untitled'})`;
        select.appendChild(option);
    });
}

function loadOperationsTable() {
    const tbody = document.getElementById('operationsTableBody');
    if (!tbody) return;
    
    // Use the same data source as Booking page
    const bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const statusFilter = document.getElementById('statusFilter')?.value || 'all';
    const searchTerm = document.getElementById('searchOperations')?.value?.toLowerCase() || '';
    
    // Filter bookings
    let filtered = bookings.filter(booking => {
        const bookingStatus = booking.status || 'confirmed';
        const matchesStatus = statusFilter === 'all' || bookingStatus === statusFilter;
        const matchesSearch = !searchTerm || 
            (booking.tour_name?.toLowerCase().includes(searchTerm)) ||
            (booking.customer_name?.toLowerCase().includes(searchTerm)) ||
            (booking.booking_id?.toLowerCase().includes(searchTerm));
        return matchesStatus && matchesSearch;
    });
    
    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; padding: 40px; color: #6c757d;">
                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 15px; opacity: 0.3;"></i>
                    <p>No operations found</p>
                    <p style="font-size: 12px;">Try adjusting your filters or add bookings first</p>
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = filtered.map(booking => {
        // Use same field names as Booking page
        const startDate = booking.travel_date || booking.arrival_date || '-';
        const endDate = booking.end_date || booking.departure_date || '-';
        const guide = booking.guides?.[0]?.name || '<span style="color:#94a3b8;font-style:italic;">Not assigned</span>';
        const hotelName = booking.hotel_name || '<span style="color:#94a3b8;font-style:italic;">Not assigned</span>';
        const pax = booking.pax_count || booking.pax || '-';
        const customerName = booking.customer_name || 'Unknown';
        const tourName = booking.tour_name || 'Untitled Tour';
        
        const statusClass = booking.status === 'completed' ? 'status-completed' : 
                           booking.status === 'confirmed' ? 'status-confirmed' : 'status-pending';
        const statusLabel = booking.status === 'completed' ? 'Sales Updated' :
                           booking.status === 'confirmed' ? 'Receive from OP' : 'Send to Sales';
        
        // Format date range
        let dateRange = '-';
        if (startDate && startDate !== '-') {
            dateRange = formatDateShort(startDate);
            if (endDate && endDate !== '-') {
                dateRange += ' → ' + formatDateShort(endDate);
            }
        }
        
        // Escape booking ID for use in onclick
        const escapedId = (booking.booking_id || '').replace(/'/g, "\\'");
        
        return `
            <tr>
                <td>
                    <a href="javascript:void(0)" onclick="openOperationBooking('${escapedId}')" 
                       style="color:#4F46E5;font-weight:600;text-decoration:none;cursor:pointer;">
                        ${booking.booking_id}
                    </a>
                </td>
                <td>
                    <div style="font-weight:500;">${customerName}</div>
                    <div style="font-size:12px;color:#64748b;">${tourName}</div>
                </td>
                <td style="font-size:13px;">${dateRange}</td>
                <td style="text-align:center;"><span style="background:#e0f2fe;color:#0284c7;padding:2px 8px;border-radius:12px;font-size:12px;font-weight:600;">${pax}</span></td>
                <td style="font-size:13px;">${hotelName}</td>
                <td style="font-size:13px;">${guide}</td>
                <td><span class="status ${statusClass}">${statusLabel}</span></td>
                <td>
                    <div class="action-icons">
                        <button class="view-btn" onclick="openOperationBooking('${escapedId}')" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="edit-btn" onclick="openOperationBooking('${escapedId}')" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

function updateOperationStats() {
    // Use same data source as Booking page
    const bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    let active = 0;
    let upcoming = 0;
    let pending = 0;
    let completed = 0;
    
    bookings.forEach(booking => {
        const startDate = new Date(booking.travel_date || booking.arrival_date);
        const endDate = new Date(booking.end_date || booking.departure_date);
        
        if (booking.status === 'completed') {
            completed++;
        } else if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime())) {
            if (startDate <= today && endDate >= today) {
                active++;
            } else if (startDate > today) {
                upcoming++;
            }
        }
        
        if (booking.status === 'processing' || booking.status === 'pending') {
            pending++;
        }
    });
    
    const activeEl = document.getElementById('activeToursCount');
    const upcomingEl = document.getElementById('upcomingCount');
    const pendingEl = document.getElementById('pendingTasksCount');
    const completedEl = document.getElementById('completedCount');
    
    if (activeEl) activeEl.textContent = active;
    if (upcomingEl) upcomingEl.textContent = upcoming;
    if (pendingEl) pendingEl.textContent = pending;
    if (completedEl) completedEl.textContent = completed;
}

// Make operation functions globally accessible
window.openOperationBooking = openOperationBooking;
window.backToOperationList = backToOperationList;
window.switchOperationTab = switchOperationTab;
window.updateOperationStatus = updateOperationStatus;
window.saveOperationNotes = saveOperationNotes;
window.saveAllOperationChanges = saveAllOperationChanges;
window.openInBookingConfirmation = openInBookingConfirmation;
window.printOperationSheet = printOperationSheet;

// Make Add functions globally accessible for operation-arrangement page
window.addNewHotel = addNewHotel;
window.addNewGuide = addNewGuide;
window.addNewTransport = addNewTransport;
window.addNewRestaurant = addNewRestaurant;
window.addNewAdmission = addNewAdmission;

// Make edit/update functions globally accessible
window.removeHotel = removeHotel;
window.updateHotelField = updateHotelField;
window.removeGuide = removeGuide;
window.updateGuideField = updateGuideField;
window.removeTransport = removeTransport;
window.updateTransportField = updateTransportField;
window.removeRestaurant = removeRestaurant;
window.updateRestaurantField = updateRestaurantField;
window.removeAdmission = removeAdmission;
window.updateAdmissionField = updateAdmissionField;

// Make render functions globally accessible
window.renderHotelsContainer = renderHotelsContainer;
window.renderGuidesContainer = renderGuidesContainer;
window.renderTransportsContainer = renderTransportsContainer;
window.renderRestaurantsContainer = renderRestaurantsContainer;
window.renderAdmissionsContainer = renderAdmissionsContainer;

// Make booking confirmation functions globally accessible
window.printConfirmation = printConfirmation;
window.saveBookingNotes = saveBookingNotes;

// Print confirmation modal functions
window.openPrintOptions = openPrintOptions;
window.closePrintOptions = closePrintOptions;
window.toggleOptionItem = toggleOptionItem;
window.togglePrintSection = togglePrintSection;
window.toggleEditMode = toggleEditMode;
window.downloadConfirmationPDF = downloadConfirmationPDF;
window.generateConfirmationPDF = generateConfirmationPDF;
window.printConfirmationDoc = printConfirmationDoc;
window.goBackToBooking = goBackToBooking;

// Make autocomplete functions globally accessible
window.showHotelAutocomplete = showHotelAutocomplete;
window.hideHotelAutocomplete = hideHotelAutocomplete;
window.showGuideAutocomplete = showGuideAutocomplete;
window.hideGuideAutocomplete = hideGuideAutocomplete;
window.showTransportAutocomplete = showTransportAutocomplete;
window.hideTransportAutocomplete = hideTransportAutocomplete;
window.showRestaurantAutocomplete = showRestaurantAutocomplete;
window.hideRestaurantAutocomplete = hideRestaurantAutocomplete;
window.showAdmissionAutocomplete = showAdmissionAutocomplete;
window.hideAdmissionAutocomplete = hideAdmissionAutocomplete;

// Make goToOperationArrangement globally accessible
window.goToOperationArrangement = goToOperationArrangement;

// Open booking from Operation Arrangement - navigates to booking confirmation
function openOperationBooking(bookingId) {
    console.log('openOperationBooking called with:', bookingId);
    // Use same data source as Booking page
    const bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const booking = bookings.find(b => b.booking_id === bookingId);
    
    if (booking) {
        // Store current booking
        localStorage.setItem('currentOperationBooking', JSON.stringify(booking));
        // Show the detail view within operation-arrangement page
        showOperationDetailView(booking);
    } else {
        showNotification('Booking not found', 'error');
    }
}

// Show the operation detail view
function showOperationDetailView(booking) {
    console.log('showOperationDetailView called for:', booking?.booking_id);
    
    const listView = document.getElementById('operationListView');
    const detailView = document.getElementById('operationDetailView');
    
    console.log('listView found:', !!listView);
    console.log('detailView found:', !!detailView);
    
    if (!listView || !detailView) {
        console.error('Operation views not found!');
        showNotification('Could not open detail view - please try again', 'error');
        return;
    }
    
    // Hide list, show detail
    listView.style.display = 'none';
    detailView.style.display = 'block';
    
    // Populate detail view with booking data
    populateOperationDetail(booking);
    
    console.log('Detail view displayed successfully');
}

// Go back to operation list view
function backToOperationList() {
    const listView = document.getElementById('operationListView');
    const detailView = document.getElementById('operationDetailView');
    
    if (!listView || !detailView) return;
    
    // Show list, hide detail
    listView.style.display = 'block';
    detailView.style.display = 'none';
    
    // Clear stored operation booking
    localStorage.removeItem('currentOperationBooking');
    
    // Refresh the list
    loadOperationsTable();
}

// Populate operation detail view
function populateOperationDetail(booking) {
    // Store the booking globally so add functions can use it
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    localStorage.setItem('currentOperationBooking', JSON.stringify(booking));
    currentBooking = booking;
    
    // Initialize the global arrays for hotels/guides/etc
    bookingHotels = booking.hotels || [];
    bookingGuides = booking.guides || [];
    bookingTransports = booking.transports || [];
    bookingRestaurants = booking.restaurants || [];
    bookingAdmissions = booking.admissions || [];
    
    // Update header info
    const refEl = document.getElementById('opDetailBookingRef');
    if (refEl) refEl.textContent = booking.booking_id || '-';
    
    // Update banner info
    const customerEl = document.getElementById('opCustomerName');
    const tourEl = document.getElementById('opTourName');
    const travelEl = document.getElementById('opTravelDate');
    const paxEl = document.getElementById('opPaxCount');
    const statusEl = document.getElementById('opBookingStatus');
    
    if (customerEl) customerEl.textContent = booking.customer_name || '-';
    if (tourEl) tourEl.textContent = booking.tour_name || '-';
    if (travelEl) {
        const startDate = formatDateShort(booking.travel_date || booking.arrival_date);
        const endDate = formatDateShort(booking.end_date || booking.departure_date);
        travelEl.textContent = startDate !== '-' ? `${startDate} - ${endDate}` : '-';
    }
    if (paxEl) paxEl.textContent = booking.pax_count || booking.pax || '-';
    if (statusEl) {
        const statusLabels = {
            'confirmed': 'Receive from OP',
            'processing': 'Send to Sales',
            'completed': 'Sales Updated',
            'cancelled': 'Cancelled'
        };
        statusEl.textContent = statusLabels[booking.status] || 'Receive from OP';
    }
    
    // Update progress indicators
    updateOperationProgress(booking);
    
    // Update tab badges
    updateOperationBadges(booking);
    
    // Render using the editable containers (same as booking-confirmation)
    // These will use the global arrays (bookingHotels, bookingGuides, etc.)
    renderHotelsContainer();
    renderGuidesContainer();
    renderTransportsContainer();
    renderRestaurantsContainer();
    renderAdmissionsContainer();
    
    // Load notes
    const notesEl = document.getElementById('opNotes');
    if (notesEl) notesEl.value = booking.operation_notes || '';
    
    // Highlight current status button
    highlightOperationStatus(booking.status || 'confirmed');
}

// Update progress indicators
function updateOperationProgress(booking) {
    const hotels = booking.hotels || [];
    const guides = booking.guides || [];
    const transports = booking.transports || [];
    const restaurants = booking.restaurants || [];
    const admissions = booking.admissions || [];
    
    updateProgressItem('progressHotel', hotels.length > 0, `${hotels.length} hotel(s)`);
    updateProgressItem('progressGuide', guides.length > 0, `${guides.length} guide(s)`);
    updateProgressItem('progressTransport', transports.length > 0, `${transports.length} vehicle(s)`);
    updateProgressItem('progressRestaurant', restaurants.length > 0, `${restaurants.length} meal(s)`);
    updateProgressItem('progressAdmission', admissions.length > 0, `${admissions.length} ticket(s)`);
}

function updateProgressItem(elementId, isCompleted, text) {
    const el = document.getElementById(elementId);
    if (!el) return;
    
    if (isCompleted) {
        el.classList.add('completed');
        el.querySelector('div:last-child').textContent = text;
    } else {
        el.classList.remove('completed');
    }
}

// Update operation tab badges
function updateOperationBadges(booking) {
    const hotels = booking.hotels || [];
    const guides = booking.guides || [];
    const transports = booking.transports || [];
    const restaurants = booking.restaurants || [];
    const admissions = booking.admissions || [];
    
    const hotelBadge = document.getElementById('opHotelBadge');
    const guideBadge = document.getElementById('opGuideBadge');
    const transportBadge = document.getElementById('opTransportBadge');
    const restaurantBadge = document.getElementById('opRestaurantBadge');
    const admissionBadge = document.getElementById('opAdmissionBadge');
    
    if (hotelBadge) hotelBadge.textContent = hotels.length;
    if (guideBadge) guideBadge.textContent = guides.length;
    if (transportBadge) transportBadge.textContent = transports.length;
    if (restaurantBadge) restaurantBadge.textContent = restaurants.length;
    if (admissionBadge) admissionBadge.textContent = admissions.length;
}

// Switch operation tabs
function switchOperationTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.op-tab').forEach(tab => {
        tab.classList.remove('active');
        tab.style.color = '#64748b';
        tab.style.borderBottomColor = 'transparent';
    });
    
    const activeTab = document.querySelector(`.op-tab[data-tab="${tabName}"]`);
    if (activeTab) {
        activeTab.classList.add('active');
        activeTab.style.color = '#4F46E5';
        activeTab.style.borderBottomColor = '#4F46E5';
    }
    
    // Show/hide content
    document.querySelectorAll('.op-tab-content').forEach(content => {
        content.style.display = 'none';
    });
    
    const tabContent = document.getElementById(`opTab${tabName.charAt(0).toUpperCase() + tabName.slice(1)}`);
    if (tabContent) tabContent.style.display = 'block';
}

// Render operation hotels
function renderOperationHotels(booking) {
    const container = document.getElementById('opHotelsContainer');
    if (!container) return;
    
    const hotels = booking.hotels || [];
    
    if (hotels.length === 0) {
        container.innerHTML = `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-hotel" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No hotels arranged yet</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = hotels.map((hotel, index) => `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;">
            <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:12px;">
                <div>
                    <div style="font-weight:600;color:#1e293b;font-size:15px;">${hotel.name || 'Hotel ' + (index + 1)}</div>
                    <div style="font-size:13px;color:#64748b;">${hotel.location || ''}</div>
                </div>
                <span style="background:${hotel.status === 'confirmed' ? '#dcfce7' : '#fef3c7'};color:${hotel.status === 'confirmed' ? '#166534' : '#92400e'};padding:4px 10px;border-radius:12px;font-size:11px;font-weight:600;">
                    ${hotel.status === 'confirmed' ? 'Confirmed' : 'Pending'}
                </span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;font-size:13px;">
                <div><span style="color:#64748b;">Check-in:</span> ${hotel.check_in || '-'}</div>
                <div><span style="color:#64748b;">Check-out:</span> ${hotel.check_out || '-'}</div>
                <div><span style="color:#64748b;">Room:</span> ${hotel.room_type || '-'}</div>
            </div>
            ${hotel.confirmation_no ? `<div style="margin-top:8px;font-size:12px;color:#64748b;">Conf#: ${hotel.confirmation_no}</div>` : ''}
        </div>
    `).join('');
}

// Render operation guides
function renderOperationGuides(booking) {
    const container = document.getElementById('opGuidesContainer');
    if (!container) return;
    
    const guides = booking.guides || [];
    
    if (guides.length === 0) {
        container.innerHTML = `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-user-tie" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No guides assigned yet</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = guides.map((guide, index) => `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;">
            <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:12px;">
                <div style="display:flex;align-items:center;gap:12px;">
                    <div style="width:40px;height:40px;border-radius:50%;background:#0ea5e9;display:flex;align-items:center;justify-content:center;color:white;font-weight:600;">
                        ${(guide.name || 'G')[0].toUpperCase()}
                    </div>
                    <div>
                        <div style="font-weight:600;color:#1e293b;">${guide.name || 'Guide ' + (index + 1)}</div>
                        <div style="font-size:12px;color:#64748b;">${guide.phone || ''}</div>
                    </div>
                </div>
                <span style="background:#e0f2fe;color:#0284c7;padding:4px 10px;border-radius:12px;font-size:11px;font-weight:600;">
                    ${guide.language || 'Guide'}
                </span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;font-size:13px;">
                <div><span style="color:#64748b;">From:</span> ${guide.date_from || '-'}</div>
                <div><span style="color:#64748b;">To:</span> ${guide.date_to || '-'}</div>
            </div>
        </div>
    `).join('');
}

// Render operation transports
function renderOperationTransports(booking) {
    const container = document.getElementById('opTransportsContainer');
    if (!container) return;
    
    const transports = booking.transports || [];
    
    if (transports.length === 0) {
        container.innerHTML = `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-shuttle-van" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No transport arranged yet</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = transports.map((transport, index) => `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;">
            <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:12px;">
                <div>
                    <div style="font-weight:600;color:#1e293b;">${transport.vehicle_type || 'Vehicle ' + (index + 1)}</div>
                    <div style="font-size:12px;color:#64748b;">${transport.company || ''}</div>
                </div>
                <span style="background:#ffedd5;color:#c2410c;padding:4px 10px;border-radius:12px;font-size:11px;font-weight:600;">
                    ${transport.driver_name || 'Assigned'}
                </span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;font-size:13px;">
                <div><span style="color:#64748b;">Driver:</span> ${transport.driver_name || '-'}</div>
                <div><span style="color:#64748b;">Phone:</span> ${transport.driver_phone || '-'}</div>
                <div><span style="color:#64748b;">Plate:</span> ${transport.plate_no || '-'}</div>
                <div><span style="color:#64748b;">Capacity:</span> ${transport.capacity || '-'} pax</div>
            </div>
        </div>
    `).join('');
}

// Render operation restaurants
function renderOperationRestaurants(booking) {
    const container = document.getElementById('opRestaurantsContainer');
    if (!container) return;
    
    const restaurants = booking.restaurants || [];
    
    if (restaurants.length === 0) {
        container.innerHTML = `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-utensils" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No meals planned yet</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = restaurants.map((restaurant, index) => `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;">
            <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:12px;">
                <div>
                    <div style="font-weight:600;color:#1e293b;">${restaurant.name || 'Restaurant ' + (index + 1)}</div>
                    <div style="font-size:12px;color:#64748b;">${restaurant.location || ''}</div>
                </div>
                <span style="background:#fce7f3;color:#be185d;padding:4px 10px;border-radius:12px;font-size:11px;font-weight:600;">
                    ${restaurant.meal_type || 'Meal'}
                </span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;font-size:13px;">
                <div><span style="color:#64748b;">Date:</span> ${restaurant.date || '-'}</div>
                <div><span style="color:#64748b;">Time:</span> ${restaurant.time || '-'}</div>
                <div><span style="color:#64748b;">Phone:</span> ${restaurant.phone || '-'}</div>
            </div>
        </div>
    `).join('');
}

// Render operation admissions
function renderOperationAdmissions(booking) {
    const container = document.getElementById('opAdmissionsContainer');
    if (!container) return;
    
    const admissions = booking.admissions || [];
    
    if (admissions.length === 0) {
        container.innerHTML = `
            <div style="text-align:center;padding:40px;color:#94a3b8;">
                <i class="fas fa-ticket-alt" style="font-size:40px;margin-bottom:12px;opacity:0.5;"></i>
                <p style="margin:0;">No admissions arranged yet</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = admissions.map((admission, index) => `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;">
            <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:12px;">
                <div>
                    <div style="font-weight:600;color:#1e293b;">${admission.venue || 'Admission ' + (index + 1)}</div>
                    <div style="font-size:12px;color:#64748b;">${admission.ticket_type || ''}</div>
                </div>
                <span style="background:#ede9fe;color:#6d28d9;padding:4px 10px;border-radius:12px;font-size:11px;font-weight:600;">
                    ${admission.quantity || 1} ticket(s)
                </span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;font-size:13px;">
                <div><span style="color:#64748b;">Date:</span> ${admission.date || '-'}</div>
                <div><span style="color:#64748b;">Time:</span> ${admission.reservation_time || '-'}</div>
                <div><span style="color:#64748b;">Res#:</span> ${admission.reservation_no || '-'}</div>
            </div>
        </div>
    `).join('');
}

// Highlight current operation status
function highlightOperationStatus(status) {
    document.querySelectorAll('.op-status-btn').forEach(btn => {
        const btnStatus = btn.dataset.status;
        btn.classList.remove('active');
        if (btnStatus === status) {
            btn.classList.add('active');
        }
    });
}

// Update operation status
function updateOperationStatus(newStatus) {
    const bookingData = localStorage.getItem('currentOperationBooking');
    if (!bookingData) return;
    
    const booking = JSON.parse(bookingData);
    booking.status = newStatus;
    
    // Update in localStorage
    localStorage.setItem('currentOperationBooking', JSON.stringify(booking));
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    
    // Update in bookingsList
    let bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const index = bookings.findIndex(b => b.booking_id === booking.booking_id);
    if (index !== -1) {
        bookings[index].status = newStatus;
        localStorage.setItem('bookingsList', JSON.stringify(bookings));
    }
    
    // Update UI
    highlightOperationStatus(newStatus);
    
    const statusEl = document.getElementById('opBookingStatus');
    const statusLabels = {
        'confirmed': 'Receive from OP',
        'processing': 'Send to Sales',
        'completed': 'Sales Updated',
        'cancelled': 'Cancelled'
    };
    if (statusEl) statusEl.textContent = statusLabels[newStatus] || 'Receive from OP';
    
    showNotification(`Status updated to ${statusLabels[newStatus]}`, 'success');
}

// Save operation notes
function saveOperationNotes() {
    const bookingData = localStorage.getItem('currentOperationBooking');
    if (!bookingData) return;
    
    const booking = JSON.parse(bookingData);
    const notesEl = document.getElementById('opNotes');
    
    if (notesEl) {
        booking.operation_notes = notesEl.value;
        
        // Update in localStorage
        localStorage.setItem('currentOperationBooking', JSON.stringify(booking));
        localStorage.setItem('currentBooking', JSON.stringify(booking));
        
        // Update in bookingsList
        let bookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
        const index = bookings.findIndex(b => b.booking_id === booking.booking_id);
        if (index !== -1) {
            bookings[index].operation_notes = booking.operation_notes;
            localStorage.setItem('bookingsList', JSON.stringify(bookings));
        }
        
        showNotification('Notes saved', 'success');
    }
}

// Save all operation changes
function saveAllOperationChanges() {
    const bookingData = localStorage.getItem('currentOperationBooking');
    if (!bookingData) {
        showNotification('No booking loaded', 'error');
        return;
    }
    
    const booking = JSON.parse(bookingData);
    
    // Save all arrays to the booking
    booking.hotels = bookingHotels;
    booking.guides = bookingGuides;
    booking.transports = bookingTransports;
    booking.restaurants = bookingRestaurants;
    booking.admissions = bookingAdmissions;
    
    // Save notes
    const notesEl = document.getElementById('opNotes');
    if (notesEl) booking.operation_notes = notesEl.value;
    
    // Update localStorage
    localStorage.setItem('currentOperationBooking', JSON.stringify(booking));
    localStorage.setItem('currentBooking', JSON.stringify(booking));
    
    // Update the bookingsList to persist across navigation
    updateBookingInList(booking);
    
    // Update progress and badges
    updateOperationProgress(booking);
    updateOperationBadges(booking);
    
    showNotification('All changes saved successfully', 'success');
}

// Open in booking confirmation page
function openInBookingConfirmation() {
    const bookingData = localStorage.getItem('currentOperationBooking');
    if (!bookingData) return;
    
    localStorage.setItem('currentBooking', bookingData);
    loadContent('booking-confirmation');
}

// Print operation sheet
function printOperationSheet() {
    window.print();
}

// Navigate from booking-confirmation to operation-arrangement with the current booking
function goToOperationArrangement() {
    const bookingData = localStorage.getItem('currentBooking');
    if (!bookingData) {
        showNotification('No booking selected', 'error');
        return;
    }
    
    // Store for operation page
    localStorage.setItem('currentOperationBooking', bookingData);
    localStorage.setItem('openOperationDetail', 'true');
    
    // Navigate to operation-arrangement
    loadContent('operation-arrangement');
}

function formatDateShort(dateStr) {
    if (!dateStr || dateStr === '-') return '-';
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return '-';
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}
