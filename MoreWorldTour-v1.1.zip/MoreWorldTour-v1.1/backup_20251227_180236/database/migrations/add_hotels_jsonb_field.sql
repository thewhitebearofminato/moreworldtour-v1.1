-- ==========================================
-- Migration: Add hotels JSONB field to bookings table
-- Date: 2025-12-27
-- Description: Replace individual hotel fields with a JSONB array
--              to support multiple hotels with checkIn/checkOut dates
-- ==========================================

-- Add hotels JSONB column to store array of hotel bookings
ALTER TABLE bookings 
ADD COLUMN hotels JSONB DEFAULT '[]'::jsonb;

-- Add transports JSONB column if not exists (for multiple transports)
ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS transports JSONB DEFAULT '[]'::jsonb;

-- Comment for hotels field
COMMENT ON COLUMN bookings.hotels IS 'Array of hotel bookings with structure: [{ id, name, confirmation_no, tel, address, checkIn, checkOut, room_twn, room_dbl, room_sgl, room_trp, room_other, status, notes }]';

COMMENT ON COLUMN bookings.transports IS 'Array of transport bookings with structure: [{ id, company, vehicle_type, driver, phone, license_plate, startDate, endDate, pickup_time, notes }]';

-- Note: The old single-hotel fields (hotel_name, hotel_confirmation_no, etc.) 
-- are kept for backward compatibility but should be migrated to the hotels JSONB array
