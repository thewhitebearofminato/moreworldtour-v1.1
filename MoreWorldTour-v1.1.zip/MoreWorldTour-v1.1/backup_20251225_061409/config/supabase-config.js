// ==========================================
// TOURIX - Supabase Configuration
// ==========================================

// TODO: Replace these with your actual Supabase credentials
// Get them from: Supabase Dashboard → Settings → API

const SUPABASE_URL = 'https://xokvixmokaltfqdtsblq.supabase.co';  // e.g., https://xxxxx.supabase.co
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhva3ZpeG1va2FsdGZxZHRzYmxxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYyOTgyMjUsImV4cCI6MjA4MTg3NDIyNX0.G33gTdL67-zDj39HYZUAnMDqSNGTLzZKdpidZbmhXAs';  // Long string starting with eyJhbGc...

// Initialize Supabase client
try {
    if (window.supabase && window.supabase.createClient) {
        const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        window.supabaseClient = supabase;
        console.log('✅ Supabase client initialized successfully');
    } else {
        console.error('❌ Supabase library not loaded');
        window.supabaseClient = null;
    }
} catch (error) {
    console.error('❌ Error initializing Supabase:', error);
    window.supabaseClient = null;
}
