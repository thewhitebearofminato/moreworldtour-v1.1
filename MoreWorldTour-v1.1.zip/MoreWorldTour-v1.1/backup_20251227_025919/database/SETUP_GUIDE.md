# TOURIX Database Schema - Setup Guide

## 📊 Database Structure

### Core Tables:

1. **customers** - Customer/company information
2. **quotations** - Main quotation records (itinerary & service types)
3. **itinerary_days** - Day-by-day itinerary for tour packages
4. **activities** - Activities for each itinerary day
5. **pricing_items** - Line items for quotation pricing
6. **bookings** - Confirmed bookings from quotations
7. **user_profiles** - User account information
8. **audit_log** - Track all changes (optional)

---

## 🔗 Relationships

```
customers
    ↓ (1:many)
quotations
    ↓ (1:many)
itinerary_days
    ↓ (1:many)
activities

quotations
    ↓ (1:many)
pricing_items

quotations
    ↓ (1:1)
bookings
```

---

## 📋 Setup Steps in Supabase

### Step 1: Create Supabase Account
1. Go to https://supabase.com
2. Click "Start your project"
3. Sign up with GitHub or email
4. Create a new project
   - Project name: `tourix`
   - Database password: (create a strong password - SAVE THIS!)
   - Region: Choose closest to you
5. Wait 2-3 minutes for project to be ready

### Step 2: Run SQL Schema
1. In your Supabase dashboard, click **SQL Editor** (left sidebar)
2. Click **New query**
3. Copy ALL content from `supabase_schema.sql`
4. Paste into SQL editor
5. Click **Run** button (or press Ctrl+Enter)
6. You should see "Success. No rows returned"

### Step 3: Verify Tables Created
1. Click **Table Editor** (left sidebar)
2. You should see all 8 tables:
   - ✅ customers
   - ✅ quotations
   - ✅ itinerary_days
   - ✅ activities
   - ✅ pricing_items
   - ✅ bookings
   - ✅ user_profiles
   - ✅ audit_log

### Step 4: Get API Credentials
1. Click **Settings** (left sidebar) → **API**
2. Copy these values:
   - **Project URL**: `https://xxxxx.supabase.co`
   - **anon/public key**: `eyJhbGc...` (long string)
3. SAVE THESE - you'll need them in your JavaScript code

---

## 🔑 Key Features

### Auto-incrementing Quote Numbers
- Format: `QT-2025-0001`, `QT-2025-0002`, etc.
- We'll generate this in JavaScript

### Automatic Timestamps
- `created_at` - Set when record is created
- `updated_at` - Updated automatically on changes

### Data Relationships
- Quotations link to customers
- Itinerary days link to quotations
- Activities link to itinerary days
- Cascade deletes (delete quotation = delete all related days/activities)

### Security (RLS)
- Row Level Security enabled
- Users can only access their own organization's data
- Will configure permissions later

---

## 📝 Sample Data

The schema includes 2 sample customers:
- ABC Travel Agency (USA)
- Global Tours Ltd (UK)

You can view them in Table Editor → customers

---

## ⚠️ Important Notes

1. **Database Password**: Save it securely! You'll need it for admin access
2. **API Keys**: Keep them private (don't commit to Git)
3. **Free Tier Limits**: 
   - 500MB database
   - 2GB file storage
   - 50,000 monthly active users
   - Unlimited API requests

---

## 🎯 Next Steps

After running this schema:
1. ✅ Verify all tables created
2. ✅ Get API credentials
3. ➡️ Connect JavaScript to Supabase
4. ➡️ Test saving a quotation
5. ➡️ Build list/edit/delete functions

---

## 🆘 Need Help?

If you get errors:
- Make sure you're in SQL Editor (not Table Editor)
- Run the entire file at once (don't run line by line)
- Check for any typos if you modified the SQL

Schema is ready for deployment! 🚀
