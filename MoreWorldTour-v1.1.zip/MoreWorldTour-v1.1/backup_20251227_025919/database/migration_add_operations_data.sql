-- ==========================================
-- TOURIX - Migration: Add Operations Data
-- Transportation, Restaurant, Admission columns
-- Run this in Supabase SQL Editor
-- ==========================================

-- Add JSONB columns to bookings table for operational data
ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS hotels JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS guides JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS transports JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS restaurants JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS admissions JSONB DEFAULT '[]'::jsonb;

-- Add comments for documentation
COMMENT ON COLUMN bookings.hotels IS 'Array of hotel bookings with room details and workflow status';
COMMENT ON COLUMN bookings.guides IS 'Array of assigned tour guides with contact and schedule';
COMMENT ON COLUMN bookings.transports IS 'Array of transportation assignments (vehicles, drivers)';
COMMENT ON COLUMN bookings.restaurants IS 'Array of restaurant/meal bookings';
COMMENT ON COLUMN bookings.admissions IS 'Array of admission tickets for attractions';

-- ==========================================
-- DIRECTORY TABLES (Master Data)
-- These store reusable entries for autocomplete
-- ==========================================

-- Transport Directory
CREATE TABLE IF NOT EXISTS transport_directory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company VARCHAR(255) NOT NULL,
    vehicle_type VARCHAR(100),
    driver_name VARCHAR(255),
    driver_phone VARCHAR(50),
    license_plate VARCHAR(50),
    capacity INTEGER,
    notes TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transport_company ON transport_directory(company);

-- Restaurant Directory
CREATE TABLE IF NOT EXISTS restaurant_directory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    cuisine VARCHAR(100),
    location VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    price_range VARCHAR(10),
    capacity INTEGER,
    notes TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_restaurant_name ON restaurant_directory(name);
CREATE INDEX IF NOT EXISTS idx_restaurant_location ON restaurant_directory(location);

-- Admission/Attraction Directory
CREATE TABLE IF NOT EXISTS admission_directory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    adult_price DECIMAL(10,2) DEFAULT 0,
    child_price DECIMAL(10,2) DEFAULT 0,
    currency VARCHAR(10) DEFAULT 'THB',
    opening_hours VARCHAR(100),
    notes TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_admission_name ON admission_directory(name);
CREATE INDEX IF NOT EXISTS idx_admission_location ON admission_directory(location);

-- Hotel Directory (if not exists)
CREATE TABLE IF NOT EXISTS hotel_directory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    star_rating INTEGER,
    notes TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_hotel_name ON hotel_directory(name);

-- Guide Directory (if not exists)
CREATE TABLE IF NOT EXISTS guide_directory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    languages VARCHAR(255),
    license_number VARCHAR(100),
    specialties TEXT,
    notes TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_guide_name ON guide_directory(name);

-- ==========================================
-- SAMPLE DATA (Optional - for testing)
-- ==========================================

-- Insert sample transport companies
INSERT INTO transport_directory (company, vehicle_type, driver_name, driver_phone, license_plate, capacity) VALUES
('Bangkok Van Service', 'Van 10 Seats', 'Mr. Somchai', '+66 81 111 2222', 'กข 1234', 10),
('Thai Luxury Coach', 'Bus 40 Seats', 'Mr. Prasert', '+66 82 333 4444', 'ขค 5678', 40),
('VIP Transport BKK', 'Alphard 6 Seats', 'Mr. Wichai', '+66 83 555 6666', 'คง 9012', 6),
('Phuket Transfer', 'Van 10 Seats', 'Mr. Anuchai', '+66 84 777 8888', 'จฉ 3456', 10),
('Chiang Mai Van', 'Van 10 Seats', 'Mr. Nattapong', '+66 85 999 0000', 'ชซ 7890', 10)
ON CONFLICT DO NOTHING;

-- Insert sample restaurants
INSERT INTO restaurant_directory (name, cuisine, location, phone, price_range) VALUES
('Sala Rim Naam', 'Thai', 'Bangkok', '+66 2 659 9000', '$$$'),
('Blue Elephant', 'Thai Fine Dining', 'Bangkok', '+66 2 673 9353', '$$$'),
('Baan Khanitha', 'Thai', 'Bangkok', '+66 2 258 4181', '$$'),
('Khao Soi Khun Yai', 'Northern Thai', 'Chiang Mai', '+66 53 814 148', '$'),
('The Cliff', 'Italian/Thai', 'Phuket', '+66 76 344 254', '$$$')
ON CONFLICT DO NOTHING;

-- Insert sample attractions
INSERT INTO admission_directory (name, location, adult_price, child_price, currency) VALUES
('Grand Palace', 'Bangkok', 500, 0, 'THB'),
('Wat Pho', 'Bangkok', 200, 0, 'THB'),
('Safari World', 'Bangkok', 1500, 1200, 'THB'),
('Doi Suthep Temple', 'Chiang Mai', 50, 20, 'THB'),
('Phi Phi Islands Tour', 'Phuket', 1800, 1200, 'THB'),
('Elephant Sanctuary', 'Chiang Mai', 2500, 1800, 'THB'),
('Alcazar Cabaret Show', 'Pattaya', 800, 600, 'THB')
ON CONFLICT DO NOTHING;

-- ==========================================
-- RLS POLICIES (Row Level Security)
-- ==========================================

-- Enable RLS on new tables
ALTER TABLE transport_directory ENABLE ROW LEVEL SECURITY;
ALTER TABLE restaurant_directory ENABLE ROW LEVEL SECURITY;
ALTER TABLE admission_directory ENABLE ROW LEVEL SECURITY;
ALTER TABLE hotel_directory ENABLE ROW LEVEL SECURITY;
ALTER TABLE guide_directory ENABLE ROW LEVEL SECURITY;

-- Allow read access to all authenticated users
CREATE POLICY "Allow read access to transport_directory" ON transport_directory
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access to restaurant_directory" ON restaurant_directory
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access to admission_directory" ON admission_directory
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access to hotel_directory" ON hotel_directory
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow read access to guide_directory" ON guide_directory
    FOR SELECT USING (auth.role() = 'authenticated');

-- Allow full access for admin/manager roles (customize as needed)
CREATE POLICY "Allow full access to transport_directory for managers" ON transport_directory
    FOR ALL USING (true);

CREATE POLICY "Allow full access to restaurant_directory for managers" ON restaurant_directory
    FOR ALL USING (true);

CREATE POLICY "Allow full access to admission_directory for managers" ON admission_directory
    FOR ALL USING (true);

CREATE POLICY "Allow full access to hotel_directory for managers" ON hotel_directory
    FOR ALL USING (true);

CREATE POLICY "Allow full access to guide_directory for managers" ON guide_directory
    FOR ALL USING (true);

-- ==========================================
-- DONE! 
-- After running this migration:
-- 1. Refresh your Supabase schema
-- 2. The bookings table now has JSONB columns for all operations data
-- 3. Directory tables are ready for master data management
-- ==========================================
