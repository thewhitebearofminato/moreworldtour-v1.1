// ==========================================
// TOURIX - Supabase Configuration
// ==========================================

// TODO: Replace these with your actual Supabase credentials
// Get them from: Supabase Dashboard → Settings → API

const SUPABASE_URL = 'https://xokvixmokaltfqdtsblq.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhva3ZpeG1va2FsdGZxZHRzYmxxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYyOTgyMjUsImV4cCI6MjA4MTg3NDIyNX0.G33gTdL67-zDj39HYZUAnMDqSNGTLzZKdpidZbmhXAs';

// Initialize Supabase client. Support both global `createClient` and
// `window.supabase.createClient` (depending on how the lib is loaded).
try {
    let supabaseClient = null;
    if (typeof createClient === 'function') {
        supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    } else if (window.supabase && typeof window.supabase.createClient === 'function') {
        supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    } else {
        console.error('❌ Supabase client factory not found. Include @supabase/supabase-js or the CDN script.');
    }
    window.supabaseClient = supabaseClient;
    if (supabaseClient) console.log('✅ Supabase client initialized successfully');
} catch (error) {
    console.error('❌ Error initializing Supabase:', error);
    window.supabaseClient = null;
}
