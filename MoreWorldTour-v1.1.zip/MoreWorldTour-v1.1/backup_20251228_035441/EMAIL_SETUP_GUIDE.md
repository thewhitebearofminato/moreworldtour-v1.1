# Email Sending Setup Guide - Resend + Supabase

## Step 1: Sign Up for Resend

1. Go to [resend.com](https://resend.com)
2. Sign up for a free account (100 emails/day)
3. Verify your email address

## Step 2: Get Your Resend API Key

1. Log in to Resend dashboard
2. Go to **API Keys** section
3. Click **Create API Key**
4. Name it: `TOURIX-Production`
5. Copy the API key (starts with `re_...`)
6. ⚠️ **Save it securely - you won't see it again!**

## Step 3: Add Verified Sender Domain (Optional but Recommended)

### Option A: Use Resend's Testing Domain (Quick Start)
- Email from: `onboarding@resend.dev`
- Good for testing, has Resend branding
- No setup needed

### Option B: Use Your Own Domain (Professional)
1. In Resend dashboard, go to **Domains**
2. Click **Add Domain**
3. Enter your domain (e.g., `tourix.com`)
4. Add DNS records to your domain provider:
   - SPF record
   - DKIM record
5. Wait for verification (usually 5-30 minutes)
6. Send from: `noreply@yourdomain.com`

## Step 4: Install Supabase CLI

```powershell
# Install Supabase CLI
npm install -g supabase

# Verify installation
supabase --version
```

## Step 5: Login to Supabase

```powershell
# Login to your Supabase account
supabase login

# Link to your project
cd C:\Backup\TOURIX
supabase link --project-ref YOUR_PROJECT_REF

# Get your project ref from: https://supabase.com/dashboard/project/_/settings/general
# It's in the URL: https://supabase.com/dashboard/project/xokvixmokaltfqdtsblq/...
#                                                          ^^^^^^^^^^^^^^^^^^^^
```

## Step 6: Set Resend API Key in Supabase

```powershell
# Set the secret in Supabase
supabase secrets set RESEND_API_KEY=re_YOUR_API_KEY_HERE

# Verify it's set
supabase secrets list
```

## Step 7: Deploy the Edge Function

```powershell
cd C:\Backup\TOURIX

# Deploy the function
supabase functions deploy send-confirmation

# Expected output:
# ✓ Deployed Function send-confirmation
# Function URL: https://xokvixmokaltfqdtsblq.supabase.co/functions/v1/send-confirmation
```

## Step 8: Update Frontend Code

The frontend code is already prepared! Just update the sender email in:

`supabase/functions/send-confirmation/index.ts` line 103:
```typescript
from: 'TOURIX <noreply@yourdomain.com>', // Change to your verified domain
```

If using Resend test domain:
```typescript
from: 'TOURIX <onboarding@resend.dev>',
```

## Step 9: Test Email Sending

1. Refresh your TOURIX dashboard
2. Go to a booking
3. Click **Send Confirmation**
4. Enter your email address
5. Click **Send Now**
6. Check your inbox! ✉️

## Troubleshooting

### "RESEND_API_KEY not configured"
```powershell
# Set the key again
supabase secrets set RESEND_API_KEY=re_YOUR_KEY_HERE

# Redeploy function
supabase functions deploy send-confirmation
```

### "Failed to send email"
- Check API key is correct
- Verify domain is set up (if using custom domain)
- Check Resend dashboard for error logs

### "CORS error"
- Edge function already has CORS headers
- Make sure you deployed the latest version

### "Function not found"
```powershell
# Ensure function is deployed
supabase functions deploy send-confirmation

# Check function list
supabase functions list
```

## Resend Free Tier Limits

- ✅ 100 emails/day
- ✅ 3,000 emails/month
- ✅ Attachments supported (up to 40MB)
- ✅ Professional email templates
- ✅ Email analytics & tracking

## Next Steps (Paid Plans)

**Resend Pro** - $20/month:
- 50,000 emails/month
- Custom DKIM
- Advanced analytics
- Priority support

## Email Quota Monitoring

Check your usage in Resend Dashboard:
- Daily sends
- Monthly sends
- Bounce rate
- Open rate (if tracking enabled)

---

## Quick Reference Commands

```powershell
# Deploy function
supabase functions deploy send-confirmation

# View logs (real-time)
supabase functions logs send-confirmation --follow

# Set secret
supabase secrets set RESEND_API_KEY=your_key

# List functions
supabase functions list

# Delete function (if needed)
supabase functions delete send-confirmation
```

---

**Support:**
- Resend Docs: https://resend.com/docs
- Supabase Edge Functions: https://supabase.com/docs/guides/functions
- TOURIX Support: info@tourix.com
