# Deploy Email Function - Quick Guide

## You have: ✅ Resend API Key

## Now follow these steps:

### Step 1: Open Supabase Dashboard
1. Go to: **https://supabase.com/dashboard/project/xokvixmokaltfqdtsblq/functions**
2. Click "**New Edge Function**" button

### Step 2: Create Function
1. Name: `send-confirmation`
2. Click "**Create function**"

### Step 3: Copy the Function Code
1. Open this file: `C:\Backup\TOURIX\supabase\functions\send-confirmation\index.ts`
2. Select ALL the code (Ctrl+A)
3. Copy it (Ctrl+C)
4. Paste into the Supabase editor
5. **IMPORTANT:** On line 103, change:
   ```typescript
   from: 'TOURIX <onboarding@resend.dev>',  // Change to your verified email
   ```
   
   To use Resend's test domain:
   ```typescript
   from: 'TOURIX <onboarding@resend.dev>',
   ```
   
   OR if you verified your own domain in Resend:
   ```typescript
   from: 'TOURIX <noreply@yourdomain.com>',
   ```

### Step 4: Add Your Resend API Key
1. In the function editor, look for "**Environment Variables**" or "**Secrets**" section
2. Click "**Add Secret**" or "**+ New Secret**"
3. Enter:
   - **Name:** `RESEND_API_KEY`
   - **Value:** Your Resend API key (starts with `re_...`)
4. Click "**Save**"

### Step 5: Deploy
1. Click "**Deploy**" button (usually green button at top right)
2. Wait 10-30 seconds for deployment
3. You should see: ✅ "Successfully deployed"

### Step 6: Test It!
1. Go back to your TOURIX app: **http://localhost:3000**
2. Navigate to a booking
3. Add customer email (click Edit button next to Email field)
4. Click "**Send Confirmation**" button
5. Fill in the email
6. Click "**Send Now**"
7. Check your inbox! 📧

---

## Troubleshooting

### "RESEND_API_KEY not configured"
- Make sure you added the secret in Step 4
- Redeploy the function

### "Failed to send email"
- Check your Resend API key is correct
- Make sure you didn't exceed the 100 emails/day limit
- Check Resend dashboard for error logs

### Email not arriving
- Check spam folder
- Verify recipient email is correct
- Check Resend dashboard for delivery status

### CORS Error
- The function already has CORS headers
- Make sure you deployed the complete code

---

## Quick Reference

**Supabase Functions URL:**
https://supabase.com/dashboard/project/xokvixmokaltfqdtsblq/functions

**Resend Dashboard:**
https://resend.com/emails

**Function URL (after deploy):**
https://xokvixmokaltfqdtsblq.supabase.co/functions/v1/send-confirmation

---

**Need Help?**
- Supabase Docs: https://supabase.com/docs/guides/functions
- Resend Docs: https://resend.com/docs
