﻿// ==========================================
// TOURIX - Main Application Script
// ==========================================

// Current page state
let currentPage = 'dashboard';

// ==========================================
// Dynamic Content Loading
// ==========================================
async function loadContent(page) {
    const contentArea = document.getElementById('contentArea');
    const headerTitle = document.querySelector('.header-left h1');
    const breadcrumb = document.querySelector('.breadcrumb');
    
    // Show loading spinner
    contentArea.innerHTML = `
        <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading...</p>
        </div>
    `;
    
    try {
        // Fetch content from the content folder
        const response = await fetch(`content/${page}.html`);
        
        if (!response.ok) {
            throw new Error('Page not found');
        }
        
        const html = await response.text();
        contentArea.innerHTML = html;
        
        // Update page title mapping
        const pageTitles = {
            'dashboard': 'Dashboard',
            'quotations': 'Quotations',
            'quotation-itinerary': 'Quotation with Itinerary',
            'quotation-service': 'Quotation by Service',
            'booking': 'Booking',
            'operation': 'Operation',
            'tour-product': 'Tour Product',
            'financial': 'Financial',
            'directory': 'Directory'
        };
        
        // Update header
        const title = pageTitles[page] || page.charAt(0).toUpperCase() + page.slice(1);
        if (headerTitle) headerTitle.textContent = title;
        if (breadcrumb) breadcrumb.textContent = `Overview / ${title}`;
        
        // Update active nav item
        updateActiveNavItem(page);
        
        // Update current page
        currentPage = page;
        
        // Initialize page-specific scripts
        initPageScripts(page);
        
        // Scroll to top
        contentArea.scrollTop = 0;
        
    } catch (error) {
        contentArea.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Page Not Found</h3>
                <p>The requested page could not be loaded.</p>
                <button class="btn-primary" onclick="loadContent('dashboard')">
                    <i class="fas fa-home"></i> Back to Dashboard
                </button>
            </div>
        `;
        console.error('Error loading content:', error);
    }
}

// Update active navigation item
function updateActiveNavItem(page) {
    const navItems = document.querySelectorAll('.nav-menu .nav-item');
    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) {
            item.classList.add('active');
        }
    });
}

// Initialize page-specific scripts after content loads
function initPageScripts(page) {
    try {
        if (page === 'dashboard') {
            initDashboardCharts();
            initContactFilters();
        } else if (page === 'quotation-itinerary') {
            initQuotePage();
        } else if (page === 'quotation-service') {
            initQuotePage();
        }
    } catch (error) {
        console.error('Error initializing page scripts:', error);
    }
}

// ==========================================
// Quotation Page Functions (New Design)
// ==========================================
let dayCounter = 1;

function initQuotePage() {
    try {
        const today = new Date();
        const validDate = new Date(today);
        validDate.setDate(validDate.getDate() + 30);
        
        // Set dates
        const qDate = document.getElementById('quotationDate');
        const vDate = document.getElementById('validUntil');
        const tDate = document.getElementById('travelDate');
        
        if (qDate) qDate.value = formatDateForInput(today);
        if (vDate) vDate.value = formatDateForInput(validDate);
        if (tDate) tDate.value = formatDateForInput(today);
        
        // Generate quote number
        const quoteNum = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const qNumField = document.getElementById('quotationNumber');
        const qNumDisplay = document.getElementById('displayQuoteId');
        if (qNumField) qNumField.value = quoteNum;
        if (qNumDisplay) qNumDisplay.textContent = quoteNum;
        
        // Set first day date
        const firstDayDate = document.querySelector('.itinerary-day .day-date');
        if (firstDayDate) {
            firstDayDate.value = formatDateForInput(today);
            updateDayDisplay(firstDayDate);
        }
        
        dayCounter = document.querySelectorAll('.itinerary-day').length || 1;
    } catch (err) {
        console.error('Error in initQuotePage:', err);
    }
}

function formatDateForInput(date) {
    return date.toISOString().split('T')[0];
}

function getDayName(dateStr) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[new Date(dateStr).getDay()];
}

function updateDayDisplay(input) {
    if (!input) return;
    const daySpan = input.parentElement?.querySelector('.day-name');
    if (input.value && daySpan) {
        daySpan.textContent = getDayName(input.value);
    }
}

function toggleMealDetail(checkbox, type) {
    const row = checkbox.closest('.day-row');
    if (!row) return;
    const detailInput = row.querySelector('.meal-' + type + '-detail');
    if (detailInput) {
        detailInput.disabled = !checkbox.checked;
        if (!checkbox.checked) detailInput.value = '';
    }
}

function addActivity(btn) {
    const container = btn.closest('.activities-container');
    if (!container) return;
    const items = container.querySelectorAll('.activity-item');
    const newNum = items.length + 1;
    
    const newItem = document.createElement('div');
    newItem.className = 'activity-item';
    newItem.innerHTML = `
        <span class="activity-num">${newNum}</span>
        <input type="text" class="activity-input" placeholder="Enter activity or sightseeing">
        <button type="button" class="activity-remove-btn" onclick="removeActivity(this)">
            <i class="fas fa-minus"></i>
        </button>
    `;
    container.appendChild(newItem);
}

function removeActivity(btn) {
    const item = btn.closest('.activity-item');
    const container = item?.closest('.activities-container');
    if (container && container.querySelectorAll('.activity-item').length > 1) {
        item.remove();
        container.querySelectorAll('.activity-item').forEach((el, i) => {
            el.querySelector('.activity-num').textContent = i + 1;
        });
    }
}

function addNewDay() {
    const container = document.getElementById('itineraryDays');
    if (!container) return;
    const days = container.querySelectorAll('.itinerary-day');
    dayCounter = days.length + 1;
    
    let nextDate = new Date();
    if (days.length > 0) {
        const lastDate = days[days.length - 1].querySelector('.day-date')?.value;
        if (lastDate) {
            nextDate = new Date(lastDate);
            nextDate.setDate(nextDate.getDate() + 1);
        }
    }
    
    const dayHtml = `
        <div class="itinerary-day" data-day="${dayCounter}">
            <div class="day-header-row">
                <div class="day-number">Day ${dayCounter}</div>
                <div class="day-date-input">
                    <input type="date" class="day-date" value="${formatDateForInput(nextDate)}" onchange="updateDayDisplay(this)">
                    <span class="day-name">${getDayName(nextDate)}</span>
                </div>
                <input type="text" class="day-title" placeholder="Day title">
                <button type="button" class="remove-day-btn" onclick="removeDay(this)" title="Remove Day">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
            <div class="day-content">
                <div class="day-row">
                    <div class="row-label"><i class="fas fa-bed"></i> Hotel</div>
                    <div class="row-inputs">
                        <input type="text" class="hotel-input" placeholder="Hotel name">
                        <select class="star-select">
                            <option value="">Rating</option>
                            <option value="2">★★</option>
                            <option value="3">★★★</option>
                            <option value="4">★★★★</option>
                            <option value="5">★★★★★</option>
                        </select>
                        <input type="text" class="room-type" placeholder="Room type">
                    </div>
                </div>
                <div class="day-row">
                    <div class="row-label"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="row-inputs meals-inputs">
                        <label class="meal-check">
                            <input type="checkbox" class="meal-b" onchange="toggleMealDetail(this, 'b')">
                            <span class="meal-badge">B</span>
                        </label>
                        <input type="text" class="meal-detail meal-b-detail" placeholder="Breakfast" disabled>
                        <label class="meal-check">
                            <input type="checkbox" class="meal-l" onchange="toggleMealDetail(this, 'l')">
                            <span class="meal-badge">L</span>
                        </label>
                        <input type="text" class="meal-detail meal-l-detail" placeholder="Lunch" disabled>
                        <label class="meal-check">
                            <input type="checkbox" class="meal-d" onchange="toggleMealDetail(this, 'd')">
                            <span class="meal-badge">D</span>
                        </label>
                        <input type="text" class="meal-detail meal-d-detail" placeholder="Dinner" disabled>
                    </div>
                </div>
                <div class="day-row activities-row">
                    <div class="row-label"><i class="fas fa-hiking"></i> Activities</div>
                    <div class="activities-container">
                        <div class="activity-item">
                            <span class="activity-num">1</span>
                            <input type="text" class="activity-input" placeholder="Enter activity">
                            <button type="button" class="activity-add-btn" onclick="addActivity(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', dayHtml);
}

function removeDay(btn) {
    const day = btn.closest('.itinerary-day');
    const container = document.getElementById('itineraryDays');
    if (container && container.querySelectorAll('.itinerary-day').length > 1) {
        day.remove();
        container.querySelectorAll('.itinerary-day').forEach((el, i) => {
            el.dataset.day = i + 1;
            el.querySelector('.day-number').textContent = 'Day ' + (i + 1);
        });
    }
}

function addPriceItem() {
    const tbody = document.getElementById('pricingBody');
    if (!tbody) return;
    const row = document.createElement('tr');
    row.innerHTML = `
        <td><input type="text" class="price-desc" placeholder="Service description"></td>
        <td><input type="number" class="price-qty" value="1" min="1" onchange="calcRowTotal(this)"></td>
        <td>
            <select class="price-unit">
                <option value="pax">Per Pax</option>
                <option value="room">Per Room</option>
                <option value="trip">Per Trip</option>
                <option value="day">Per Day</option>
            </select>
        </td>
        <td><input type="number" class="price-rate" placeholder="0.00" step="0.01" onchange="calcRowTotal(this)"></td>
        <td class="row-total">$0.00</td>
        <td><button type="button" class="remove-row-btn" onclick="removePriceRow(this)"><i class="fas fa-times"></i></button></td>
    `;
    tbody.appendChild(row);
}

function removePriceRow(btn) {
    const row = btn.closest('tr');
    const tbody = row?.closest('tbody');
    if (tbody && tbody.querySelectorAll('tr').length > 1) {
        row.remove();
        calcTotals();
    }
}

function calcRowTotal(input) {
    const row = input.closest('tr');
    if (!row) return;
    const qty = parseFloat(row.querySelector('.price-qty')?.value) || 0;
    const rate = parseFloat(row.querySelector('.price-rate')?.value) || 0;
    const total = qty * rate;
    const totalCell = row.querySelector('.row-total');
    if (totalCell) totalCell.textContent = formatCurrency(total);
    calcTotals();
}

function calcTotals() {
    let subtotal = 0;
    document.querySelectorAll('#pricingBody tr').forEach(row => {
        const qty = parseFloat(row.querySelector('.price-qty')?.value) || 0;
        const rate = parseFloat(row.querySelector('.price-rate')?.value) || 0;
        subtotal += qty * rate;
    });
    
    const discountPct = parseFloat(document.getElementById('discountPercent')?.value) || 0;
    const taxPct = parseFloat(document.getElementById('taxPercent')?.value) || 0;
    const pax = parseInt(document.getElementById('paxCount')?.value) || 1;
    
    const discount = subtotal * (discountPct / 100);
    const afterDiscount = subtotal - discount;
    const tax = afterDiscount * (taxPct / 100);
    const grandTotal = afterDiscount + tax;
    const perPax = grandTotal / pax;
    
    const subtotalEl = document.getElementById('calcSubtotal');
    const discountEl = document.getElementById('calcDiscount');
    const taxEl = document.getElementById('calcTax');
    const grandTotalEl = document.getElementById('calcGrandTotal');
    const perPaxEl = document.getElementById('calcPerPax');
    
    if (subtotalEl) subtotalEl.textContent = formatCurrency(subtotal);
    if (discountEl) discountEl.textContent = '-' + formatCurrency(discount);
    if (taxEl) taxEl.textContent = formatCurrency(tax);
    if (grandTotalEl) grandTotalEl.textContent = formatCurrency(grandTotal);
    if (perPaxEl) perPaxEl.textContent = formatCurrency(perPax);
}

function formatCurrency(amount) {
    return '$' + amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function saveAsDraft() {
    alert('Quotation saved as draft!');
}

function showPreview() {
    generatePreviewContent();
    const modal = document.getElementById('printPreviewModal');
    if (modal) modal.classList.add('active');
}

function closePreview() {
    const modal = document.getElementById('printPreviewModal');
    if (modal) modal.classList.remove('active');
}

function generatePreviewContent() {
    const previewDiv = document.getElementById('previewContent');
    const printDiv = document.getElementById('printDocument');
    if (!previewDiv) return;
    
    const quoteNum = document.getElementById('quotationNumber')?.value || '-';
    const quoteDate = document.getElementById('quotationDate')?.value || '-';
    const validUntil = document.getElementById('validUntil')?.value || '-';
    const customerName = document.getElementById('customerName')?.value || '-';
    const contactPerson = document.getElementById('contactPerson')?.value || '-';
    const customerEmail = document.getElementById('customerEmail')?.value || '-';
    const customerPhone = document.getElementById('customerPhone')?.value || '-';
    const tourName = document.getElementById('tourName')?.value || '-';
    const destination = document.getElementById('destination')?.value || '-';
    const travelDate = document.getElementById('travelDate')?.value || '-';
    const paxCount = document.getElementById('paxCount')?.value || '-';
    
    // Build itinerary HTML
    let itineraryHtml = '';
    document.querySelectorAll('.itinerary-day').forEach(day => {
        const dayNum = day.querySelector('.day-number')?.textContent || '';
        const date = day.querySelector('.day-date')?.value || '';
        const dayName = day.querySelector('.day-name')?.textContent || '';
        const title = day.querySelector('.day-title')?.value || '';
        const hotel = day.querySelector('.hotel-input')?.value || '-';
        const stars = day.querySelector('.star-select')?.value;
        const starStr = stars ? '★'.repeat(parseInt(stars)) : '';
        
        const bChecked = day.querySelector('.meal-b')?.checked;
        const lChecked = day.querySelector('.meal-l')?.checked;
        const dChecked = day.querySelector('.meal-d')?.checked;
        const meals = [bChecked ? 'B' : '', lChecked ? 'L' : '', dChecked ? 'D' : ''].filter(m => m).join(' / ') || 'None';
        
        let activities = [];
        day.querySelectorAll('.activity-input').forEach(input => {
            if (input.value.trim()) activities.push(input.value.trim());
        });
        
        itineraryHtml += `
            <div class="day-block">
                <div class="day-title-print">${dayNum}: ${title || date} ${dayName ? '(' + dayName + ')' : ''}</div>
                <div class="day-details">
                    <p><strong>Hotel:</strong> ${hotel} ${starStr}</p>
                    <p><strong>Meals:</strong> ${meals}</p>
                    ${activities.length > 0 ? '<p><strong>Activities:</strong></p><ul>' + activities.map(a => '<li>' + a + '</li>').join('') + '</ul>' : ''}
                </div>
            </div>
        `;
    });
    
    // Build pricing table
    let pricingHtml = '';
    document.querySelectorAll('#pricingBody tr').forEach(row => {
        const desc = row.querySelector('.price-desc')?.value || '-';
        const qty = row.querySelector('.price-qty')?.value || '0';
        const unit = row.querySelector('.price-unit')?.value || '-';
        const rate = row.querySelector('.price-rate')?.value || '0';
        const total = row.querySelector('.row-total')?.textContent || '$0.00';
        pricingHtml += `<tr><td>${desc}</td><td>${qty}</td><td>${unit}</td><td class="amount-col">${formatCurrency(parseFloat(rate) || 0)}</td><td class="amount-col">${total}</td></tr>`;
    });
    
    const subtotal = document.getElementById('calcSubtotal')?.textContent || '$0.00';
    const discount = document.getElementById('calcDiscount')?.textContent || '$0.00';
    const tax = document.getElementById('calcTax')?.textContent || '$0.00';
    const grandTotal = document.getElementById('calcGrandTotal')?.textContent || '$0.00';
    const perPax = document.getElementById('calcPerPax')?.textContent || '$0.00';
    
    const inclusions = document.getElementById('inclusions')?.value || '';
    const exclusions = document.getElementById('exclusions')?.value || '';
    const terms = document.getElementById('termsText')?.value || '';
    
    const html = `
        <div class="print-doc">
            <div class="company-header">
                <h1 class="company-name">TOURIX</h1>
                <p class="company-tagline">Travel & Tours</p>
            </div>
            
            <div class="quote-title">QUOTATION</div>
            
            <div class="info-row">
                <div class="info-box">
                    <h4>Bill To</h4>
                    <p><strong>${customerName}</strong></p>
                    <p>Contact: ${contactPerson}</p>
                    <p>Email: ${customerEmail}</p>
                    <p>Phone: ${customerPhone}</p>
                </div>
                <div class="info-box" style="text-align: right;">
                    <h4>Quote Details</h4>
                    <p><strong>Quote #:</strong> ${quoteNum}</p>
                    <p><strong>Date:</strong> ${quoteDate}</p>
                    <p><strong>Valid Until:</strong> ${validUntil}</p>
                    <p><strong>Passengers:</strong> ${paxCount}</p>
                </div>
            </div>
            
            <h3 class="section-title">Tour: ${tourName}</h3>
            <p><strong>Destination:</strong> ${destination} | <strong>Travel Date:</strong> ${travelDate}</p>
            
            <h3 class="section-title">Itinerary</h3>
            ${itineraryHtml}
            
            <h3 class="section-title">Pricing</h3>
            <table class="price-table">
                <thead>
                    <tr><th>Description</th><th>Qty</th><th>Unit</th><th class="amount-col">Rate</th><th class="amount-col">Amount</th></tr>
                </thead>
                <tbody>${pricingHtml}</tbody>
            </table>
            
            <div class="totals-box">
                <div class="total-line"><span>Subtotal</span><span>${subtotal}</span></div>
                <div class="total-line"><span>Discount</span><span>${discount}</span></div>
                <div class="total-line"><span>Tax</span><span>${tax}</span></div>
                <div class="total-line grand-total"><span>Grand Total</span><span>${grandTotal}</span></div>
                <div class="total-line"><span>Per Person</span><span>${perPax}</span></div>
            </div>
            
            ${inclusions ? '<h3 class="section-title">Inclusions</h3><div style="white-space: pre-line;">' + inclusions + '</div>' : ''}
            ${exclusions ? '<h3 class="section-title">Exclusions</h3><div style="white-space: pre-line;">' + exclusions + '</div>' : ''}
            
            <div class="terms-section">
                <h4>Terms & Conditions</h4>
                <div style="white-space: pre-line;">${terms}</div>
            </div>
            
            <div class="signature-area">
                <div class="signature-box">
                    <div class="signature-line">Authorized Signature (Company)</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line">Customer Acceptance</div>
                </div>
            </div>
        </div>
    `;
    
    previewDiv.innerHTML = html;
    if (printDiv) printDiv.innerHTML = html;
}

function printDocument() {
    generatePreviewContent();
    window.print();
}

// Keep old function names as aliases for backward compatibility
function initQuotationItinerary() { initQuotePage(); }
function initQuotationService() { initQuotePage(); }

function setupQuotationEventListeners() {
    const servicesList = document.getElementById('servicesList');
    if (servicesList) {
        servicesList.addEventListener('input', function(e) {
            if (e.target.classList.contains('service-qty') || e.target.classList.contains('service-price')) {
                updateServiceTotal(e.target.closest('.service-item'));
                calculateTotals();
            }
        });
    }
    
    const discountPercent = document.getElementById('discountPercent');
    const taxPercent = document.getElementById('taxPercent');
    const passengerCount = document.getElementById('passengerCount');
    
    if (discountPercent) discountPercent.addEventListener('input', calculateTotals);
    if (taxPercent) taxPercent.addEventListener('input', calculateTotals);
    if (passengerCount) passengerCount.addEventListener('input', calculateTotals);
}

function updateServiceTotal(serviceItem) {
    if (!serviceItem) return;
    const qty = parseFloat(serviceItem.querySelector('.service-qty')?.value) || 0;
    const price = parseFloat(serviceItem.querySelector('.service-price')?.value) || 0;
    const total = qty * price;
    const totalEl = serviceItem.querySelector('.service-total');
    if (totalEl) totalEl.textContent = '$' + total.toFixed(2);
}

function calculateTotals() {
    let subtotal = 0;
    document.querySelectorAll('.service-item').forEach(item => {
        const qty = parseFloat(item.querySelector('.service-qty')?.value) || 0;
        const price = parseFloat(item.querySelector('.service-price')?.value) || 0;
        subtotal += qty * price;
    });
    
    const discountPercent = parseFloat(document.getElementById('discountPercent')?.value) || 0;
    const taxPercent = parseFloat(document.getElementById('taxPercent')?.value) || 0;
    const passengerCount = parseInt(document.getElementById('passengerCount')?.value) || 1;
    
    const discountAmount = subtotal * (discountPercent / 100);
    const afterDiscount = subtotal - discountAmount;
    const taxAmount = afterDiscount * (taxPercent / 100);
    const grandTotal = afterDiscount + taxAmount;
    const perPerson = grandTotal / passengerCount;
    
    const subtotalEl = document.getElementById('subtotal');
    const discountEl = document.getElementById('discountAmount');
    const taxEl = document.getElementById('taxAmount');
    const grandTotalEl = document.getElementById('grandTotal');
    const perPersonEl = document.getElementById('perPerson');
    const paxCountEl = document.getElementById('paxCount');
    
    if (subtotalEl) subtotalEl.textContent = '$' + subtotal.toFixed(2);
    if (discountEl) discountEl.textContent = '-$' + discountAmount.toFixed(2);
    if (taxEl) taxEl.textContent = '$' + taxAmount.toFixed(2);
    if (grandTotalEl) grandTotalEl.textContent = '$' + grandTotal.toFixed(2);
    if (perPersonEl) perPersonEl.textContent = '$' + perPerson.toFixed(2);
    if (paxCountEl) paxCountEl.textContent = passengerCount;
}

function addService() {
    const servicesList = document.getElementById('servicesList');
    if (!servicesList) return;
    
    const serviceHtml = `
        <div class="service-item">
            <select class="service-category">
                <option value="">Select Category</option>
                <option value="accommodation">Accommodation</option>
                <option value="transport">Transportation</option>
                <option value="transfer">Airport Transfer</option>
                <option value="tours">Tours & Activities</option>
                <option value="meals">Meals</option>
                <option value="guide">Guide Services</option>
                <option value="visa">Visa & Documents</option>
                <option value="insurance">Travel Insurance</option>
                <option value="other">Other</option>
            </select>
            <input type="text" class="service-name" placeholder="Service description">
            <input type="number" class="service-qty" value="1" min="1" placeholder="Qty">
            <input type="number" class="service-price" placeholder="Unit Price" step="0.01">
            <span class="service-total">$0.00</span>
            <button class="btn-icon remove-service" onclick="removeService(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    servicesList.insertAdjacentHTML('beforeend', serviceHtml);
}

function removeService(btn) {
    const serviceItem = btn.closest('.service-item');
    if (document.querySelectorAll('.service-item').length > 1) {
        serviceItem.remove();
        calculateTotals();
    }
}

function addItineraryDay() {
    dayCounter++;
    const itineraryList = document.getElementById('itineraryList');
    if (!itineraryList) return;
    
    const dayHtml = `
        <div class="itinerary-day-card" data-day="${dayCounter}">
            <div class="day-header-bar">
                <div class="day-number-badge">Day ${dayCounter}</div>
                <div class="day-date-picker">
                    <input type="date" class="day-date" onchange="updateDayOfWeek(this)">
                    <span class="day-of-week">Select date</span>
                </div>
                <input type="text" class="day-title-input" placeholder="Day title (e.g., City Tour)">
                <button type="button" class="btn-icon-delete" onclick="removeItineraryDay(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            
            <div class="day-body">
                <!-- Hotel Section -->
                <div class="day-section hotel-section">
                    <div class="section-label"><i class="fas fa-hotel"></i> Accommodation</div>
                    <div class="hotel-inputs">
                        <input type="text" class="hotel-name" placeholder="Hotel name">
                        <div class="hotel-grade">
                            <select class="star-rating">
                                <option value="">Star</option>
                                <option value="1">⭐</option>
                                <option value="2">⭐⭐</option>
                                <option value="3">⭐⭐⭐</option>
                                <option value="4">⭐⭐⭐⭐</option>
                                <option value="5">⭐⭐⭐⭐⭐</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Meals Section -->
                <div class="day-section meals-section">
                    <div class="section-label"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="meals-grid">
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="breakfast">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Breakfast</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="lunch">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Lunch</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="dinner">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Dinner</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                    </div>
                </div>

                <!-- Sightseeing & Activities Section -->
                <div class="day-section activities-section">
                    <div class="section-label"><i class="fas fa-camera"></i> Sightseeing & Activities</div>
                    <div class="activities-list">
                        <div class="activity-row">
                            <span class="activity-number">1</span>
                            <input type="text" class="activity-input" placeholder="Enter sightseeing or activity...">
                            <button type="button" class="btn-add-activity" onclick="addActivity(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    itineraryList.insertAdjacentHTML('beforeend', dayHtml);
    
    // Setup meal toggle listeners for new day
    setupMealToggles();
}

function removeItineraryDay(btn) {
    const dayItem = btn.closest('.itinerary-day-card');
    if (document.querySelectorAll('.itinerary-day-card').length > 1) {
        dayItem.remove();
        renumberDays();
    }
}

function renumberDays() {
    document.querySelectorAll('.itinerary-day-card').forEach((day, index) => {
        day.dataset.day = index + 1;
        day.querySelector('.day-number-badge').textContent = 'Day ' + (index + 1);
    });
    dayCounter = document.querySelectorAll('.itinerary-day-card').length;
}

// Update day of week when date is selected
function updateDayOfWeek(dateInput) {
    const dayCard = dateInput.closest('.itinerary-day-card');
    const dayOfWeekSpan = dayCard.querySelector('.day-of-week');
    
    if (dateInput.value) {
        const date = new Date(dateInput.value);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        dayOfWeekSpan.textContent = days[date.getDay()];
    } else {
        dayOfWeekSpan.textContent = 'Select date';
    }
}

// Add activity row
function addActivity(btn) {
    const activitiesList = btn.closest('.activities-list');
    const activityRows = activitiesList.querySelectorAll('.activity-row');
    const newNumber = activityRows.length + 1;
    
    const activityHtml = `
        <div class="activity-row">
            <span class="activity-number">${newNumber}</span>
            <input type="text" class="activity-input" placeholder="Enter sightseeing or activity...">
            <button type="button" class="btn-remove-activity" onclick="removeActivity(this)">
                <i class="fas fa-minus"></i>
            </button>
        </div>
    `;
    activitiesList.insertAdjacentHTML('beforeend', activityHtml);
}

// Remove activity row
function removeActivity(btn) {
    const activityRow = btn.closest('.activity-row');
    const activitiesList = activityRow.closest('.activities-list');
    
    if (activitiesList.querySelectorAll('.activity-row').length > 1) {
        activityRow.remove();
        renumberActivities(activitiesList);
    }
}

// Renumber activities after removal
function renumberActivities(activitiesList) {
    activitiesList.querySelectorAll('.activity-row').forEach((row, index) => {
        row.querySelector('.activity-number').textContent = index + 1;
    });
}

// Setup meal toggles to enable/disable menu input
function setupMealToggles() {
    document.querySelectorAll('.meal-included').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const mealItem = this.closest('.meal-item');
            const menuInput = mealItem.querySelector('.meal-menu');
            menuInput.disabled = !this.checked;
            if (!this.checked) {
                menuInput.value = '';
            }
        });
    });
}

// Initialize meal toggles on page load
function initQuotationItinerary() {
    try {
        // Set default dates
        const today = new Date();
        const validDate = new Date(today);
        validDate.setDate(validDate.getDate() + 30);
        
        const quotationDate = document.getElementById('quotationDate');
        const validUntil = document.getElementById('validUntil');
        
        if (quotationDate) quotationDate.value = formatDateForInput(today);
        if (validUntil) validUntil.value = formatDateForInput(validDate);
        
        // Generate quotation number
        const quotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const quotationNumber = document.getElementById('quotationNumber');
        if (quotationNumber) quotationNumber.value = quotationNo;
        
        // Setup event listeners for pricing calculation
        setupPricingListeners();
        
        // Reset day counter
        dayCounter = document.querySelectorAll('.day-card').length || 1;
        
        // Initialize first day date
        const firstDayDate = document.querySelector('.day-card .day-date');
        if (firstDayDate && !firstDayDate.value) {
            firstDayDate.value = formatDateForInput(today);
            updateDayOfWeekNew(firstDayDate);
        }
    } catch (err) {
        console.error('Error in initQuotationItinerary:', err);
    }
}

function initQuotationService() {
    try {
        // Set default dates
        const today = new Date();
        const validDate = new Date(today);
        validDate.setDate(validDate.getDate() + 30);
        
        const quotationDate = document.getElementById('quotationDate');
        const validUntil = document.getElementById('validUntil');
        
        if (quotationDate) quotationDate.value = formatDateForInput(today);
        if (validUntil) validUntil.value = formatDateForInput(validDate);
        
        // Generate quotation number
        const quotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const quotationNumber = document.getElementById('quotationNumber');
        if (quotationNumber) quotationNumber.value = quotationNo;
        
        // Setup event listeners for pricing calculation
        setupPricingListeners();
    } catch (err) {
        console.error('Error in initQuotationService:', err);
    }
}

// Setup pricing event listeners
function setupPricingListeners() {
    const discountInput = document.getElementById('discountPercent');
    const taxInput = document.getElementById('taxPercent');
    const paxInput = document.getElementById('paxCount');
    
    if (discountInput) discountInput.addEventListener('input', calculatePricingSummary);
    if (taxInput) taxInput.addEventListener('input', calculatePricingSummary);
    if (paxInput) paxInput.addEventListener('input', calculatePricingSummary);
}

// Update day of week for new structure
function updateDayOfWeekNew(dateInput) {
    if (!dateInput) return;
    const dayCard = dateInput.closest('.day-card');
    if (!dayCard) return;
    const dayOfWeekSpan = dayCard.querySelector('.day-of-week');
    if (!dayOfWeekSpan) return;
    
    if (dateInput.value) {
        const date = new Date(dateInput.value);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        dayOfWeekSpan.textContent = days[date.getDay()];
    } else {
        dayOfWeekSpan.textContent = 'Select date';
    }
}

// Add new day card
function addDayCard() {
    const daysContainer = document.getElementById('daysContainer');
    if (!daysContainer) return;
    
    const dayCards = daysContainer.querySelectorAll('.day-card');
    const newDayNum = dayCards.length + 1;
    
    // Calculate next date based on last day
    let nextDate = new Date();
    if (dayCards.length > 0) {
        const lastDayDate = dayCards[dayCards.length - 1].querySelector('.day-date')?.value;
        if (lastDayDate) {
            nextDate = new Date(lastDayDate);
            nextDate.setDate(nextDate.getDate() + 1);
        }
    }
    
    const dayHtml = `
        <div class="day-card" data-day="${newDayNum}">
            <div class="day-header">
                <div class="day-badge">Day ${newDayNum}</div>
                <div class="day-date-group">
                    <input type="date" class="day-date" value="${formatDateForInput(nextDate)}" onchange="updateDayOfWeekNew(this)">
                    <span class="day-of-week">${getDayName(nextDate)}</span>
                </div>
                <button type="button" class="btn-remove-day" onclick="removeDayCard(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            
            <div class="day-body">
                <!-- Hotel Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-hotel"></i> Accommodation</div>
                    <div class="hotel-row">
                        <input type="text" class="hotel-name" placeholder="Hotel name">
                        <select class="hotel-star">
                            <option value="">Star Rating</option>
                            <option value="1">★</option>
                            <option value="2">★★</option>
                            <option value="3">★★★</option>
                            <option value="4">★★★★</option>
                            <option value="5">★★★★★</option>
                        </select>
                    </div>
                </div>
                
                <!-- Meals Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="meals-row">
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-breakfast" onchange="toggleMealInput(this)">
                                <span class="meal-name">Breakfast</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-lunch" onchange="toggleMealInput(this)">
                                <span class="meal-name">Lunch</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-dinner" onchange="toggleMealInput(this)">
                                <span class="meal-name">Dinner</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                    </div>
                </div>
                
                <!-- Activities Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-camera"></i> Sightseeing & Activities</div>
                    <div class="activities-list">
                        <div class="activity-row">
                            <span class="activity-num">1</span>
                            <input type="text" class="activity-input" placeholder="Enter sightseeing or activity...">
                            <button type="button" class="btn-add-activity" onclick="addActivityLine(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    daysContainer.insertAdjacentHTML('beforeend', dayHtml);
}

// Get day name from date
function getDayName(date) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[date.getDay()];
}

// Remove day card
function removeDayCard(btn) {
    const dayCard = btn.closest('.day-card');
    const container = dayCard.closest('#daysContainer');
    
    if (container.querySelectorAll('.day-card').length > 1) {
        dayCard.remove();
        // Renumber days
        container.querySelectorAll('.day-card').forEach((card, i) => {
            card.dataset.day = i + 1;
            card.querySelector('.day-badge').textContent = 'Day ' + (i + 1);
        });
    }
}

// ==========================================
// Dashboard Charts
// ==========================================
function initDashboardCharts() {
    // Quotations Chart
    const quotationsCtx = document.getElementById('quotationsChart');
    if (quotationsCtx) {
        new Chart(quotationsCtx, {
            type: 'doughnut',
            data: {
                labels: ['Sent', 'Confirmed', 'Cancelled'],
                datasets: [{
                    data: [45, 28, 12],
                    backgroundColor: ['#2563EB', '#10B981', '#EF4444'],
                    borderWidth: 0,
                    cutout: '75%'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
}

// ==========================================
// Contact Filters
// ==========================================
function initContactFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const contactCards = document.querySelectorAll('.contact-card');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const filter = this.dataset.filter;
            contactCards.forEach(card => {
                if (filter === 'all' || card.dataset.type === filter) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// ==========================================
// Dark Mode Toggle
// ==========================================
const darkModeToggle = document.getElementById('darkModeToggle');
const body = document.body;

// Check for saved dark mode preference
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    body.classList.add('dark-mode');
    if (darkModeToggle) darkModeToggle.checked = true;
}

if (darkModeToggle) {
    darkModeToggle.addEventListener('change', () => {
        body.classList.toggle('dark-mode');
        const theme = body.classList.contains('dark-mode') ? 'dark' : 'light';
        localStorage.setItem('theme', theme);
    });
}

// ==========================================
// Update Current Date
// ==========================================
function updateDate() {
    const dateElement = document.getElementById('currentDate');
    if (dateElement) {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        const currentDate = new Date().toLocaleDateString('en-US', options);
        dateElement.textContent = currentDate;
    }
}
updateDate();

// ==========================================
// Navigation Event Listeners
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    // Handle sidebar navigation clicks
    const navItems = document.querySelectorAll('.nav-menu .nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            if (page) {
                loadContent(page);
                // Close sidebar on mobile after navigation
                if (window.innerWidth <= 768) {
                    document.querySelector('.sidebar').classList.remove('active');
                    document.body.classList.remove('sidebar-open');
                }
            }
        });
    });
    
    // Hamburger menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            document.body.classList.toggle('sidebar-open');
        });
    }
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            const sidebar = document.querySelector('.sidebar');
            const menuToggle = document.getElementById('menuToggle');
            
            if (sidebar.classList.contains('active') && 
                !sidebar.contains(e.target) && 
                !menuToggle.contains(e.target)) {
                sidebar.classList.remove('active');
                document.body.classList.remove('sidebar-open');
            }
        }
    });
    
    // Load initial content (dashboard)
    loadContent('dashboard');
});

// ==========================================
// Filter Tabs Functionality
// ==========================================
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('tab')) {
        const tabs = e.target.parentElement.querySelectorAll('.tab');
        tabs.forEach(t => t.classList.remove('active'));
        e.target.classList.add('active');
    }
});

// ==========================================
// Icon Button Animations
// ==========================================
// Icon Button Animations
// ==========================================
document.addEventListener('click', function(e) {
    if (e.target.closest('.icon-btn')) {
        const btn = e.target.closest('.icon-btn');
        btn.style.transform = 'scale(0.95)';
        setTimeout(() => {
            btn.style.transform = '';
        }, 150);
    }
});

// ==========================================
// Loading Spinner Styles
// ==========================================
const spinnerStyles = document.createElement('style');
spinnerStyles.textContent = `
    .loading-spinner {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 300px;
        color: var(--text-secondary);
    }
    .loading-spinner i {
        font-size: 40px;
        color: var(--primary-blue);
        margin-bottom: 16px;
    }
    .error-message {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 300px;
        text-align: center;
        color: var(--text-secondary);
    }
    .error-message i {
        font-size: 48px;
        color: #F59E0B;
        margin-bottom: 16px;
    }
    .error-message h3 {
        color: var(--text-primary);
        margin-bottom: 8px;
    }
    .error-message button {
        margin-top: 20px;
    }
`;
document.head.appendChild(spinnerStyles);

// Console welcome message
console.log('%c🎯 TOURIX Dashboard v1.0', 'color: #4F46E5; font-size: 20px; font-weight: bold;');
console.log('%cDeveloped for tour and travel management', 'color: #6B7280; font-size: 12px;');