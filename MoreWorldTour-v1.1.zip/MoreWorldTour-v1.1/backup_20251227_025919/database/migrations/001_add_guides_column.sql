-- ==========================================
-- Migration: Add guides, restaurants, and admissions columns to bookings table
-- Date: 2024-12-26
-- Description: Adds JSONB columns to store tour guide, restaurant, and admission assignments
-- ==========================================

-- Add guides column to bookings table
-- Each guide object: { id, name, phone, languages, license, rating, startDate, endDate }
ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS guides JSONB DEFAULT '[]'::jsonb;

-- Add restaurants column to bookings table
-- Each restaurant object: { id, name, cuisine, location, phone, date, meal_type, pax, notes }
ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS restaurants JSONB DEFAULT '[]'::jsonb;

-- Add admissions column to bookings table
-- Each admission object: { id, name, date, reservation_no, reservation_time, adult_price, adult_qty, child_price, child_qty, notes }
ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS admissions JSONB DEFAULT '[]'::jsonb;

-- Create index for JSON queries on guides
CREATE INDEX IF NOT EXISTS idx_bookings_guides ON bookings USING GIN (guides);

-- Create index for JSON queries on restaurants
CREATE INDEX IF NOT EXISTS idx_bookings_restaurants ON bookings USING GIN (restaurants);

-- Create index for JSON queries on admissions
CREATE INDEX IF NOT EXISTS idx_bookings_admissions ON bookings USING GIN (admissions);

-- Comments
COMMENT ON COLUMN bookings.guides IS 'JSON array of tour guide assignments with startDate and endDate';
COMMENT ON COLUMN bookings.restaurants IS 'JSON array of restaurant/meal bookings with date and phone';
COMMENT ON COLUMN bookings.admissions IS 'JSON array of admission/ticket bookings with date, reservation_no, and reservation_time';
