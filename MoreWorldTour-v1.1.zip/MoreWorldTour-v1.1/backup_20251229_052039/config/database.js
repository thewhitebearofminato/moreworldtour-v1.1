// ==========================================
// TOURIX - Database Operations
// All Supabase database functions
// ==========================================

// Get supabaseClient from window (set in supabase-config.js)
const getClient = () => window.supabaseClient;

const db = {
    // ==========================================
    // QUOTATION OPERATIONS
    // ==========================================
    
    // Get next quotation number
    async getNextQuotationNumber() {
        const supabaseClient = getClient();
        if (!supabaseClient) return `QT-${new Date().getFullYear()}-0001`;
        
        const year = new Date().getFullYear();
        const prefix = `QT-${year}-`;
        
        const { data, error } = await getClient()
            .from('quotations')
            .select('quotation_number')
            .like('quotation_number', `${prefix}%`)
            .order('quotation_number', { ascending: false })
            .limit(1);
        
        if (error) {
            console.error('Error getting quotation number:', error);
            return `${prefix}0001`;
        }
        
        if (!data || data.length === 0) {
            return `${prefix}0001`;
        }
        
        const lastNumber = parseInt(data[0].quotation_number.split('-')[2]);
        const nextNumber = (lastNumber + 1).toString().padStart(4, '0');
        return `${prefix}${nextNumber}`;
    },
    
    // Save quotation (itinerary type)
    async saveQuotationItinerary(quotationData, itineraryDays, pricingItems) {
        try {
            console.log('Saving to Supabase:', quotationData.quotation_number);
            
            // 1. Save main quotation using UPSERT with full_data JSONB
            const { data: quotation, error: quotationError } = await getClient()
                .from('quotations')
                .upsert([{
                    quotation_number: quotationData.quotation_number,
                    quotation_type: 'itinerary',
                    quotation_date: quotationData.quotation_date,
                    valid_until: quotationData.valid_until,
                    customer_name: quotationData.customer_name,
                    contact_person: quotationData.contact_person,
                    customer_email: quotationData.customer_email,
                    customer_phone: quotationData.customer_phone,
                    tour_name: quotationData.tour_name,
                    destination: quotationData.destination,
                    travel_date: quotationData.travel_date,
                    number_of_days: quotationData.number_of_days || quotationData.num_days,
                    number_of_passengers: quotationData.number_of_passengers || quotationData.pax_count,
                    status: quotationData.status || 'draft',
                    updated_at: new Date().toISOString(),
                    // Store COMPLETE quotation data as JSONB
                    full_data: quotationData
                }], {
                    onConflict: 'quotation_number'
                })
                .select()
                .single();
            
            if (quotationError) {
                console.error('Quotation save error:', quotationError);
                throw quotationError;
            }
            
            const quotationId = quotation.id;
            console.log('✅ Quotation saved with full_data to Supabase, ID:', quotationId);
            
            // 2. Delete old itinerary days and pricing items (if updating existing quotation)
            await getClient().from('itinerary_days').delete().eq('quotation_id', quotationId);
            await getClient().from('pricing_items').delete().eq('quotation_id', quotationId);
            
            // 3. Save itinerary days
            if (itineraryDays && itineraryDays.length > 0) {
                console.log('📋 Itinerary days to save:', itineraryDays);
                const daysToInsert = itineraryDays.map((day, index) => {
                    const dayNum = day.day_number || index + 1;
                    console.log(`Day ${index}: day_number = ${dayNum}`);
                    return {
                        quotation_id: quotationId,
                        day_number: dayNum,
                        day_date: day.day_date || null,
                        day_title: day.day_title || null,
                        hotel_name: day.hotel_name || null,
                        hotel_star_rating: day.hotel_star_rating || null,
                        room_type: day.room_type || null,
                        breakfast: day.breakfast || false,
                        breakfast_menu: day.breakfast_menu || null,
                        lunch: day.lunch || false,
                        lunch_menu: day.lunch_menu || null,
                        dinner: day.dinner || false,
                        dinner_menu: day.dinner_menu || null
                    };
                });
                
                console.log('📤 Days to insert:', daysToInsert);
                
                const { data: savedDays, error: daysError } = await getClient()
                    .from('itinerary_days')
                    .insert(daysToInsert)
                    .select();
                
                if (daysError) throw daysError;
                
                // 4. Save activities for each day
                for (let i = 0; i < itineraryDays.length; i++) {
                    const day = itineraryDays[i];
                    if (day.activities && day.activities.length > 0) {
                        const activitiesToInsert = day.activities.map((activity, actIndex) => {
                            // Handle both string activities and object activities
                            const isString = typeof activity === 'string';
                            return {
                                itinerary_day_id: savedDays[i].id,
                                activity_number: isString ? actIndex + 1 : (activity.activity_number || actIndex + 1),
                                activity_description: isString ? activity : (activity.activity_description || activity.description || '')
                            };
                        });
                        
                        console.log('📋 Activities to insert for day', i + 1, ':', activitiesToInsert);
                        
                        const { error: activitiesError } = await getClient()
                            .from('activities')
                            .insert(activitiesToInsert);
                        
                        if (activitiesError) {
                            console.error('Activities insert error:', activitiesError);
                            throw activitiesError;
                        }
                    }
                }
            }
            
            // 5. Save pricing items
            if (pricingItems && pricingItems.length > 0) {
                const itemsToInsert = pricingItems.map(item => ({
                    quotation_id: quotationId,
                    item_number: item.item_number,
                    description: item.description,
                    quantity: item.quantity,
                    unit: item.unit,
                    rate: item.rate,
                    amount: item.amount
                }));
                
                const { error: itemsError } = await getClient()
                    .from('pricing_items')
                    .insert(itemsToInsert);
                
                if (itemsError) throw itemsError;
            }
            
            return { success: true, quotation_id: quotationId, data: quotation };
            
        } catch (error) {
            console.error('Error saving quotation:', error);
            return { success: false, error: error.message };
        }
    },
    
    // Save quotation (service type)
    async saveQuotationService(quotationData, pricingItems) {
        try {
            console.log('Saving service quotation to Supabase:', quotationData.quotation_number);
            
            // 1. Save main quotation using UPSERT with full_data JSONB
            const { data: quotation, error: quotationError } = await getClient()
                .from('quotations')
                .upsert([{
                    quotation_number: quotationData.quotation_number,
                    quotation_type: 'service',
                    quotation_date: quotationData.quotation_date,
                    valid_until: quotationData.valid_until,
                    customer_name: quotationData.customer_name,
                    contact_person: quotationData.contact_person,
                    customer_email: quotationData.customer_email,
                    customer_phone: quotationData.customer_phone,
                    service_type: quotationData.service_type,
                    destination: quotationData.destination,
                    number_of_passengers: quotationData.number_of_passengers || quotationData.pax_count,
                    status: quotationData.status || 'draft',
                    updated_at: new Date().toISOString(),
                    // Store COMPLETE quotation data as JSONB
                    full_data: quotationData
                }], {
                    onConflict: 'quotation_number'
                })
                .select()
                .single();
            
            if (quotationError) {
                console.error('Service quotation save error:', quotationError);
                throw quotationError;
            }
            
            const quotationId = quotation.id;
            console.log('✅ Service quotation saved with full_data to Supabase, ID:', quotationId);
            
            // 2. Delete old pricing items (if updating existing quotation)
            await getClient().from('pricing_items').delete().eq('quotation_id', quotationId);
            
            // 3. Save pricing items
            if (pricingItems && pricingItems.length > 0) {
                const itemsToInsert = pricingItems.map((item, index) => ({
                    quotation_id: quotationId,
                    item_number: index + 1,
                    description: item.description,
                    quantity: item.quantity,
                    unit: item.unit || 'pcs',
                    rate: item.rate,
                    amount: item.amount
                }));
                
                const { error: itemsError } = await getClient()
                    .from('pricing_items')
                    .insert(itemsToInsert);
                
                if (itemsError) throw itemsError;
            }
            
            return { success: true, quotation_id: quotationId, data: quotation };
            
        } catch (error) {
            console.error('Error saving service quotation:', error);
            return { success: false, error: error.message };
        }
    },
    
    // Get all quotations
    async getAllQuotations(limit = 50) {
        const { data, error } = await getClient()
            .from('quotations')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(limit);
        
        if (error) {
            console.error('Error fetching quotations:', error);
            return { success: false, error: error.message };
        }
        
        return { success: true, data };
    },
    
    // Get single quotation with all details
    async getQuotation(quotationId) {
        try {
            // Get main quotation
            const { data: quotation, error: quotationError } = await getClient()
                .from('quotations')
                .select('*')
                .eq('id', quotationId)
                .single();
            
            if (quotationError) throw quotationError;
            
            // Get itinerary days with activities
            const { data: days, error: daysError } = await getClient()
                .from('itinerary_days')
                .select(`
                    *,
                    activities (*)
                `)
                .eq('quotation_id', quotationId)
                .order('day_number');
            
            if (daysError) throw daysError;
            
            // Get pricing items
            const { data: items, error: itemsError } = await getClient()
                .from('pricing_items')
                .select('*')
                .eq('quotation_id', quotationId)
                .order('item_number');
            
            if (itemsError) throw itemsError;
            
            return {
                success: true,
                data: {
                    quotation,
                    itinerary_days: days || [],
                    pricing_items: items || []
                }
            };
            
        } catch (error) {
            console.error('Error fetching quotation:', error);
            return { success: false, error: error.message };
        }
    },
    
    // Update quotation
    async updateQuotation(quotationId, updates) {
        const { data, error } = await getClient()
            .from('quotations')
            .update(updates)
            .eq('id', quotationId)
            .select()
            .single();
        
        if (error) {
            console.error('Error updating quotation:', error);
            return { success: false, error: error.message };
        }
        
        return { success: true, data };
    },
    
    // Delete quotation (cascade deletes days, activities, items)
    async deleteQuotation(quotationId) {
        const { error } = await getClient()
            .from('quotations')
            .delete()
            .eq('id', quotationId);
        
        if (error) {
            console.error('Error deleting quotation:', error);
            return { success: false, error: error.message };
        }
        
        return { success: true };
    },
    
    // ==========================================
    // CUSTOMER OPERATIONS
    // ==========================================
    
    // Save customer
    async saveCustomer(customerData) {
        const { data, error } = await getClient()
            .from('customers')
            .insert([customerData])
            .select()
            .single();
        
        if (error) {
            console.error('Error saving customer:', error);
            return { success: false, error: error.message };
        }
        
        return { success: true, data };
    },
    
    // Search customers
    async searchCustomers(searchTerm) {
        const { data, error } = await getClient()
            .from('customers')
            .select('*')
            .or(`customer_name.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%`)
            .limit(10);
        
        if (error) {
            console.error('Error searching customers:', error);
            return { success: false, error: error.message };
        }
        
        return { success: true, data };
    },
    
    // Get all customers
    async getAllCustomers(limit = 100) {
        const { data, error } = await getClient()
            .from('customers')
            .select('*')
            .order('customer_name')
            .limit(limit);
        
        if (error) {
            console.error('Error fetching customers:', error);
            return { success: false, error: error.message };
        }
        
        return { success: true, data };
    }
};

// Make db available globally
window.db = db;
