// ==========================================
// TOURIX - Main Application Script
// ==========================================

// Current page state
let currentPage = 'dashboard';

// ==========================================
// Dynamic Content Loading
// ==========================================
async function loadContent(page) {
    const contentArea = document.getElementById('contentArea');
    const headerTitle = document.querySelector('.header-left h1');
    const breadcrumb = document.querySelector('.breadcrumb');
    
    // Show loading spinner
    contentArea.innerHTML = `
        <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading...</p>
        </div>
    `;
    
    try {
        // Fetch content from the content folder
        const response = await fetch(`content/${page}.html`);
        
        if (!response.ok) {
            throw new Error('Page not found');
        }
        
        const html = await response.text();
        contentArea.innerHTML = html;
        
        // Update page title mapping
        const pageTitles = {
            'dashboard': 'Dashboard',
            'quotations': 'Quotations',
            'quotation-itinerary': 'Quotation with Itinerary',
            'quotation-service': 'Quotation by Service',
            'quotation-summary': 'Quotation Summary',
            'quotation-service-summary': 'Service Quotation Summary',
            'booking': 'Booking',
            'operation': 'Operation',
            'tour-product': 'Tour Product',
            'financial': 'Financial',
            'directory': 'Directory'
        };
        
        // Update header
        const title = pageTitles[page] || page.charAt(0).toUpperCase() + page.slice(1);
        if (headerTitle) headerTitle.textContent = title;
        if (breadcrumb) breadcrumb.textContent = `Overview / ${title}`;
        
        // Update active nav item
        updateActiveNavItem(page);
        
        // Update current page
        currentPage = page;
        
        // Initialize page-specific scripts
        initPageScripts(page);
        
        // Scroll to top
        contentArea.scrollTop = 0;
        
    } catch (error) {
        contentArea.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Page Not Found</h3>
                <p>The requested page could not be loaded.</p>
                <button class="btn-primary" onclick="loadContent('dashboard')">
                    <i class="fas fa-home"></i> Back to Dashboard
                </button>
            </div>
        `;
        console.error('Error loading content:', error);
    }
}

// Update active navigation item
function updateActiveNavItem(page) {
    const navItems = document.querySelectorAll('.nav-menu .nav-item');
    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) {
            item.classList.add('active');
        }
    });
}

// Initialize page-specific scripts after content loads
function initPageScripts(page) {
    try {
        if (page === 'dashboard') {
            initDashboardCharts();
            initContactFilters();
        } else if (page === 'quotation-itinerary') {
            initQuotePage();
        } else if (page === 'quotation-service') {
            initQuoteServicePage();
        } else if (page === 'quotations') {
            loadQuotationsFromStorage();
        } else if (page === 'quotation-summary') {
            populateSummaryPage();
        } else if (page === 'quotation-service-summary') {
            populateServiceSummaryPage();
        } else if (page === 'booking') {
            loadBookingsFromStorage();
        }
    } catch (error) {
        console.error('Error initializing page scripts:', error);
    }
}

// ==========================================
// Quotation by Service Page Functions
// ==========================================
let serviceItemCounter = 1;

function initQuoteServicePage() {
    try {
        // Check for saved quotation data (editing mode)
        const savedData = localStorage.getItem('currentQuotation');
        if (savedData) {
            const data = JSON.parse(savedData);
            console.log('Loading saved service quotation:', data.quotation_number);
            
            // Wait a bit for DOM to be ready, then populate
            setTimeout(() => {
                populateServiceForm(data);
            }, 100);
            
            return;
        }
        
        // New quotation - set defaults
        const today = new Date();
        const validDate = new Date(today);
        validDate.setMonth(validDate.getMonth() + 1);
        
        const quotationDate = document.getElementById('quotationDate');
        const validUntil = document.getElementById('validUntil');
        
        if (quotationDate) quotationDate.value = formatDateForInput(today);
        if (validUntil) validUntil.value = formatDateForInput(validDate);
        
        // Generate quotation number
        const quotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const quotationNumber = document.getElementById('quotationNumber');
        const displayQuoteId = document.getElementById('displayQuoteId');
        if (quotationNumber) quotationNumber.value = quotationNo;
        if (displayQuoteId) displayQuoteId.textContent = quotationNo;
        
        // Add input listeners to existing items
        const priceInputs = document.querySelectorAll('.item-price, .item-qty');
        priceInputs.forEach(input => {
            input.addEventListener('input', calculateServiceTotal);
        });
        
        // Add listener to pax count
        const paxInput = document.getElementById('paxCount');
        if (paxInput) {
            paxInput.addEventListener('input', calculateServiceTotal);
        }
        
        // Reset counter
        serviceItemCounter = document.querySelectorAll('.service-item').length || 1;
        
    } catch (err) {
        console.error('Error in initQuoteServicePage:', err);
    }
}

// Add new service item
function addServiceItem() {
    serviceItemCounter++;
    const container = document.getElementById('serviceItemsContainer');
    
    const itemHtml = `
        <div class="service-item" data-item="${serviceItemCounter}">
            <div class="service-item-header">
                <span class="item-number">Item ${serviceItemCounter}</span>
                <button type="button" class="btn-remove-item" onclick="removeServiceItem(this)" title="Remove">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
            <div class="service-item-body">
                <div class="form-grid cols-4">
                    <div class="form-group col-span-2">
                        <label>Description</label>
                        <input type="text" class="item-description" placeholder="Service description">
                    </div>
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" class="item-qty" value="1" min="1" oninput="calculateServiceTotal()">
                    </div>
                    <div class="form-group">
                        <label>Unit Price (USD)</label>
                        <input type="number" class="item-price" placeholder="0.00" step="0.01" oninput="calculateServiceTotal()">
                    </div>
                </div>
            </div>
        </div>
    `;
    
    container.insertAdjacentHTML('beforeend', itemHtml);
}

// Remove service item
function removeServiceItem(btn) {
    const item = btn.closest('.service-item');
    if (document.querySelectorAll('.service-item').length > 1) {
        item.remove();
        renumberServiceItems();
        calculateServiceTotal();
    } else {
        showNotification('At least one service item is required', 'warning');
    }
}

// Renumber service items
function renumberServiceItems() {
    const items = document.querySelectorAll('.service-item');
    items.forEach((item, index) => {
        item.dataset.item = index + 1;
        item.querySelector('.item-number').textContent = `Item ${index + 1}`;
    });
    serviceItemCounter = items.length;
}

// Calculate service total
// ==========================================
// COST ESTIMATION FORMULAS:
// ==========================================
// 1. SUBTOTAL = Σ (Quantity × Unit Price) for all service items
// 2. SGL SUPPLEMENT = SGL Room Count × SGL Rate per Room
// 3. AFTER SGL = SUBTOTAL + SGL SUPPLEMENT
// 4. HANDLING FEE = AFTER SGL × (Handling Fee % / 100)
// 5. AFTER HANDLING = AFTER SGL + HANDLING FEE
// 6. DISCOUNT = AFTER HANDLING × (Discount % / 100)
// 7. AFTER DISCOUNT = AFTER HANDLING - DISCOUNT
// 8. TAX = AFTER DISCOUNT × (Tax % / 100)
// 9. GRAND TOTAL = AFTER DISCOUNT + TAX
// 10. PER PERSON = GRAND TOTAL / Number of Passengers
// ==========================================
function calculateServiceTotal() {
    const items = document.querySelectorAll('.service-item');
    let subtotal = 0;
    
    // Step 1: Calculate Subtotal (sum of all service items)
    items.forEach(item => {
        const qty = parseFloat(item.querySelector('.item-qty').value) || 0;
        const price = parseFloat(item.querySelector('.item-price').value) || 0;
        subtotal += qty * price;
    });
    
    // Get optional fee values (only apply if row is visible)
    const sglChargeRow = document.getElementById('sglChargeRow');
    const handlingFeeRow = document.getElementById('handlingFeeRow');
    const discountRow = document.getElementById('discountRow');
    const taxRow = document.getElementById('taxRow');
    
    // Step 2: SGL Supplement calculation
    const sglCount = (sglChargeRow && sglChargeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('sglChargeCount')?.value) || 0) : 0;
    const sglRate = (sglChargeRow && sglChargeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('sglChargeAmount')?.value) || 0) : 0;
    const sglTotal = sglCount * sglRate;
    
    // Step 3: After SGL
    const afterSgl = subtotal + sglTotal;
    
    // Step 4 & 5: Handling Fee calculation
    const handlingFeePercent = (handlingFeeRow && handlingFeeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('handlingFeePercent')?.value) || 0) : 0;
    const handlingFeeAmount = afterSgl * (handlingFeePercent / 100);
    const afterHandling = afterSgl + handlingFeeAmount;
    
    // Step 6 & 7: Discount calculation
    const discountPercent = (discountRow && discountRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('discountPercent')?.value) || 0) : 0;
    const discountAmount = afterHandling * (discountPercent / 100);
    const afterDiscount = afterHandling - discountAmount;
    
    // Step 8: Tax calculation
    const taxPercent = (taxRow && taxRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('taxPercent')?.value) || 0) : 0;
    const taxAmount = afterDiscount * (taxPercent / 100);
    
    // Step 9: Grand Total
    const grandTotal = afterDiscount + taxAmount;
    
    // Step 10: Per Person
    const paxCount = parseInt(document.getElementById('paxCount')?.value) || 1;
    const perPersonUSD = grandTotal / paxCount;
    
    // Format numbers
    const formatUSD = (num) => '$' + num.toFixed(2);
    
    // Update display
    const subtotalEl = document.getElementById('subtotalAmount');
    const sglTotalEl = document.getElementById('sglTotalAmount');
    const handlingEl = document.getElementById('handlingFeeAmount');
    const discountEl = document.getElementById('discountAmount');
    const taxEl = document.getElementById('taxAmount');
    const grandTotalEl = document.getElementById('grandTotalUSD');
    const perPersonEl = document.getElementById('perPersonUSD');
    const paxDisplayEl = document.getElementById('paxDisplay');
    
    if (subtotalEl) subtotalEl.textContent = formatUSD(subtotal);
    if (sglTotalEl) sglTotalEl.textContent = formatUSD(sglTotal);
    if (handlingEl) handlingEl.textContent = formatUSD(handlingFeeAmount);
    if (discountEl) discountEl.textContent = '-' + formatUSD(discountAmount);
    if (taxEl) taxEl.textContent = formatUSD(taxAmount);
    if (grandTotalEl) grandTotalEl.textContent = formatUSD(grandTotal);
    if (perPersonEl) perPersonEl.textContent = formatUSD(perPersonUSD);
    if (paxDisplayEl) paxDisplayEl.textContent = paxCount;
}

// Toggle fee row visibility
function toggleFeeRow(rowId, show) {
    const row = document.getElementById(rowId);
    if (row) {
        row.style.display = show ? 'flex' : 'none';
        calculateServiceTotal();
    }
}

// Populate the service quotation summary page with saved data
function populateServiceSummaryPage() {
    const savedData = localStorage.getItem('currentQuotation');
    if (!savedData) return;
    
    const data = JSON.parse(savedData);
    
    // Helper function
    const setTextById = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value || '';
    };
    
    // Format date for display
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    };
    
    // Format USD
    const formatUSD = (num) => '$' + (parseFloat(num) || 0).toFixed(2);
    
    // Header info
    setTextById('printQuoteNo', data.quotation_number);
    setTextById('printQuoteDate', formatDate(data.quotation_date));
    setTextById('printValidUntil', formatDate(data.valid_until));
    setTextById('summaryQuoteId', data.quotation_number);
    
    // Customer info
    setTextById('printCustomerName', data.customer_name);
    setTextById('printNationality', data.nationality ? `Nationality: ${data.nationality}` : '');
    setTextById('printCustomerEmail', data.customer_email);
    setTextById('printCustomerPhone', data.customer_phone);
    
    // Service details
    setTextById('printServiceType', data.service_type || 'Service Quotation');
    if (data.service_date) {
        setTextById('printServiceDates', `Service Date: ${formatDate(data.service_date)}`);
    }
    if (data.pax_count) {
        setTextById('printPax', `${data.pax_count} Person(s)`);
        setTextById('printPaxCount', data.pax_count);
    }
    
    // Populate service items
    const itemsContainer = document.getElementById('printServiceItems');
    if (itemsContainer && data.service_items && data.service_items.length > 0) {
        itemsContainer.innerHTML = '';
        data.service_items.forEach((item, index) => {
            const qty = parseFloat(item.qty) || 0;
            const price = parseFloat(item.price) || 0;
            const amount = qty * price;
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${item.description || '-'}</td>
                <td class="text-center">${qty}</td>
                <td class="text-right">${formatUSD(price)}</td>
                <td class="text-right">${formatUSD(amount)}</td>
            `;
            itemsContainer.appendChild(row);
        });
    }
    
    // Pricing summary
    setTextById('printSubtotal', formatUSD(data.subtotal));
    
    // SGL Supplement
    if (data.sgl_count && parseFloat(data.sgl_count) > 0) {
        document.getElementById('printSglRow').style.display = '';
        setTextById('printSglCount', data.sgl_count);
        setTextById('printSglRate', parseFloat(data.sgl_rate).toFixed(2));
        setTextById('printSglTotal', formatUSD(data.sgl_total));
    }
    
    // Handling fee
    if (data.handling_fee_percent && parseFloat(data.handling_fee_percent) > 0) {
        document.getElementById('printHandlingRow').style.display = '';
        setTextById('printHandlingPercent', data.handling_fee_percent);
        setTextById('printHandlingAmount', formatUSD(data.handling_fee_amount));
    }
    
    // Discount
    if (data.discount_percent && parseFloat(data.discount_percent) > 0) {
        document.getElementById('printDiscountRow').style.display = '';
        setTextById('printDiscountPercent', data.discount_percent);
        setTextById('printDiscountAmount', '-' + formatUSD(data.discount_amount));
    }
    
    // Tax
    if (data.tax_percent && parseFloat(data.tax_percent) > 0) {
        document.getElementById('printTaxRow').style.display = '';
        setTextById('printTaxPercent', data.tax_percent);
        setTextById('printTaxAmount', formatUSD(data.tax_amount));
    }
    
    // Grand total and per person
    setTextById('printGrandTotal', formatUSD(data.grand_total));
    setTextById('printPerPerson', formatUSD(data.per_person));
    
    // Notes
    if (data.notes && data.notes.trim()) {
        document.getElementById('notesSection').style.display = '';
        setTextById('printNotes', data.notes);
    }
    
    // Terms
    if (data.terms && data.terms.trim()) {
        const termsEl = document.getElementById('printTerms');
        if (termsEl) {
            termsEl.innerHTML = `<div style="white-space: pre-line;">${data.terms}</div>`;
        }
    }
}

// Edit service quotation
function editServiceQuotation() {
    const savedData = localStorage.getItem('currentQuotation');
    if (savedData) {
        loadContent('quotation-service');
        // TODO: Populate form with saved data after page loads
    } else {
        showNotification('No quotation data found', 'error');
    }
}

// Populate the quotation summary page with saved data
function populateSummaryPage() {
    const savedData = localStorage.getItem('currentQuotation');
    if (!savedData) return;
    
    const data = JSON.parse(savedData);
    
    // Update quote info
    const setTextById = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value || '';
    };
    
    // Format date for display
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    };
    
    // Header info
    setTextById('printQuoteNo', data.quotation_number);
    setTextById('printQuoteDate', formatDate(data.quotation_date));
    setTextById('printValidUntil', formatDate(data.valid_until));
    
    // Also update the page header quote ID
    setTextById('summaryQuoteId', data.quotation_number);
    
    // Customer info
    setTextById('printCustomerName', data.customer_name);
    setTextById('printCustomerContact', data.contact_person);
    setTextById('printCustomerEmail', data.customer_email);
    setTextById('printCustomerPhone', data.customer_phone);
    
    // Tour details
    setTextById('printTourName', data.tour_name);
    setTextById('printDestination', data.destination);
    
    // Travel dates
    if (data.travel_date && data.num_days) {
        const startDate = new Date(data.travel_date);
        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + parseInt(data.num_days) - 1);
        const dateRange = `${formatDate(data.travel_date)} - ${formatDate(endDate.toISOString())} (${data.num_days} Days)`;
        setTextById('printTravelDates', dateRange);
    } else {
        setTextById('printTravelDates', '');
    }
    
    if (data.pax_count) {
        setTextById('printPax', `${data.pax_count} Passengers`);
    } else {
        setTextById('printPax', '');
    }
    
    // Populate itinerary
    const itineraryContainer = document.getElementById('printItinerary');
    if (itineraryContainer) {
        itineraryContainer.innerHTML = '';
        if (data.itinerary && data.itinerary.length > 0) {
            data.itinerary.forEach((day, index) => {
                const dayDate = day.date ? formatDate(day.date) : '';
                const activities = day.activities ? day.activities.join('. ') : '';
                const meals = [];
                if (day.meals?.breakfast) meals.push('B');
                if (day.meals?.lunch) meals.push('L');
                if (day.meals?.dinner) meals.push('D');
                
                const dayHtml = `
                    <div class="itinerary-day">
                        <div class="day-header">
                            <span class="day-badge">Day ${index + 1}</span>
                            <span class="day-date">${dayDate}</span>
                            <span class="day-title">${day.title || ''}</span>
                        </div>
                        <div class="day-content">
                            <p class="day-description">${activities}</p>
                            <div class="day-details">
                                ${day.hotel ? `<span class="detail-item"><i class="fas fa-hotel"></i> ${day.hotel}${day.room_type ? ' - ' + day.room_type : ''}</span>` : ''}
                                ${meals.length > 0 ? `<span class="detail-item"><i class="fas fa-utensils"></i> ${meals.join(', ')}</span>` : ''}
                            </div>
                        </div>
                    </div>
                `;
                itineraryContainer.innerHTML += dayHtml;
            });
        }
    }
    
    // Populate pricing table
    const pricingContainer = document.getElementById('printPricing');
    if (pricingContainer && data.pricing && data.pricing.length > 0) {
        pricingContainer.innerHTML = '';
        data.pricing.forEach(p => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${p.pax} PAX</td>
                <td class="text-center">${p.sellPriceUSD}</td>
                <td class="text-right">-</td>
            `;
            pricingContainer.appendChild(row);
        });
    }
}

// Edit current quotation from summary page
function editCurrentQuotation() {
    const savedData = localStorage.getItem('currentQuotation');
    if (savedData) {
        loadContent('quotation-itinerary');
        // TODO: Populate form with saved data after page loads
    } else {
        showNotification('No quotation data found', 'error');
    }
}

// Confirm booking - convert quotation to booking
function confirmBooking() {
    const savedData = localStorage.getItem('currentQuotation');
    if (!savedData) {
        showNotification('No quotation data found', 'error');
        return;
    }
    
    const quotationData = JSON.parse(savedData);
    
    // Create booking from quotation
    const bookingId = 'BK-' + new Date().getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
    const today = new Date();
    
    const booking = {
        booking_id: bookingId,
        quotation_number: quotationData.quotation_number,
        customer_name: quotationData.customer_name,
        contact_person: quotationData.contact_person,
        customer_email: quotationData.customer_email,
        customer_phone: quotationData.customer_phone,
        tour_name: quotationData.tour_name,
        destination: quotationData.destination,
        travel_date: quotationData.travel_date,
        num_days: quotationData.num_days,
        pax_count: quotationData.pax_count,
        pricing: quotationData.pricing,
        itinerary: quotationData.itinerary,
        status: 'confirmed',
        booking_date: today.toISOString(),
        created_at: today.toISOString(),
        full_data: quotationData
    };
    
    // Save to bookings list
    let bookingsList = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    bookingsList.unshift(booking);
    localStorage.setItem('bookingsList', JSON.stringify(bookingsList));
    
    // Update quotation status
    let quotationsList = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    const quotationIndex = quotationsList.findIndex(q => q.quotation_number === quotationData.quotation_number);
    if (quotationIndex !== -1) {
        quotationsList[quotationIndex].status = 'confirmed';
        localStorage.setItem('quotationsList', JSON.stringify(quotationsList));
    }
    
    showNotification(`Booking confirmed! Booking ID: ${bookingId}`, 'success');
    
    // Redirect to bookings page
    setTimeout(() => {
        loadContent('booking');
    }, 1500);
}

// Load saved quotations from localStorage into the table
function loadQuotationsFromStorage() {
    const savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    const tbody = document.getElementById('quotationsBody');
    
    if (!tbody || savedQuotations.length === 0) return;
    
    // Sort by last_update date descending (latest first)
    savedQuotations.sort((a, b) => {
        const dateA = new Date(a.last_update || a.sending_date || 0);
        const dateB = new Date(b.last_update || b.sending_date || 0);
        return dateB - dateA;
    });
    
    // Clear existing rows first
    tbody.innerHTML = '';
    
    // Add saved quotations to the table (already sorted latest first)
    savedQuotations.forEach(q => {
        // Create new row
        const row = document.createElement('tr');
        row.dataset.status = q.status;
        row.dataset.quotation = q.quotation_number;
        row.innerHTML = `
            <td class="qt-number"><a href="#" class="qt-link" onclick="viewQuotation('${q.quotation_number}'); return false;">${q.quotation_number}</a></td>
            <td class="program-name">${q.program_name}</td>
            <td>${q.customer_name}</td>
            <td><span class="type-badge-sm itinerary">${q.type}</span></td>
            <td>${q.sending_date}</td>
            <td>${q.last_update}</td>
            <td>
                <select class="status-dropdown ${q.status}" onchange="updateQuotationStatus(this)">
                    <option value="draft" ${q.status === 'draft' ? 'selected' : ''}>Draft</option>
                    <option value="pending" ${q.status === 'pending' ? 'selected' : ''}>Pending</option>
                    <option value="sent" ${q.status === 'sent' ? 'selected' : ''}>Sent</option>
                    <option value="confirmed" ${q.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                    <option value="cancelled" ${q.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                </select>
            </td>
            <td class="action-btns">
                <button class="icon-btn small highlight-btn" title="Highlight" onclick="highlightQuotation(this, '${q.quotation_number}')"><i class="fas fa-highlighter"></i></button>
                <button class="icon-btn small" title="Copy" onclick="copyQuotation('${q.quotation_number}')"><i class="fas fa-copy"></i></button>
                <button class="icon-btn small delete-btn" title="Delete" onclick="deleteQuotation('${q.quotation_number}')"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // Update filter counts
    updateFilterCounts();
}

// Load saved bookings from localStorage into the bookings table
function loadBookingsFromStorage() {
    const savedBookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const tbody = document.getElementById('bookingsBody');
    
    if (!tbody) return;
    
    // Sort by booking date descending (latest first)
    savedBookings.sort((a, b) => {
        const dateA = new Date(a.booking_date || 0);
        const dateB = new Date(b.booking_date || 0);
        return dateB - dateA;
    });
    
    // Add bookings to the table at the top
    savedBookings.forEach(b => {
        // Check if this booking already exists in the table
        const existingRow = tbody.querySelector(`tr[data-booking="${b.booking_id}"]`);
        if (existingRow) return;
        
        const formatDate = (dateStr) => {
            if (!dateStr) return '-';
            const date = new Date(dateStr);
            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        };
        
        // Get total price from pricing
        let totalPrice = '-';
        if (b.pricing && b.pricing.length > 0) {
            totalPrice = b.pricing[0].sellPriceUSD || '-';
        }
        
        const row = document.createElement('tr');
        row.dataset.booking = b.booking_id;
        row.dataset.status = b.status;
        row.innerHTML = `
            <td><strong><a href="#" class="qt-link" onclick="viewBooking('${b.booking_id}'); return false;">${b.booking_id}</a></strong></td>
            <td>${b.customer_name || 'Unknown'}</td>
            <td>${b.tour_name || 'Tour Package'}</td>
            <td>${formatDate(b.travel_date)}</td>
            <td>${b.pax_count || 0} Guests</td>
            <td>${totalPrice}</td>
            <td><span class="status ${b.status}">${b.status.charAt(0).toUpperCase() + b.status.slice(1)}</span></td>
            <td class="actions-cell">
                <button class="btn-icon-sm" title="View" onclick="viewBooking('${b.booking_id}')"><i class="fas fa-eye"></i></button>
                <button class="btn-icon-sm" title="Edit" onclick="editBooking('${b.booking_id}')"><i class="fas fa-edit"></i></button>
            </td>
        `;
        tbody.insertBefore(row, tbody.firstChild);
    });
}

// View booking details
function viewBooking(bookingId) {
    const savedBookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const booking = savedBookings.find(b => b.booking_id === bookingId);
    
    if (booking && booking.full_data) {
        localStorage.setItem('currentQuotation', JSON.stringify(booking.full_data));
        loadContent('quotation-summary');
    } else {
        showNotification('Booking details not found', 'error');
    }
}

// Edit booking
function editBooking(bookingId) {
    const savedBookings = JSON.parse(localStorage.getItem('bookingsList') || '[]');
    const booking = savedBookings.find(b => b.booking_id === bookingId);
    
    if (booking && booking.full_data) {
        localStorage.setItem('currentQuotation', JSON.stringify(booking.full_data));
        loadContent('quotation-itinerary');
    } else {
        showNotification('Booking details not found', 'error');
    }
}

// View quotation details
function viewQuotation(quotationNumber) {
    const savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    const quotation = savedQuotations.find(q => q.quotation_number === quotationNumber);
    
    if (quotation && quotation.full_data) {
        localStorage.setItem('currentQuotation', JSON.stringify(quotation.full_data));
        
        // Navigate to appropriate summary based on quotation type
        if (quotation.full_data.quotation_type === 'service') {
            loadContent('quotation-service-summary');
        } else {
            loadContent('quotation-summary');
        }
    }
}

// Edit quotation
function editQuotation(quotationNumber) {
    const savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    const quotation = savedQuotations.find(q => q.quotation_number === quotationNumber);
    
    if (quotation && quotation.full_data) {
        // Store the full data for the form to load
        localStorage.setItem('currentQuotation', JSON.stringify(quotation.full_data));
        
        console.log('Editing quotation:', quotationNumber);
        console.log('Data:', quotation.full_data);
        
        // Navigate to appropriate form based on quotation type
        if (quotation.full_data.quotation_type === 'service' || quotation.type === 'Service') {
            loadContent('quotation-service');
        } else {
            loadContent('quotation-itinerary');
        }
    } else {
        showNotification('Quotation data not found. It may not have been saved properly.', 'error');
        console.error('Quotation not found or missing full_data:', quotationNumber, quotation);
    }
}

// Highlight quotation row
function highlightQuotation(btn, quotationNumber) {
    const row = btn.closest('tr');
    if (row) {
        row.classList.toggle('highlighted');
        btn.classList.toggle('active');
        
        // Save highlight state
        let highlights = JSON.parse(localStorage.getItem('quotationHighlights') || '[]');
        if (row.classList.contains('highlighted')) {
            if (!highlights.includes(quotationNumber)) highlights.push(quotationNumber);
        } else {
            highlights = highlights.filter(q => q !== quotationNumber);
        }
        localStorage.setItem('quotationHighlights', JSON.stringify(highlights));
    }
}

// Copy quotation
function copyQuotation(quotationNumber) {
    const savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    const quotation = savedQuotations.find(q => q.quotation_number === quotationNumber);
    
    if (quotation) {
        // Create a copy with new quotation number
        const today = new Date();
        const newQuotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        
        const copiedQuotation = JSON.parse(JSON.stringify(quotation));
        copiedQuotation.quotation_number = newQuotationNo;
        copiedQuotation.sending_date = today.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        copiedQuotation.last_update = copiedQuotation.sending_date;
        copiedQuotation.program_name = quotation.program_name + ' (Copy)';
        copiedQuotation.status = 'draft';
        
        if (copiedQuotation.full_data) {
            copiedQuotation.full_data.quotation_number = newQuotationNo;
            copiedQuotation.full_data.tour_name = quotation.program_name + ' (Copy)';
        }
        
        // Add to list
        savedQuotations.unshift(copiedQuotation);
        localStorage.setItem('quotationsList', JSON.stringify(savedQuotations));
        
        showNotification('Quotation copied: ' + newQuotationNo, 'success');
        
        // Reload the list
        loadContent('quotations');
    }
}

// Delete quotation
function deleteQuotation(quotationNumber) {
    if (!confirm('Are you sure you want to delete quotation ' + quotationNumber + '?')) {
        return;
    }
    
    let savedQuotations = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    savedQuotations = savedQuotations.filter(q => q.quotation_number !== quotationNumber);
    localStorage.setItem('quotationsList', JSON.stringify(savedQuotations));
    
    // Remove from DOM
    const row = document.querySelector(`tr[data-quotation="${quotationNumber}"]`);
    if (row) {
        row.remove();
    }
    
    showNotification('Quotation deleted: ' + quotationNumber, 'success');
    
    // Update filter counts
    updateFilterCounts();
}

// ==========================================
// Quotation Page Functions (New Design)
// ==========================================
let dayCounter = 1;

function initQuotePage() {
    try {
        // Check for saved quotation data (editing mode)
        const savedData = localStorage.getItem('currentQuotation');
        if (savedData) {
            const data = JSON.parse(savedData);
            console.log('Loading saved quotation:', data.quotation_number);
            
            // Wait a bit for DOM to be ready, then populate
            setTimeout(() => {
                populateItineraryForm(data);
            }, 100);
            
            // Don't clear yet - will be cleared after successful population
            return;
        }
        
        // New quotation - set default values
        const today = new Date();
        const validDate = new Date(today);
        validDate.setMonth(validDate.getMonth() + 1); // 1 month after quote date
        
        // Set dates
        const qDate = document.getElementById('quotationDate');
        const vDate = document.getElementById('validUntil');
        const tDate = document.getElementById('travelDate');
        
        if (qDate) qDate.value = formatDateForInput(today);
        if (vDate) vDate.value = formatDateForInput(validDate);
        if (tDate) tDate.value = formatDateForInput(today);
        
        // Generate quote number
        const quoteNum = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const qNumField = document.getElementById('quotationNumber');
        const qNumDisplay = document.getElementById('displayQuoteId');
        if (qNumField) qNumField.value = quoteNum;
        if (qNumDisplay) qNumDisplay.textContent = quoteNum;
        
        // Set first day date
        const firstDayDate = document.querySelector('.itinerary-day .day-date');
        if (firstDayDate) {
            firstDayDate.value = formatDateForInput(today);
            updateDayDisplay(firstDayDate);
        }
        
        dayCounter = document.querySelectorAll('.itinerary-day').length || 1;
    } catch (err) {
        console.error('Error in initQuotePage:', err);
    }
}

function formatDateForInput(date) {
    return date.toISOString().split('T')[0];
}

function getDayName(dateStr) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[new Date(dateStr).getDay()];
}

function updateDayDisplay(input) {
    if (!input) return;
    const daySpan = input.parentElement?.querySelector('.day-name');
    if (input.value && daySpan) {
        daySpan.textContent = getDayName(input.value);
    }
}

function toggleMealDetail(checkbox, type) {
    const row = checkbox.closest('.day-row');
    if (!row) return;
    const detailInput = row.querySelector('.meal-' + type + '-detail');
    if (detailInput) {
        detailInput.disabled = !checkbox.checked;
        if (!checkbox.checked) detailInput.value = '';
    }
}

function addActivity(btn) {
    const container = btn.closest('.activities-container');
    if (!container) return;
    const items = container.querySelectorAll('.activity-item');
    const newNum = items.length + 1;
    
    const newItem = document.createElement('div');
    newItem.className = 'activity-item';
    newItem.innerHTML = `
        <span class="activity-num">${newNum}</span>
        <input type="text" class="activity-input" placeholder="Enter activity or sightseeing">
        <button type="button" class="activity-remove-btn" onclick="removeActivity(this)">
            <i class="fas fa-minus"></i>
        </button>
    `;
    container.appendChild(newItem);
}

function removeActivity(btn) {
    const item = btn.closest('.activity-item');
    const container = item?.closest('.activities-container');
    if (container && container.querySelectorAll('.activity-item').length > 1) {
        item.remove();
        container.querySelectorAll('.activity-item').forEach((el, i) => {
            el.querySelector('.activity-num').textContent = i + 1;
        });
    }
}

function addNewDay() {
    const container = document.getElementById('itineraryDays');
    if (!container) return;
    const days = container.querySelectorAll('.itinerary-day');
    dayCounter = days.length + 1;
    
    let nextDate = new Date();
    if (days.length > 0) {
        const lastDate = days[days.length - 1].querySelector('.day-date')?.value;
        if (lastDate) {
            nextDate = new Date(lastDate);
            nextDate.setDate(nextDate.getDate() + 1);
        }
    }
    
    const dayHtml = `
        <div class="itinerary-day" data-day="${dayCounter}">
            <div class="day-header-row">
                <div class="day-number">Day ${dayCounter}</div>
                <div class="day-date-input">
                    <input type="date" class="day-date" value="${formatDateForInput(nextDate)}" onchange="updateDayDisplay(this)">
                    <span class="day-name">${getDayName(nextDate)}</span>
                </div>
                <input type="text" class="day-title" placeholder="Day title">
                <button type="button" class="remove-day-btn" onclick="removeDay(this)" title="Remove Day">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
            <div class="day-content">
                <div class="day-row">
                    <div class="row-label"><i class="fas fa-bed"></i> Hotel</div>
                    <div class="row-inputs">
                        <input type="text" class="hotel-input" placeholder="Hotel name">
                        <select class="star-select">
                            <option value="">Rating</option>
                            <option value="2">2 Star</option>
                            <option value="3">3 Star</option>
                            <option value="4">4 Star</option>
                            <option value="5">5 Star</option>
                        </select>
                        <input type="text" class="room-type" placeholder="or similar">
                    </div>
                </div>
                <div class="day-row">
                    <div class="row-label"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="row-inputs meals-inputs">
                        <label class="meal-check">
                            <input type="checkbox" class="meal-b" onchange="toggleMealDetail(this, 'b')">
                            <span class="meal-badge">B</span>
                        </label>
                        <input type="text" class="meal-detail meal-b-detail" placeholder="Breakfast" disabled>
                        <label class="meal-check">
                            <input type="checkbox" class="meal-l" onchange="toggleMealDetail(this, 'l')">
                            <span class="meal-badge">L</span>
                        </label>
                        <input type="text" class="meal-detail meal-l-detail" placeholder="Lunch" disabled>
                        <label class="meal-check">
                            <input type="checkbox" class="meal-d" onchange="toggleMealDetail(this, 'd')">
                            <span class="meal-badge">D</span>
                        </label>
                        <input type="text" class="meal-detail meal-d-detail" placeholder="Dinner" disabled>
                    </div>
                </div>
                <div class="day-row activities-row">
                    <div class="row-label"><i class="fas fa-hiking"></i> Activities</div>
                    <div class="activities-container">
                        <div class="activity-item">
                            <span class="activity-num">1</span>
                            <input type="text" class="activity-input" placeholder="Enter activity">
                            <button type="button" class="activity-add-btn" onclick="addActivity(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', dayHtml);
}

function removeDay(btn) {
    const day = btn.closest('.itinerary-day');
    const container = document.getElementById('itineraryDays');
    if (container && container.querySelectorAll('.itinerary-day').length > 1) {
        day.remove();
        container.querySelectorAll('.itinerary-day').forEach((el, i) => {
            el.dataset.day = i + 1;
            el.querySelector('.day-number').textContent = 'Day ' + (i + 1);
        });
    }
}

// ==========================================
// COST ESTIMATION FUNCTIONS
// ==========================================

// Toggle category collapse
function toggleCategory(header) {
    const category = header.closest('.cost-category');
    if (category) {
        category.classList.toggle('collapsed');
    }
}

// Cost category configurations
const costConfigs = {
    hotel: {
        tableId: 'hotelTable',
        totalId: 'hotelTotal',
        template: `
            <td><input type="number" class="cost-day" value="1" min="1"></td>
            <td><input type="date" class="cost-date"></td>
            <td><input type="text" class="cost-name" placeholder="Hotel name"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('hotel')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('hotel')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'hotel')"><i class="fas fa-times"></i></button></td>
        `
    },
    meal: {
        tableId: 'mealTable',
        totalId: 'mealTotal',
        template: `
            <td><input type="number" class="cost-day" value="1" min="1"></td>
            <td><input type="date" class="cost-date"></td>
            <td>
                <select class="cost-type">
                    <option value="B">Breakfast</option>
                    <option value="L">Lunch</option>
                    <option value="D">Dinner</option>
                    <option value="O">Other</option>
                </select>
            </td>
            <td><input type="text" class="cost-name" placeholder="Meal description"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('meal')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('meal')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'meal')"><i class="fas fa-times"></i></button></td>
        `
    },
    admission: {
        tableId: 'admissionTable',
        totalId: 'admissionTotal',
        template: `
            <td><input type="number" class="cost-day" value="1" min="1"></td>
            <td><input type="date" class="cost-date"></td>
            <td><input type="text" class="cost-name" placeholder="Admission/Transfer"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('admission')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('admission')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'admission')"><i class="fas fa-times"></i></button></td>
        `
    },
    transport: {
        tableId: 'transportTable',
        totalId: 'transportTotal',
        template: `
            <td><input type="number" class="cost-day" value="1" min="1"></td>
            <td><input type="date" class="cost-date"></td>
            <td><input type="text" class="cost-name" placeholder="Bus/Van/Flight"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('transport')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('transport')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'transport')"><i class="fas fa-times"></i></button></td>
        `
    },
    guide: {
        tableId: 'guideTable',
        totalId: 'guideTotal',
        template: `
            <td>
                <select class="cost-type">
                    <option value="guide">Guide</option>
                    <option value="driver">Driver</option>
                    <option value="leader">Tour Leader</option>
                </select>
            </td>
            <td><input type="text" class="cost-name" placeholder="Service fee"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('guide')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('guide')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'guide')"><i class="fas fa-times"></i></button></td>
        `
    },
    other: {
        tableId: 'otherTable',
        totalId: 'otherTotal',
        template: `
            <td><input type="text" class="cost-name" placeholder="Other expense"></td>
            <td><input type="number" class="cost-price" placeholder="0" onchange="calcCategoryTotal('other')"></td>
            <td><input type="number" class="cost-qty" value="1" min="1" onchange="calcCategoryTotal('other')"></td>
            <td class="cost-row-total">₩0</td>
            <td><button type="button" class="cost-remove-btn" onclick="removeCostRow(this, 'other')"><i class="fas fa-times"></i></button></td>
        `
    }
};

// Add row to cost category
function addCostRow(category) {
    const config = costConfigs[category];
    if (!config) return;
    
    const table = document.getElementById(config.tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    const rows = tbody.querySelectorAll('tr');
    
    // Get the last row's date and day to auto-increment
    let lastDate = null;
    let lastDay = 1;
    if (rows.length > 0) {
        const lastRow = rows[rows.length - 1];
        const lastDateInput = lastRow.querySelector('.cost-date');
        const lastDayInput = lastRow.querySelector('.cost-day');
        if (lastDateInput && lastDateInput.value) {
            lastDate = new Date(lastDateInput.value);
        }
        if (lastDayInput && lastDayInput.value) {
            lastDay = parseInt(lastDayInput.value) || 1;
        }
    }
    
    const row = document.createElement('tr');
    row.innerHTML = config.template;
    tbody.appendChild(row);
    
    // Auto-set next day date for categories with date fields
    if ((category === 'hotel' || category === 'meal' || category === 'admission' || category === 'transport') && lastDate) {
        const nextDate = new Date(lastDate);
        nextDate.setDate(nextDate.getDate() + 1);
        const dateInput = row.querySelector('.cost-date');
        if (dateInput) {
            dateInput.value = nextDate.toISOString().split('T')[0];
        }
        // Increment the day number
        const dayInput = row.querySelector('.cost-day');
        if (dayInput) {
            dayInput.value = lastDay + 1;
        }
    }
}

// Remove cost row
function removeCostRow(btn, category) {
    const row = btn.closest('tr');
    const tbody = row?.closest('tbody');
    if (tbody && tbody.querySelectorAll('tr').length > 1) {
        row.remove();
        calcCategoryTotal(category);
    }
}

// Calculate category total
function calcCategoryTotal(category) {
    const config = costConfigs[category];
    if (!config) return;
    
    const table = document.getElementById(config.tableId);
    if (!table) return;
    
    let categoryTotal = 0;
    
    table.querySelectorAll('tbody tr').forEach(row => {
        const price = parseFloat(row.querySelector('.cost-price')?.value) || 0;
        const qty = parseFloat(row.querySelector('.cost-qty')?.value) || 1;
        const rowTotal = price * qty;
        
        const totalCell = row.querySelector('.cost-row-total');
        if (totalCell) totalCell.textContent = formatKRW(rowTotal);
        
        categoryTotal += rowTotal;
    });
    
    const totalEl = document.getElementById(config.totalId);
    if (totalEl) totalEl.textContent = formatKRW(categoryTotal);
    
    // Recalculate overall totals
    calcPricing();
}

// Calculate all pricing
function calcPricing() {
    // Sum all category totals
    let totalGroupCost = 0;
    
    // Hotel (fixed cost, not per person)
    const hotelTotal = parseKRW(document.getElementById('hotelTotal')?.textContent);
    totalGroupCost += hotelTotal;
    
    // Transportation (fixed cost)
    const transportTotal = parseKRW(document.getElementById('transportTotal')?.textContent);
    totalGroupCost += transportTotal;
    
    // Guide/Driver (fixed cost)
    const guideTotal = parseKRW(document.getElementById('guideTotal')?.textContent);
    totalGroupCost += guideTotal;
    
    // Other (fixed cost)
    const otherTotal = parseKRW(document.getElementById('otherTotal')?.textContent);
    totalGroupCost += otherTotal;
    
    // Get per-person costs
    const mealTotal = parseKRW(document.getElementById('mealTotal')?.textContent);
    const admissionTotal = parseKRW(document.getElementById('admissionTotal')?.textContent);
    
    // Store fixed and variable costs for PAX calculation
    window.tourCosts = {
        fixedCosts: hotelTotal + transportTotal + guideTotal + otherTotal,
        perPersonCosts: mealTotal + admissionTotal,
        hotelTotal,
        mealTotal,
        admissionTotal
    };
    
    // Update summary
    const basePax = parseInt(document.getElementById('paxCount')?.value) || 10;
    const groupCost = window.tourCosts.fixedCosts + (window.tourCosts.perPersonCosts);
    const costPerPerson = basePax > 0 ? groupCost / basePax : 0;
    
    document.getElementById('totalGroupCost').textContent = formatKRW(groupCost);
    document.getElementById('costPerPerson').textContent = formatKRW(costPerPerson);
    
    // Update PAX table
    calcPaxPricing();
}

// Mark SGL input as edited when user changes it
function markSglEdited(input) {
    input.dataset.edited = 'true';
}

// Update PAX row when PAX number or FOC changes
function updatePaxRow(input) {
    const row = input.closest('tr');
    if (!row) return;
    
    const paxInput = row.querySelector('.pax-number-input');
    if (paxInput) {
        row.dataset.pax = paxInput.value;
    }
    
    // Recalculate pricing
    calcPaxPricing();
}

// Calculate PAX-based pricing
// ==========================================
// COST ESTIMATION FORMULAS (Quotation with Itinerary):
// ==========================================
// 1. Category Total = Σ (Price × Quantity) for each item in category
// 2. Total Group Cost = Hotel + Meals + Admission
// 3. Cost Per Person = Transport + Guide + Other
//    Group Cost = Total Group Cost (NOT divided by PAX)
// 4. Profit Amount = Cost Per Person × (Profit Margin % ÷ 100)
// 5. Selling Price (KRW) = Cost Per Person + Profit Amount
// 6. Selling Price (USD) = Selling Price (KRW) ÷ Currency Rate
// 7. SGL Charge = (Hotel Total / 2) × 10%
// ==========================================
function calcPaxPricing() {
    if (!window.tourCosts) return;
    
    const profitMargin = parseFloat(document.getElementById('profitMargin')?.value) || 10;
    const currencyRate = parseFloat(document.getElementById('currencyRate')?.value) || 1350;
    
    // Auto-calculate SGL Charge: (Hotel Total / 2) * 10%
    const hotelTotal = window.tourCosts.hotelTotal || 0;
    const autoSglCharge = Math.round((hotelTotal / 2) * 0.1); // (Hotel/2) * 10%
    
    const paxRows = document.querySelectorAll('#paxBody tr');
    
    // Get total group cost (same for all PAX rows - NOT divided by PAX)
    const totalGroupCost = window.tourCosts.fixedCosts + window.tourCosts.perPersonCosts;
    
    paxRows.forEach(row => {
        // Get PAX from input or data attribute
        const paxInput = row.querySelector('.pax-number-input');
        const plusInput = row.querySelector('.pax-plus-input');
        const pax = paxInput ? parseInt(paxInput.value) || 10 : parseInt(row.dataset.pax) || 10;
        const plusOne = plusInput ? parseInt(plusInput.value) || 0 : 1; // FOC/Tour leader
        const totalPax = pax + plusOne;
        
        // Update data-pax attribute
        row.dataset.pax = pax;
        
        // Group Cost = Total Group Cost (same for all, NOT divided by PAX)
        const groupCost = totalGroupCost;
        
        // Cost per person (divide by paying passengers only, not tour leader)
        const costPerPerson = groupCost / pax;
        
        // Profit amount
        const profit = costPerPerson * (profitMargin / 100);
        
        // Selling price in KRW
        const sellPriceKRW = costPerPerson + profit;
        
        // Selling price in USD
        const sellPriceUSD = sellPriceKRW / currencyRate;
        
        // Update row cells
        row.querySelector('.pax-group-cost').textContent = formatKRW(groupCost);
        row.querySelector('.pax-cost-pp').textContent = formatKRW(costPerPerson);
        row.querySelector('.pax-profit').textContent = formatKRW(profit);
        row.querySelector('.pax-sell-krw').textContent = formatKRW(sellPriceKRW);
        
        // Update Price USD (calculated from KRW)
        const priceUsdCell = row.querySelector('.pax-price-usd');
        if (priceUsdCell) {
            priceUsdCell.textContent = formatUSD(sellPriceUSD);
        }
        
        // Selling USD - use input value or calculated
        const sellUsdInput = row.querySelector('.pax-usd-input');
        if (sellUsdInput && !sellUsdInput.value) {
            // If no manual value, show calculated
        }
        
        // SGL Charge - auto-calculate but allow edit
        const sglInput = row.querySelector('.pax-sgl-input');
        if (sglInput) {
            // Only set if empty (first time) or value is 0
            if (!sglInput.dataset.edited && (sglInput.value === '' || sglInput.value === '0')) {
                sglInput.value = autoSglCharge;
            }
        }
    });
}

// Add PAX row
function addPaxRow() {
    const tbody = document.getElementById('paxBody');
    if (!tbody) return;
    
    // Find the highest current PAX and add 5
    const rows = tbody.querySelectorAll('tr');
    let maxPax = 0;
    rows.forEach(row => {
        const pax = parseInt(row.dataset.pax) || 0;
        if (pax > maxPax) maxPax = pax;
    });
    const newPax = maxPax + 5;
    
    const row = document.createElement('tr');
    row.dataset.pax = newPax;
    row.innerHTML = `
        <td><span class="pax-number">${newPax}</span><span class="pax-plus">+1</span></td>
        <td class="pax-group-cost">฿0</td>
        <td class="pax-cost-pp">฿0</td>
        <td class="pax-profit">฿0</td>
        <td class="pax-sell-krw">฿0</td>
        <td class="pax-sell-usd">$0</td>
        <td><button type="button" class="cost-remove-btn" onclick="removePaxRow(this)"><i class="fas fa-times"></i></button></td>
    `;
    tbody.appendChild(row);
    calcPaxPricing();
}

// Remove PAX row
function removePaxRow(btn) {
    const row = btn.closest('tr');
    const tbody = row?.closest('tbody');
    if (tbody && tbody.querySelectorAll('tr').length > 1) {
        row.remove();
    }
}

// Format KRW currency (Korean Won)
function formatKRW(amount) {
    return '₩' + Math.round(amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Parse KRW string to number
function parseKRW(str) {
    if (!str) return 0;
    return parseFloat(str.replace(/[₩,]/g, '')) || 0;
}

// Format USD currency
function formatUSD(amount) {
    return '$' + amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Legacy function for backwards compatibility
function addPriceItem() {
    // Redirect to first cost category
    addCostRow('hotel');
}

function removePriceRow(btn) {
    removeCostRow(btn, 'other');
}

function calcRowTotal(input) {
    const row = input.closest('tr');
    const category = row?.closest('table')?.id?.replace('Table', '');
    if (category) calcCategoryTotal(category);
}

function calcTotals() {
    calcPricing();
}

function formatCurrency(amount) {
    return '$' + amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// ==========================================
// QUOTATION STATUS & FILTER FUNCTIONS
// ==========================================

// Current filter state
let currentStatusFilter = 'all';

// Update quotation status from dropdown
function updateQuotationStatus(select) {
    const newStatus = select.value;
    const row = select.closest('tr');
    const quotationNo = row?.querySelector('.qt-number')?.textContent;
    
    // Remove all status classes and add new one
    select.classList.remove('draft', 'pending', 'sent', 'confirmed', 'cancelled');
    select.classList.add(newStatus);
    
    // Update row data-status attribute
    if (row) row.dataset.status = newStatus;
    
    // Update last update column to today
    const cells = row?.querySelectorAll('td');
    if (cells && cells.length >= 6) {
        const today = new Date();
        const formattedDate = today.toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric', 
            year: 'numeric' 
        });
        cells[5].textContent = formattedDate; // Last Update column
    }
    
    // Update filter counts
    updateFilterCounts();
    
    // Re-apply current filter
    filterByStatus(currentStatusFilter);
    
    // Show notification
    showNotification(`Status updated to "${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)}" for ${quotationNo}`, 'success');
    
    // TODO: Save to database
    // db.updateQuotationStatus(quotationNo, newStatus);
}

// Filter by status
function filterByStatus(status) {
    currentStatusFilter = status;
    const rows = document.querySelectorAll('#quotationsBody tr');
    const filterCards = document.querySelectorAll('.filter-stat-card');
    
    // Update active filter card
    filterCards.forEach(card => {
        card.classList.remove('active');
        if (card.dataset.filter === status) {
            card.classList.add('active');
        }
    });
    
    // Filter rows
    rows.forEach(row => {
        const rowStatus = row.dataset.status;
        if (status === 'all' || rowStatus === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Update filter counts
function updateFilterCounts() {
    const rows = document.querySelectorAll('#quotationsBody tr');
    const counts = {
        all: 0,
        draft: 0,
        sent: 0,
        pending: 0,
        confirmed: 0,
        cancelled: 0
    };
    
    rows.forEach(row => {
        const status = row.dataset.status;
        counts.all++;
        if (counts.hasOwnProperty(status)) {
            counts[status]++;
        }
    });
    
    // Update count displays
    const countAll = document.getElementById('countAll');
    const countSent = document.getElementById('countSent');
    const countPending = document.getElementById('countPending');
    const countConfirmed = document.getElementById('countConfirmed');
    const countCancelled = document.getElementById('countCancelled');
    
    if (countAll) countAll.textContent = counts.all;
    if (countSent) countSent.textContent = counts.sent;
    if (countPending) countPending.textContent = counts.pending;
    if (countConfirmed) countConfirmed.textContent = counts.confirmed;
    if (countCancelled) countCancelled.textContent = counts.cancelled;
}

// Search/filter quotations by text
function filterQuotations() {
    const searchInput = document.getElementById('quotationSearch');
    const searchText = searchInput?.value.toLowerCase() || '';
    const rows = document.querySelectorAll('#quotationsBody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const matchesSearch = text.includes(searchText);
        const matchesStatus = currentStatusFilter === 'all' || row.dataset.status === currentStatusFilter;
        
        if (matchesSearch && matchesStatus) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// ==========================================
// QUOTATION SAVE FUNCTIONS
// ==========================================

// Store quotation data temporarily for summary page
let currentQuotationData = null;

// Apply travel dates to itinerary days
function applyDatesToItinerary() {
    const travelDateInput = document.getElementById('travelDate');
    const numDaysInput = document.getElementById('numDays');
    
    if (!travelDateInput || !numDaysInput) {
        showNotification('Please fill in Travel Date and Number of Days', 'warning');
        return;
    }
    
    const travelDate = travelDateInput.value;
    const numDays = parseInt(numDaysInput.value) || 1;
    
    if (!travelDate) {
        showNotification('Please select a travel date first', 'warning');
        return;
    }
    
    const startDate = new Date(travelDate);
    const daysContainer = document.getElementById('itineraryDays');
    
    if (!daysContainer) {
        showNotification('Itinerary section not found', 'error');
        return;
    }
    
    // Get existing day items
    let dayItems = daysContainer.querySelectorAll('.itinerary-day');
    
    // If we need more day items than exist, add them
    while (dayItems.length < numDays) {
        addNewDay(); // This function adds new itinerary days
        dayItems = daysContainer.querySelectorAll('.itinerary-day');
    }
    
    // Update each day with the correct date
    for (let i = 0; i < numDays && i < dayItems.length; i++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(startDate.getDate() + i);
        
        const dayItem = dayItems[i];
        const dayNumber = i + 1;
        
        // Format date for display (e.g., "Mon")
        const dayName = currentDate.toLocaleDateString('en-US', { weekday: 'short' });
        
        // Update the date input
        const dateInput = dayItem.querySelector('.day-date');
        if (dateInput) {
            dateInput.value = currentDate.toISOString().split('T')[0];
        }
        
        // Update day name display
        const dayNameSpan = dayItem.querySelector('.day-name');
        if (dayNameSpan) {
            dayNameSpan.textContent = dayName;
        }
        
        // Update day number display
        const dayNumEl = dayItem.querySelector('.day-number');
        if (dayNumEl) {
            dayNumEl.textContent = `Day ${dayNumber}`;
        }
        
        // Update the data attribute
        dayItem.dataset.day = dayNumber;
        
        // Show this day
        dayItem.style.display = '';
    }
    
    // Hide extra day items if there are more than numDays
    for (let i = numDays; i < dayItems.length; i++) {
        dayItems[i].style.display = 'none';
    }
    
    // Also set the first date to all Cost Estimation sections
    applyCostEstimationDates(travelDate, numDays);
    
    showNotification(`Itinerary updated with ${numDays} days starting from ${startDate.toLocaleDateString()}`, 'success');
}

// Apply travel date to all Cost Estimation date fields
function applyCostEstimationDates(startDateStr, numDays) {
    const startDate = new Date(startDateStr);
    
    // Set first row date for each cost category
    const costTables = ['hotelTable', 'mealTable', 'admissionTable', 'transportTable', 'guideTable', 'otherTable'];
    
    costTables.forEach(tableId => {
        const table = document.getElementById(tableId);
        if (table) {
            const firstRow = table.querySelector('tbody tr');
            if (firstRow) {
                const dateInput = firstRow.querySelector('.cost-date');
                if (dateInput) {
                    dateInput.value = startDateStr;
                }
                // Also set day 1
                const dayInput = firstRow.querySelector('.cost-day');
                if (dayInput) {
                    dayInput.value = 1;
                }
            }
        }
    });
}

// Update validUntil when quotationDate changes (1 month after)
function updateValidUntil() {
    const quotationDate = document.getElementById('quotationDate');
    const validUntil = document.getElementById('validUntil');
    
    if (quotationDate && quotationDate.value && validUntil) {
        const qDate = new Date(quotationDate.value);
        qDate.setMonth(qDate.getMonth() + 1);
        validUntil.value = qDate.toISOString().split('T')[0];
    }
}

// Save quotation (just save, stay on page)
async function saveQuotationDraft() {
    try {
        const btn = event?.target;
        const originalText = btn?.innerHTML;
        if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        
        // Detect quotation type based on current page content
        const isServiceQuotation = document.getElementById('serviceItemsContainer') !== null;
        
        // Collect form data
        if (isServiceQuotation) {
            currentQuotationData = collectServiceQuotationData();
            currentQuotationData.quotation_type = 'service';
        } else {
            currentQuotationData = collectQuotationFormData();
            currentQuotationData.quotation_type = 'itinerary';
        }
        
        // Store in localStorage for quick access
        localStorage.setItem('currentQuotation', JSON.stringify(currentQuotationData));
        
        // Also save to quotationsList for persistence
        saveToQuotationsList(currentQuotationData, 'draft');
        
        // Simulate save delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (btn) btn.innerHTML = originalText;
        showNotification('Quotation saved successfully!', 'success');
        
    } catch (error) {
        console.error('Error saving quotation:', error);
        showNotification('Error saving quotation', 'error');
    }
}

// Save quotation data to the quotations list
function saveToQuotationsList(quotationData, status = 'draft') {
    // Get existing quotations list
    let quotationsList = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    
    // Check if this quotation already exists
    const existingIndex = quotationsList.findIndex(q => q.quotation_number === quotationData.quotation_number);
    
    // Determine quotation type and display name
    const isServiceQuotation = quotationData.quotation_type === 'service';
    
    // Create quotation record for the list
    const quotationRecord = {
        quotation_number: quotationData.quotation_number,
        program_name: isServiceQuotation 
            ? (quotationData.service_type || 'Service Quotation')
            : (quotationData.tour_name || 'Untitled Tour'),
        customer_name: quotationData.customer_name || 'Unknown Customer',
        type: isServiceQuotation ? 'Service' : 'Itinerary',
        sending_date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        last_update: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        status: status,
        full_data: quotationData
    };
    
    if (existingIndex >= 0) {
        // Update existing - preserve original sending_date
        quotationRecord.sending_date = quotationsList[existingIndex].sending_date;
        quotationsList[existingIndex] = quotationRecord;
    } else {
        // Add new at the top
        quotationsList.unshift(quotationRecord);
    }
    
    // Save back to localStorage
    localStorage.setItem('quotationsList', JSON.stringify(quotationsList));
    
    console.log('Saved quotation to list:', quotationData.quotation_number);
}

// Save and go to summary page
async function saveAndShowSummary() {
    try {
        const btn = event?.target;
        const originalText = btn?.innerHTML;
        if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        
        // Detect quotation type based on current page content
        const isServiceQuotation = document.getElementById('serviceItemsContainer') !== null;
        
        // Collect form data based on type
        if (isServiceQuotation) {
            currentQuotationData = collectServiceQuotationData();
            currentQuotationData.quotation_type = 'service';
        } else {
            currentQuotationData = collectQuotationFormData();
            currentQuotationData.quotation_type = 'itinerary';
        }
        
        // Store in localStorage
        localStorage.setItem('currentQuotation', JSON.stringify(currentQuotationData));
        
        // Also save to quotationsList for persistence
        saveToQuotationsList(currentQuotationData, 'sent');
        
        // Simulate save delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (btn) btn.innerHTML = originalText;
        showNotification('Quotation saved!', 'success');
        
        // Navigate to appropriate summary page
        if (isServiceQuotation) {
            loadContent('quotation-service-summary');
        } else {
            loadContent('quotation-summary');
        }
        
    } catch (error) {
        console.error('Error saving quotation:', error);
        showNotification('Error saving quotation', 'error');
    }
}

// Collect service quotation form data
function collectServiceQuotationData() {
    // Get pricing values
    const subtotal = parseFloat(document.getElementById('subtotalAmount')?.textContent?.replace(/[$,]/g, '')) || 0;
    const sglChargeRow = document.getElementById('sglChargeRow');
    const handlingFeeRow = document.getElementById('handlingFeeRow');
    const discountRow = document.getElementById('discountRow');
    const taxRow = document.getElementById('taxRow');
    
    // SGL Supplement
    const sglCount = (sglChargeRow && sglChargeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('sglChargeCount')?.value) || 0) : 0;
    const sglRate = (sglChargeRow && sglChargeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('sglChargeAmount')?.value) || 0) : 0;
    const sglTotal = parseFloat(document.getElementById('sglTotalAmount')?.textContent?.replace(/[$,]/g, '')) || 0;
    
    const handlingFeePercent = (handlingFeeRow && handlingFeeRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('handlingFeePercent')?.value) || 0) : 0;
    const handlingFeeAmount = parseFloat(document.getElementById('handlingFeeAmount')?.textContent?.replace(/[$,]/g, '')) || 0;
    
    const discountPercent = (discountRow && discountRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('discountPercent')?.value) || 0) : 0;
    const discountAmount = parseFloat(document.getElementById('discountAmount')?.textContent?.replace(/[-$,]/g, '')) || 0;
    
    const taxPercent = (taxRow && taxRow.style.display !== 'none') 
        ? (parseFloat(document.getElementById('taxPercent')?.value) || 0) : 0;
    const taxAmount = parseFloat(document.getElementById('taxAmount')?.textContent?.replace(/[$,]/g, '')) || 0;
    
    const grandTotal = parseFloat(document.getElementById('grandTotalUSD')?.textContent?.replace(/[$,]/g, '')) || 0;
    const perPerson = parseFloat(document.getElementById('perPersonUSD')?.textContent?.replace(/[$,]/g, '')) || 0;
    
    // Collect service items
    const serviceItems = [];
    document.querySelectorAll('.service-item').forEach((item, index) => {
        serviceItems.push({
            item_no: index + 1,
            description: item.querySelector('.item-description')?.value || '',
            qty: parseFloat(item.querySelector('.item-qty')?.value) || 0,
            price: parseFloat(item.querySelector('.item-price')?.value) || 0
        });
    });
    
    return {
        quotation_type: 'service',
        quotation_number: document.getElementById('quotationNumber')?.value || 'QT-2025-0001',
        quotation_date: document.getElementById('quotationDate')?.value,
        valid_until: document.getElementById('validUntil')?.value,
        
        // Customer Info
        customer_name: document.getElementById('customerName')?.value,
        customer_email: document.getElementById('customerEmail')?.value,
        customer_phone: document.getElementById('customerPhone')?.value,
        nationality: document.getElementById('customerNationality')?.value,
        
        // Service Info
        service_type: document.getElementById('serviceType')?.value,
        service_date: document.getElementById('serviceDate')?.value,
        pax_count: parseInt(document.getElementById('paxCount')?.value) || 1,
        
        // Service Items
        service_items: serviceItems,
        
        // Pricing
        subtotal: subtotal,
        sgl_count: sglCount,
        sgl_rate: sglRate,
        sgl_total: sglTotal,
        handling_fee_percent: handlingFeePercent,
        handling_fee_amount: handlingFeeAmount,
        discount_percent: discountPercent,
        discount_amount: discountAmount,
        tax_percent: taxPercent,
        tax_amount: taxAmount,
        grand_total: grandTotal,
        per_person: perPerson,
        
        // Notes & Terms
        notes: document.getElementById('quotationNotes')?.value || '',
        terms: document.getElementById('quotationTerms')?.value || '',
        
        // Timestamps
        created_at: new Date().toISOString(),
        status: 'draft'
    };
}

// Populate itinerary form with saved data (for editing)
function populateItineraryForm(data) {
    if (!data) {
        console.error('No data to populate');
        return;
    }
    
    console.log('Populating form with data:', data);
    
    // Helper to set input value
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el && val !== undefined && val !== null) {
            el.value = val;
            console.log('Set', id, '=', val);
        }
    };
    
    // Basic Info
    setVal('quotationNumber', data.quotation_number);
    setVal('quotationDate', data.quotation_date);
    setVal('validUntil', data.valid_until);
    
    // Update display ID
    const displayQuoteId = document.getElementById('displayQuoteId');
    if (displayQuoteId) displayQuoteId.textContent = data.quotation_number;
    
    // Customer Info
    setVal('customerName', data.customer_name);
    setVal('contactPerson', data.contact_person);
    setVal('customerEmail', data.customer_email);
    setVal('customerPhone', data.customer_phone);
    setVal('customerNationality', data.customer_nationality);
    
    // Tour Info
    setVal('tourName', data.tour_name);
    setVal('destination', data.destination);
    setVal('travelDate', data.travel_date);
    setVal('numDays', data.num_days);
    setVal('paxCount', data.pax_count);
    
    // Pricing settings
    setVal('profitMargin', data.profit_margin);
    setVal('currencyRate', data.currency_rate);
    
    // Notes and Terms
    setVal('quotationNotes', data.notes);
    setVal('quotationTerms', data.terms);
    
    // Inclusions and Exclusions
    setVal('inclusions', data.inclusions);
    setVal('exclusions', data.exclusions);
    
    // Cost tables would need more complex restoration
    // For now, just restore basic fields
    
    // Setup event listeners for pricing calculation
    setupPricingListeners();
    
    // Initialize day counter
    dayCounter = document.querySelectorAll('.day-card').length || 1;
    
    // Clear the localStorage after successful load
    localStorage.removeItem('currentQuotation');
    
    console.log('Successfully loaded quotation:', data.quotation_number);
    showNotification('Quotation loaded for editing', 'success');
}

// Collect all form data
function collectQuotationFormData() {
    return {
        // Basic Info
        quotation_number: document.getElementById('quotationNumber')?.value || 'QT-2025-0001',
        quotation_date: document.getElementById('quotationDate')?.value,
        valid_until: document.getElementById('validUntil')?.value,
        
        // Customer Info
        customer_name: document.getElementById('customerName')?.value,
        contact_person: document.getElementById('contactPerson')?.value,
        customer_email: document.getElementById('customerEmail')?.value,
        customer_phone: document.getElementById('customerPhone')?.value,
        customer_nationality: document.getElementById('customerNationality')?.value?.toUpperCase(),
        
        // Tour Info
        tour_name: document.getElementById('tourName')?.value,
        destination: document.getElementById('destination')?.value,
        travel_date: document.getElementById('travelDate')?.value,
        num_days: parseInt(document.getElementById('numDays')?.value) || 1,
        pax_count: parseInt(document.getElementById('paxCount')?.value) || 2,
        
        // Cost Data
        costs: window.tourCosts || {},
        profit_margin: parseFloat(document.getElementById('profitMargin')?.value) || 10,
        currency_rate: parseFloat(document.getElementById('currencyRate')?.value) || 1350,
        
        // Itinerary (collect from DOM)
        itinerary: collectItineraryData(),
        
        // Pricing by PAX
        pricing: collectPaxPricingData(),
        
        // Timestamps
        created_at: new Date().toISOString(),
        status: 'draft'
    };
}

// Collect itinerary data from form
function collectItineraryData() {
    const days = [];
    document.querySelectorAll('.itinerary-day').forEach((card, index) => {
        const dayNum = index + 1;
        
        // Collect activities
        const activities = [];
        card.querySelectorAll('.activity-input').forEach(input => {
            if (input.value.trim()) activities.push(input.value.trim());
        });
        
        days.push({
            day: dayNum,
            date: card.querySelector('.day-date')?.value || '',
            title: card.querySelector('.day-title')?.value || `Day ${dayNum}`,
            activities: activities,
            hotel: card.querySelector('.hotel-input')?.value || '',
            hotel_rating: card.querySelector('.star-select')?.value || '',
            room_type: card.querySelector('.room-type')?.value || '',
            meals: {
                breakfast: card.querySelector('.meal-b')?.checked || false,
                lunch: card.querySelector('.meal-l')?.checked || false,
                dinner: card.querySelector('.meal-d')?.checked || false
            },
            breakfast_detail: card.querySelector('.meal-b-detail')?.value || '',
            lunch_detail: card.querySelector('.meal-l-detail')?.value || '',
            dinner_detail: card.querySelector('.meal-d-detail')?.value || ''
        });
    });
    return days;
}

// Collect PAX pricing data
function collectPaxPricingData() {
    const pricing = [];
    document.querySelectorAll('#paxBody tr').forEach(row => {
        const pax = parseInt(row.dataset.pax) || 0;
        pricing.push({
            pax: pax,
            groupCost: row.querySelector('.pax-group-cost')?.textContent || '฿0',
            costPerPerson: row.querySelector('.pax-cost-pp')?.textContent || '฿0',
            profit: row.querySelector('.pax-profit')?.textContent || '฿0',
            sellPriceKRW: row.querySelector('.pax-sell-krw')?.textContent || '฿0',
            sellPriceUSD: row.querySelector('.pax-sell-usd')?.textContent || '$0'
        });
    });
    return pricing;
}

// Print quotation
function printQuotation() {
    window.print();
}

// Toggle print options panel
function togglePrintOptions() {
    const panel = document.getElementById('printOptionsPanel');
    if (panel) {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
}

// Toggle print section visibility
function togglePrintSection(sectionId, show) {
    const section = document.getElementById(sectionId);
    if (section) {
        // Special handling for notes section - only show if it has content
        if (sectionId === 'notesSection') {
            const notesContent = document.getElementById('printNotes');
            if (notesContent && notesContent.textContent.trim()) {
                section.style.display = show ? '' : 'none';
            }
        } else {
            section.style.display = show ? '' : 'none';
        }
    }
}

// Download as PDF (placeholder - would need library like jsPDF)
function downloadPDF() {
    showNotification('PDF download feature coming soon!', 'info');
}

// Finish quotation and add to list
function finishQuotation() {
    // Get the saved quotation data
    const savedData = localStorage.getItem('currentQuotation');
    if (!savedData) {
        showNotification('No quotation data found. Please save the quotation first.', 'error');
        return;
    }
    
    const quotationData = JSON.parse(savedData);
    
    // Get existing quotations list or create new one
    let quotationsList = JSON.parse(localStorage.getItem('quotationsList') || '[]');
    
    // Check if this quotation already exists (update) or is new (add)
    const existingIndex = quotationsList.findIndex(q => q.quotation_number === quotationData.quotation_number);
    
    // Determine quotation type and display name
    const isServiceQuotation = quotationData.quotation_type === 'service';
    
    // Create quotation record for the list
    const quotationRecord = {
        quotation_number: quotationData.quotation_number,
        program_name: isServiceQuotation 
            ? (quotationData.service_type || 'Service Quotation')
            : (quotationData.tour_name || 'Untitled Tour'),
        customer_name: quotationData.customer_name || 'Unknown Customer',
        type: isServiceQuotation ? 'Service' : 'Itinerary',
        sending_date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        last_update: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        status: 'sent',
        full_data: quotationData
    };
    
    if (existingIndex >= 0) {
        // Update existing
        quotationsList[existingIndex] = quotationRecord;
    } else {
        // Add new
        quotationsList.unshift(quotationRecord);
    }
    
    // Save back to localStorage
    localStorage.setItem('quotationsList', JSON.stringify(quotationsList));
    
    showNotification('Quotation finished and saved to list!', 'success');
    
    // Navigate back to quotations list after a short delay
    setTimeout(() => {
        loadContent('quotations');
    }, 1500);
}

// Legacy function compatibility
async function saveAsDraft() {
    await saveQuotationDraft();
}

async function saveQuotation(status = 'draft') {
    try {
        // Show loading indicator
        const btn = event?.target;
        const originalText = btn?.innerHTML;
        if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        
        // Get next quotation number from database
        const quotationNumber = await db.getNextQuotationNumber();
        
        // Collect form data
        const quotationData = {
            quotation_number: quotationNumber,
            quotation_date: document.getElementById('quotationDate')?.value,
            valid_until: document.getElementById('validUntil')?.value,
            customer_name: document.getElementById('customerName')?.value,
            contact_person: document.getElementById('contactPerson')?.value,
            customer_email: document.getElementById('customerEmail')?.value,
            customer_phone: document.getElementById('customerPhone')?.value,
            tour_name: document.getElementById('tourName')?.value,
            destination: document.getElementById('destination')?.value,
            travel_date: document.getElementById('travelDate')?.value,
            number_of_days: parseInt(document.getElementById('numberOfDays')?.value) || 0,
            number_of_passengers: parseInt(document.getElementById('numberOfPassengers')?.value) || 0,
            subtotal: parseFloat(document.getElementById('subtotalAmount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            discount_percent: parseFloat(document.getElementById('discountPercent')?.value) || 0,
            discount_amount: parseFloat(document.getElementById('discountAmount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            tax_percent: parseFloat(document.getElementById('taxPercent')?.value) || 0,
            tax_amount: parseFloat(document.getElementById('taxAmount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            grand_total: parseFloat(document.getElementById('grandTotal')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            per_person_price: parseFloat(document.getElementById('perPersonAmount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0,
            inclusions: document.getElementById('inclusions')?.value,
            exclusions: document.getElementById('exclusions')?.value,
            terms_conditions: document.getElementById('termsConditions')?.value,
            internal_notes: document.getElementById('internalNotes')?.value,
            status: status
        };
        
        // Collect itinerary days
        const itineraryDays = [];
        document.querySelectorAll('.itinerary-day').forEach((dayCard, index) => {
            const day = {
                day_number: index + 1,
                day_date: dayCard.querySelector('.day-date')?.value,
                day_title: dayCard.querySelector('.day-title')?.value,
                hotel_name: dayCard.querySelector('[name="hotelName"]')?.value,
                hotel_star_rating: parseInt(dayCard.querySelector('[name="starRating"]')?.value) || null,
                room_type: dayCard.querySelector('[name="roomType"]')?.value,
                breakfast: dayCard.querySelector('.meal-breakfast')?.checked || false,
                breakfast_menu: dayCard.querySelector('.meal-b-detail')?.value,
                lunch: dayCard.querySelector('.meal-lunch')?.checked || false,
                lunch_menu: dayCard.querySelector('.meal-l-detail')?.value,
                dinner: dayCard.querySelector('.meal-dinner')?.checked || false,
                dinner_menu: dayCard.querySelector('.meal-d-detail')?.value,
                activities: []
            };
            
            // Collect activities
            dayCard.querySelectorAll('.activity-item').forEach((actItem, actIndex) => {
                const actDesc = actItem.querySelector('.activity-input')?.value;
                if (actDesc) {
                    day.activities.push({
                        activity_number: actIndex + 1,
                        activity_description: actDesc
                    });
                }
            });
            
            itineraryDays.push(day);
        });
        
        // Collect pricing items
        const pricingItems = [];
        document.querySelectorAll('#pricingBody tr').forEach((row, index) => {
            const desc = row.querySelector('.price-desc')?.value;
            const qty = parseInt(row.querySelector('.price-qty')?.value) || 0;
            const rate = parseFloat(row.querySelector('.price-rate')?.value) || 0;
            const amount = parseFloat(row.querySelector('.price-amount')?.textContent?.replace(/[^0-9.-]+/g, '')) || 0;
            
            if (desc) {
                pricingItems.push({
                    item_number: index + 1,
                    description: desc,
                    quantity: qty,
                    unit: row.querySelector('.price-unit')?.value || 'pcs',
                    rate: rate,
                    amount: amount
                });
            }
        });
        
        // Save to database
        const result = await db.saveQuotationItinerary(quotationData, itineraryDays, pricingItems);
        
        if (result.success) {
            // Update UI with saved quote number
            const qNumDisplay = document.getElementById('displayQuoteId');
            if (qNumDisplay) qNumDisplay.textContent = quotationNumber;
            const qNumField = document.getElementById('quotationNumber');
            if (qNumField) qNumField.value = quotationNumber;
            
            // Show success message
            showNotification('Quotation saved successfully!', 'success');
        } else {
            throw new Error(result.error || 'Failed to save quotation');
        }
        
    } catch (error) {
        console.error('Error saving quotation:', error);
        showNotification('Error saving quotation: ' + error.message, 'error');
    } finally {
        // Restore button
        if (btn && originalText) {
            btn.innerHTML = originalText;
        }
    }
}

function showNotification(message, type = 'info') {
    // Simple notification - you can enhance this later
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 24px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        font-size: 14px;
        font-weight: 500;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function showPreview() {
    generatePreviewContent();
    const modal = document.getElementById('printPreviewModal');
    if (modal) modal.classList.add('active');
}

function closePreview() {
    const modal = document.getElementById('printPreviewModal');
    if (modal) modal.classList.remove('active');
}

function generatePreviewContent() {
    const previewDiv = document.getElementById('previewContent');
    const printDiv = document.getElementById('printDocument');
    if (!previewDiv) return;
    
    const quoteNum = document.getElementById('quotationNumber')?.value || '-';
    const quoteDate = document.getElementById('quotationDate')?.value || '-';
    const validUntil = document.getElementById('validUntil')?.value || '-';
    const customerName = document.getElementById('customerName')?.value || '-';
    const contactPerson = document.getElementById('contactPerson')?.value || '-';
    const customerEmail = document.getElementById('customerEmail')?.value || '-';
    const customerPhone = document.getElementById('customerPhone')?.value || '-';
    const tourName = document.getElementById('tourName')?.value || '-';
    const destination = document.getElementById('destination')?.value || '-';
    const travelDate = document.getElementById('travelDate')?.value || '-';
    const paxCount = document.getElementById('paxCount')?.value || '-';
    
    // Build itinerary HTML
    let itineraryHtml = '';
    document.querySelectorAll('.itinerary-day').forEach(day => {
        const dayNum = day.querySelector('.day-number')?.textContent || '';
        const date = day.querySelector('.day-date')?.value || '';
        const dayName = day.querySelector('.day-name')?.textContent || '';
        const title = day.querySelector('.day-title')?.value || '';
        const hotel = day.querySelector('.hotel-input')?.value || '-';
        const stars = day.querySelector('.star-select')?.value;
        const starStr = stars ? '★'.repeat(parseInt(stars)) : '';
        
        const bChecked = day.querySelector('.meal-b')?.checked;
        const lChecked = day.querySelector('.meal-l')?.checked;
        const dChecked = day.querySelector('.meal-d')?.checked;
        const meals = [bChecked ? 'B' : '', lChecked ? 'L' : '', dChecked ? 'D' : ''].filter(m => m).join(' / ') || 'None';
        
        let activities = [];
        day.querySelectorAll('.activity-input').forEach(input => {
            if (input.value.trim()) activities.push(input.value.trim());
        });
        
        itineraryHtml += `
            <div class="day-block">
                <div class="day-title-print">${dayNum}: ${title || date} ${dayName ? '(' + dayName + ')' : ''}</div>
                <div class="day-details">
                    <p><strong>Hotel:</strong> ${hotel} ${starStr}</p>
                    <p><strong>Meals:</strong> ${meals}</p>
                    ${activities.length > 0 ? '<p><strong>Activities:</strong></p><ul>' + activities.map(a => '<li>' + a + '</li>').join('') + '</ul>' : ''}
                </div>
            </div>
        `;
    });
    
    // Build pricing table
    let pricingHtml = '';
    document.querySelectorAll('#pricingBody tr').forEach(row => {
        const desc = row.querySelector('.price-desc')?.value || '-';
        const qty = row.querySelector('.price-qty')?.value || '0';
        const unit = row.querySelector('.price-unit')?.value || '-';
        const rate = row.querySelector('.price-rate')?.value || '0';
        const total = row.querySelector('.row-total')?.textContent || '$0.00';
        pricingHtml += `<tr><td>${desc}</td><td>${qty}</td><td>${unit}</td><td class="amount-col">${formatCurrency(parseFloat(rate) || 0)}</td><td class="amount-col">${total}</td></tr>`;
    });
    
    const subtotal = document.getElementById('calcSubtotal')?.textContent || '$0.00';
    const discount = document.getElementById('calcDiscount')?.textContent || '$0.00';
    const tax = document.getElementById('calcTax')?.textContent || '$0.00';
    const grandTotal = document.getElementById('calcGrandTotal')?.textContent || '$0.00';
    const perPax = document.getElementById('calcPerPax')?.textContent || '$0.00';
    
    const inclusions = document.getElementById('inclusions')?.value || '';
    const exclusions = document.getElementById('exclusions')?.value || '';
    const terms = document.getElementById('termsText')?.value || '';
    
    const html = `
        <div class="print-doc">
            <div class="company-header">
                <h1 class="company-name">TOURIX</h1>
                <p class="company-tagline">Travel & Tours</p>
            </div>
            
            <div class="quote-title">QUOTATION</div>
            
            <div class="info-row">
                <div class="info-box">
                    <h4>Bill To</h4>
                    <p><strong>${customerName}</strong></p>
                    <p>Contact: ${contactPerson}</p>
                    <p>Email: ${customerEmail}</p>
                    <p>Phone: ${customerPhone}</p>
                </div>
                <div class="info-box" style="text-align: right;">
                    <h4>Quote Details</h4>
                    <p><strong>Quote #:</strong> ${quoteNum}</p>
                    <p><strong>Date:</strong> ${quoteDate}</p>
                    <p><strong>Valid Until:</strong> ${validUntil}</p>
                    <p><strong>Passengers:</strong> ${paxCount}</p>
                </div>
            </div>
            
            <h3 class="section-title">Tour: ${tourName}</h3>
            <p><strong>Destination:</strong> ${destination} | <strong>Travel Date:</strong> ${travelDate}</p>
            
            <h3 class="section-title">Itinerary</h3>
            ${itineraryHtml}
            
            <h3 class="section-title">Pricing</h3>
            <table class="price-table">
                <thead>
                    <tr><th>Description</th><th>Qty</th><th>Unit</th><th class="amount-col">Rate</th><th class="amount-col">Amount</th></tr>
                </thead>
                <tbody>${pricingHtml}</tbody>
            </table>
            
            <div class="totals-box">
                <div class="total-line"><span>Subtotal</span><span>${subtotal}</span></div>
                <div class="total-line"><span>Discount</span><span>${discount}</span></div>
                <div class="total-line"><span>Tax</span><span>${tax}</span></div>
                <div class="total-line grand-total"><span>Grand Total</span><span>${grandTotal}</span></div>
                <div class="total-line"><span>Per Person</span><span>${perPax}</span></div>
            </div>
            
            ${inclusions ? '<h3 class="section-title">Inclusions</h3><div style="white-space: pre-line;">' + inclusions + '</div>' : ''}
            ${exclusions ? '<h3 class="section-title">Exclusions</h3><div style="white-space: pre-line;">' + exclusions + '</div>' : ''}
            
            <div class="terms-section">
                <h4>Terms & Conditions</h4>
                <div style="white-space: pre-line;">${terms}</div>
            </div>
            
            <div class="signature-area">
                <div class="signature-box">
                    <div class="signature-line">Authorized Signature (Company)</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line">Customer Acceptance</div>
                </div>
            </div>
        </div>
    `;
    
    previewDiv.innerHTML = html;
    if (printDiv) printDiv.innerHTML = html;
}

function printDocument() {
    generatePreviewContent();
    window.print();
}

// Keep old function names as aliases for backward compatibility
function initQuotationItinerary() { initQuotePage(); }
function initQuotationService() { initQuotePage(); }

function setupQuotationEventListeners() {
    const servicesList = document.getElementById('servicesList');
    if (servicesList) {
        servicesList.addEventListener('input', function(e) {
            if (e.target.classList.contains('service-qty') || e.target.classList.contains('service-price')) {
                updateServiceTotal(e.target.closest('.service-item'));
                calculateTotals();
            }
        });
    }
    
    const discountPercent = document.getElementById('discountPercent');
    const taxPercent = document.getElementById('taxPercent');
    const passengerCount = document.getElementById('passengerCount');
    
    if (discountPercent) discountPercent.addEventListener('input', calculateTotals);
    if (taxPercent) taxPercent.addEventListener('input', calculateTotals);
    if (passengerCount) passengerCount.addEventListener('input', calculateTotals);
}

function updateServiceTotal(serviceItem) {
    if (!serviceItem) return;
    const qty = parseFloat(serviceItem.querySelector('.service-qty')?.value) || 0;
    const price = parseFloat(serviceItem.querySelector('.service-price')?.value) || 0;
    const total = qty * price;
    const totalEl = serviceItem.querySelector('.service-total');
    if (totalEl) totalEl.textContent = '$' + total.toFixed(2);
}

function calculateTotals() {
    let subtotal = 0;
    document.querySelectorAll('.service-item').forEach(item => {
        const qty = parseFloat(item.querySelector('.service-qty')?.value) || 0;
        const price = parseFloat(item.querySelector('.service-price')?.value) || 0;
        subtotal += qty * price;
    });
    
    const discountPercent = parseFloat(document.getElementById('discountPercent')?.value) || 0;
    const taxPercent = parseFloat(document.getElementById('taxPercent')?.value) || 0;
    const passengerCount = parseInt(document.getElementById('passengerCount')?.value) || 1;
    
    const discountAmount = subtotal * (discountPercent / 100);
    const afterDiscount = subtotal - discountAmount;
    const taxAmount = afterDiscount * (taxPercent / 100);
    const grandTotal = afterDiscount + taxAmount;
    const perPerson = grandTotal / passengerCount;
    
    const subtotalEl = document.getElementById('subtotal');
    const discountEl = document.getElementById('discountAmount');
    const taxEl = document.getElementById('taxAmount');
    const grandTotalEl = document.getElementById('grandTotal');
    const perPersonEl = document.getElementById('perPerson');
    const paxCountEl = document.getElementById('paxCount');
    
    if (subtotalEl) subtotalEl.textContent = '$' + subtotal.toFixed(2);
    if (discountEl) discountEl.textContent = '-$' + discountAmount.toFixed(2);
    if (taxEl) taxEl.textContent = '$' + taxAmount.toFixed(2);
    if (grandTotalEl) grandTotalEl.textContent = '$' + grandTotal.toFixed(2);
    if (perPersonEl) perPersonEl.textContent = '$' + perPerson.toFixed(2);
    if (paxCountEl) paxCountEl.textContent = passengerCount;
}

function addService() {
    const servicesList = document.getElementById('servicesList');
    if (!servicesList) return;
    
    const serviceHtml = `
        <div class="service-item">
            <select class="service-category">
                <option value="">Select Category</option>
                <option value="accommodation">Accommodation</option>
                <option value="transport">Transportation</option>
                <option value="transfer">Airport Transfer</option>
                <option value="tours">Tours & Activities</option>
                <option value="meals">Meals</option>
                <option value="guide">Guide Services</option>
                <option value="visa">Visa & Documents</option>
                <option value="insurance">Travel Insurance</option>
                <option value="other">Other</option>
            </select>
            <input type="text" class="service-name" placeholder="Service description">
            <input type="number" class="service-qty" value="1" min="1" placeholder="Qty">
            <input type="number" class="service-price" placeholder="Unit Price" step="0.01">
            <span class="service-total">$0.00</span>
            <button class="btn-icon remove-service" onclick="removeService(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    servicesList.insertAdjacentHTML('beforeend', serviceHtml);
}

function removeService(btn) {
    const serviceItem = btn.closest('.service-item');
    if (document.querySelectorAll('.service-item').length > 1) {
        serviceItem.remove();
        calculateTotals();
    }
}

function addItineraryDay() {
    dayCounter++;
    const itineraryList = document.getElementById('itineraryList');
    if (!itineraryList) return;
    
    const dayHtml = `
        <div class="itinerary-day-card" data-day="${dayCounter}">
            <div class="day-header-bar">
                <div class="day-number-badge">Day ${dayCounter}</div>
                <div class="day-date-picker">
                    <input type="date" class="day-date" onchange="updateDayOfWeek(this)">
                    <span class="day-of-week">Select date</span>
                </div>
                <input type="text" class="day-title-input" placeholder="Day title (e.g., City Tour)">
                <button type="button" class="btn-icon-delete" onclick="removeItineraryDay(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            
            <div class="day-body">
                <!-- Hotel Section -->
                <div class="day-section hotel-section">
                    <div class="section-label"><i class="fas fa-hotel"></i> Accommodation</div>
                    <div class="hotel-inputs">
                        <input type="text" class="hotel-name" placeholder="Hotel name">
                        <div class="hotel-grade">
                            <select class="star-rating">
                                <option value="">Star</option>
                                <option value="1">⭐</option>
                                <option value="2">⭐⭐</option>
                                <option value="3">⭐⭐⭐</option>
                                <option value="4">⭐⭐⭐⭐</option>
                                <option value="5">⭐⭐⭐⭐⭐</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Meals Section -->
                <div class="day-section meals-section">
                    <div class="section-label"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="meals-grid">
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="breakfast">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Breakfast</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="lunch">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Lunch</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-item">
                            <div class="meal-header">
                                <label class="meal-toggle">
                                    <input type="checkbox" class="meal-included" data-meal="dinner">
                                    <span class="toggle-slider"></span>
                                </label>
                                <span class="meal-name">Dinner</span>
                            </div>
                            <input type="text" class="meal-menu" placeholder="Menu details..." disabled>
                        </div>
                    </div>
                </div>

                <!-- Sightseeing & Activities Section -->
                <div class="day-section activities-section">
                    <div class="section-label"><i class="fas fa-camera"></i> Sightseeing & Activities</div>
                    <div class="activities-list">
                        <div class="activity-row">
                            <span class="activity-number">1</span>
                            <input type="text" class="activity-input" placeholder="Enter sightseeing or activity...">
                            <button type="button" class="btn-add-activity" onclick="addActivity(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    itineraryList.insertAdjacentHTML('beforeend', dayHtml);
    
    // Setup meal toggle listeners for new day
    setupMealToggles();
}

function removeItineraryDay(btn) {
    const dayItem = btn.closest('.itinerary-day-card');
    if (document.querySelectorAll('.itinerary-day-card').length > 1) {
        dayItem.remove();
        renumberDays();
    }
}

function renumberDays() {
    document.querySelectorAll('.itinerary-day-card').forEach((day, index) => {
        day.dataset.day = index + 1;
        day.querySelector('.day-number-badge').textContent = 'Day ' + (index + 1);
    });
    dayCounter = document.querySelectorAll('.itinerary-day-card').length;
}

// Update day of week when date is selected
function updateDayOfWeek(dateInput) {
    const dayCard = dateInput.closest('.itinerary-day-card');
    const dayOfWeekSpan = dayCard.querySelector('.day-of-week');
    
    if (dateInput.value) {
        const date = new Date(dateInput.value);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        dayOfWeekSpan.textContent = days[date.getDay()];
    } else {
        dayOfWeekSpan.textContent = 'Select date';
    }
}

// Setup meal toggles to enable/disable menu input
function setupMealToggles() {
    document.querySelectorAll('.meal-included').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const mealItem = this.closest('.meal-item');
            const menuInput = mealItem.querySelector('.meal-menu');
            menuInput.disabled = !this.checked;
            if (!this.checked) {
                menuInput.value = '';
            }
        });
    });
}

// Initialize meal toggles on page load
function initQuotationItinerary() {
    try {
        // Check for saved quotation data (editing mode)
        const savedData = localStorage.getItem('currentQuotation');
        if (savedData) {
            const data = JSON.parse(savedData);
            // Populate form with saved data
            populateItineraryForm(data);
            // Clear the saved data after loading
            localStorage.removeItem('currentQuotation');
            return;
        }
        
        // New quotation - set default dates
        const today = new Date();
        const validDate = new Date(today);
        validDate.setDate(validDate.getDate() + 30);
        
        const quotationDate = document.getElementById('quotationDate');
        const validUntil = document.getElementById('validUntil');
        
        if (quotationDate) quotationDate.value = formatDateForInput(today);
        if (validUntil) validUntil.value = formatDateForInput(validDate);
        
        // Generate quotation number
        const quotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const quotationNumber = document.getElementById('quotationNumber');
        if (quotationNumber) quotationNumber.value = quotationNo;
        
        // Setup event listeners for pricing calculation
        setupPricingListeners();
        
        // Reset day counter
        dayCounter = document.querySelectorAll('.day-card').length || 1;
        
        // Initialize first day date
        const firstDayDate = document.querySelector('.day-card .day-date');
        if (firstDayDate && !firstDayDate.value) {
            firstDayDate.value = formatDateForInput(today);
            updateDayOfWeekNew(firstDayDate);
        }
    } catch (err) {
        console.error('Error in initQuotationItinerary:', err);
    }
}

function initQuotationService() {
    try {
        // Check for saved quotation data (editing mode)
        const savedData = localStorage.getItem('currentQuotation');
        if (savedData) {
            const data = JSON.parse(savedData);
            // Populate form with saved data
            populateServiceForm(data);
            // Clear the saved data after loading
            localStorage.removeItem('currentQuotation');
            return;
        }
        
        // New quotation - set default dates
        const today = new Date();
        const validDate = new Date(today);
        validDate.setDate(validDate.getDate() + 30);
        
        const quotationDate = document.getElementById('quotationDate');
        const validUntil = document.getElementById('validUntil');
        
        if (quotationDate) quotationDate.value = formatDateForInput(today);
        if (validUntil) validUntil.value = formatDateForInput(validDate);
        
        // Generate quotation number
        const quotationNo = 'QT-' + today.getFullYear() + '-' + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
        const quotationNumber = document.getElementById('quotationNumber');
        if (quotationNumber) quotationNumber.value = quotationNo;
        
        // Setup event listeners for pricing calculation
        setupPricingListeners();
    } catch (err) {
        console.error('Error in initQuotationService:', err);
    }
}

// Populate service form with saved data (for editing)
function populateServiceForm(data) {
    if (!data) {
        console.error('No data to populate');
        return;
    }
    
    console.log('Populating service form with data:', data);
    
    // Helper to set input value
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el && val !== undefined && val !== null) {
            el.value = val;
            console.log('Set', id, '=', val);
        }
    };
    
    // Basic Info
    setVal('quotationNumber', data.quotation_number);
    setVal('quotationDate', data.quotation_date);
    setVal('validUntil', data.valid_until);
    
    // Update display ID
    const displayQuoteId = document.getElementById('displayQuoteId');
    if (displayQuoteId) displayQuoteId.textContent = data.quotation_number;
    
    // Customer Info
    setVal('customerName', data.customer_name);
    setVal('contactPerson', data.contact_person);
    setVal('customerEmail', data.customer_email);
    setVal('customerPhone', data.customer_phone);
    setVal('customerNationality', data.nationality);
    
    // Service Info
    setVal('serviceType', data.service_type);
    setVal('serviceDate', data.service_date);
    setVal('paxCount', data.pax_count);
    
    // Pricing settings
    setVal('discountPercent', data.discount_percent);
    setVal('taxPercent', data.tax_percent);
    setVal('handlingFeePercent', data.handling_fee_percent);
    
    // Notes and Terms
    setVal('quotationNotes', data.notes);
    setVal('quotationTerms', data.terms);
    
    // Setup event listeners for pricing calculation
    setupPricingListeners();
    
    // Clear localStorage after loading
    localStorage.removeItem('currentQuotation');
    
    console.log('Successfully loaded service quotation:', data.quotation_number);
    showNotification('Quotation loaded for editing', 'success');
}

// Setup pricing event listeners
function setupPricingListeners() {
    const discountInput = document.getElementById('discountPercent');
    const taxInput = document.getElementById('taxPercent');
    const paxInput = document.getElementById('paxCount');
    
    if (discountInput) discountInput.addEventListener('input', calculatePricingSummary);
    if (taxInput) taxInput.addEventListener('input', calculatePricingSummary);
    if (paxInput) paxInput.addEventListener('input', calculatePricingSummary);
}

// Update day of week for new structure
function updateDayOfWeekNew(dateInput) {
    if (!dateInput) return;
    const dayCard = dateInput.closest('.day-card');
    if (!dayCard) return;
    const dayOfWeekSpan = dayCard.querySelector('.day-of-week');
    if (!dayOfWeekSpan) return;
    
    if (dateInput.value) {
        const date = new Date(dateInput.value);
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        dayOfWeekSpan.textContent = days[date.getDay()];
    } else {
        dayOfWeekSpan.textContent = 'Select date';
    }
}

// Add new day card
function addDayCard() {
    const daysContainer = document.getElementById('daysContainer');
    if (!daysContainer) return;
    
    const dayCards = daysContainer.querySelectorAll('.day-card');
    const newDayNum = dayCards.length + 1;
    
    // Calculate next date based on last day
    let nextDate = new Date();
    if (dayCards.length > 0) {
        const lastDayDate = dayCards[dayCards.length - 1].querySelector('.day-date')?.value;
        if (lastDayDate) {
            nextDate = new Date(lastDayDate);
            nextDate.setDate(nextDate.getDate() + 1);
        }
    }
    
    const dayHtml = `
        <div class="day-card" data-day="${newDayNum}">
            <div class="day-header">
                <div class="day-badge">Day ${newDayNum}</div>
                <div class="day-date-group">
                    <input type="date" class="day-date" value="${formatDateForInput(nextDate)}" onchange="updateDayOfWeekNew(this)">
                    <span class="day-of-week">${getDayName(nextDate)}</span>
                </div>
                <button type="button" class="btn-remove-day" onclick="removeDayCard(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            
            <div class="day-body">
                <!-- Hotel Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-hotel"></i> Accommodation</div>
                    <div class="hotel-row">
                        <input type="text" class="hotel-name" placeholder="Hotel name">
                        <select class="hotel-star">
                            <option value="">Star Rating</option>
                            <option value="1">★</option>
                            <option value="2">★★</option>
                            <option value="3">★★★</option>
                            <option value="4">★★★★</option>
                            <option value="5">★★★★★</option>
                        </select>
                    </div>
                </div>
                
                <!-- Meals Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-utensils"></i> Meals</div>
                    <div class="meals-row">
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-breakfast" onchange="toggleMealInput(this)">
                                <span class="meal-name">Breakfast</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-lunch" onchange="toggleMealInput(this)">
                                <span class="meal-name">Lunch</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                        <div class="meal-box">
                            <label class="meal-label">
                                <input type="checkbox" class="meal-checkbox meal-dinner" onchange="toggleMealInput(this)">
                                <span class="meal-name">Dinner</span>
                            </label>
                            <input type="text" class="meal-menu-input" placeholder="Menu details..." disabled>
                        </div>
                    </div>
                </div>
                
                <!-- Activities Section -->
                <div class="day-section">
                    <div class="section-title"><i class="fas fa-camera"></i> Sightseeing & Activities</div>
                    <div class="activities-list">
                        <div class="activity-row">
                            <span class="activity-num">1</span>
                            <input type="text" class="activity-input" placeholder="Enter sightseeing or activity...">
                            <button type="button" class="btn-add-activity" onclick="addActivityLine(this)">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    daysContainer.insertAdjacentHTML('beforeend', dayHtml);
}

// Get day name from date
function getDayName(date) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[date.getDay()];
}

// Remove day card
function removeDayCard(btn) {
    const dayCard = btn.closest('.day-card');
    const container = dayCard.closest('#daysContainer');
    
    if (container.querySelectorAll('.day-card').length > 1) {
        dayCard.remove();
        // Renumber days
        container.querySelectorAll('.day-card').forEach((card, i) => {
            card.dataset.day = i + 1;
            card.querySelector('.day-badge').textContent = 'Day ' + (i + 1);
        });
    }
}

// ==========================================
// Dashboard Charts
// ==========================================
function initDashboardCharts() {
    // Quotations Chart
    const quotationsCtx = document.getElementById('quotationsChart');
    if (quotationsCtx) {
        new Chart(quotationsCtx, {
            type: 'doughnut',
            data: {
                labels: ['Sent', 'Confirmed', 'Cancelled'],
                datasets: [{
                    data: [45, 28, 12],
                    backgroundColor: ['#2563EB', '#10B981', '#EF4444'],
                    borderWidth: 0,
                    cutout: '75%'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
}

// ==========================================
// Contact Filters
// ==========================================
function initContactFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const contactCards = document.querySelectorAll('.contact-card');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const filter = this.dataset.filter;
            contactCards.forEach(card => {
                if (filter === 'all' || card.dataset.type === filter) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// ==========================================
// Dark Mode Toggle
// ==========================================
const darkModeToggle = document.getElementById('darkModeToggle');
const body = document.body;

// Check for saved dark mode preference
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    body.classList.add('dark-mode');
    if (darkModeToggle) darkModeToggle.checked = true;
}

if (darkModeToggle) {
    darkModeToggle.addEventListener('change', () => {
        body.classList.toggle('dark-mode');
        const theme = body.classList.contains('dark-mode') ? 'dark' : 'light';
        localStorage.setItem('theme', theme);
    });
}

// ==========================================
// Update Current Date
// ==========================================
function updateDate() {
    const dateElement = document.getElementById('currentDate');
    if (dateElement) {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        const currentDate = new Date().toLocaleDateString('en-US', options);
        dateElement.textContent = currentDate;
    }
}
updateDate();

// ==========================================
// Navigation Event Listeners
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    // Handle sidebar navigation clicks
    const navItems = document.querySelectorAll('.nav-menu .nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            if (page) {
                loadContent(page);
                // Close sidebar on mobile after navigation
                if (window.innerWidth <= 768) {
                    document.querySelector('.sidebar').classList.remove('active');
                    document.body.classList.remove('sidebar-open');
                }
            }
        });
    });
    
    // Hamburger menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            document.body.classList.toggle('sidebar-open');
        });
    }
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            const sidebar = document.querySelector('.sidebar');
            const menuToggle = document.getElementById('menuToggle');
            
            if (sidebar.classList.contains('active') && 
                !sidebar.contains(e.target) && 
                !menuToggle.contains(e.target)) {
                sidebar.classList.remove('active');
                document.body.classList.remove('sidebar-open');
            }
        }
    });
    
    // Load initial content (dashboard)
    loadContent('dashboard');
});

// ==========================================
// Filter Tabs Functionality
// ==========================================
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('tab')) {
        const tabs = e.target.parentElement.querySelectorAll('.tab');
        tabs.forEach(t => t.classList.remove('active'));
        e.target.classList.add('active');
    }
});

// ==========================================
// Icon Button Animations
// ==========================================
// Icon Button Animations
// ==========================================
document.addEventListener('click', function(e) {
    if (e.target.closest('.icon-btn')) {
        const btn = e.target.closest('.icon-btn');
        btn.style.transform = 'scale(0.95)';
        setTimeout(() => {
            btn.style.transform = '';
        }, 150);
    }
});

// ==========================================
// Loading Spinner Styles
// ==========================================
const spinnerStyles = document.createElement('style');
spinnerStyles.textContent = `
    .loading-spinner {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 300px;
        color: var(--text-secondary);
    }
    .loading-spinner i {
        font-size: 40px;
        color: var(--primary-blue);
        margin-bottom: 16px;
    }
    .error-message {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 300px;
        text-align: center;
        color: var(--text-secondary);
    }
    .error-message i {
        font-size: 48px;
        color: #F59E0B;
        margin-bottom: 16px;
    }
    .error-message h3 {
        color: var(--text-primary);
        margin-bottom: 8px;
    }
    .error-message button {
        margin-top: 20px;
    }
`;
document.head.appendChild(spinnerStyles);

// Console welcome message
console.log('%c🎯 TOURIX Dashboard v1.0', 'color: #4F46E5; font-size: 20px; font-weight: bold;');
console.log('%cDeveloped for tour and travel management', 'color: #6B7280; font-size: 12px;');
