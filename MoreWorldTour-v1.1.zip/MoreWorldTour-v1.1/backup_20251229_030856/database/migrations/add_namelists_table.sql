-- ==========================================
-- TOURIX - Add Namelists Table Migration
-- Stores passenger namelist data for bookings
-- ==========================================

-- ==========================================
-- NAMELISTS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS namelists (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id VARCHAR(100) NOT NULL,
    passengers JSONB DEFAULT '[]'::jsonb,
    passenger_count INTEGER DEFAULT 0,
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Ensure one namelist per booking
    CONSTRAINT unique_booking_namelist UNIQUE (booking_id)
);

CREATE INDEX idx_namelists_booking ON namelists(booking_id);

-- ==========================================
-- ROW LEVEL SECURITY (RLS)
-- ==========================================
ALTER TABLE namelists ENABLE ROW LEVEL SECURITY;

-- Allow all operations for authenticated and anon users (adjust as needed)
CREATE POLICY "Allow all operations on namelists" ON namelists
    FOR ALL
    USING (true)
    WITH CHECK (true);

-- ==========================================
-- AUTO-UPDATE TRIGGER for updated_at
-- ==========================================
CREATE OR REPLACE FUNCTION update_namelists_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_namelists_updated_at
    BEFORE UPDATE ON namelists
    FOR EACH ROW
    EXECUTE FUNCTION update_namelists_updated_at();

-- ==========================================
-- SAMPLE DATA STRUCTURE FOR passengers JSONB
-- ==========================================
-- The passengers column stores an array of passenger objects:
-- [
--   {
--     "title": "Mr",
--     "name": "John Doe",
--     "gender": "Male",
--     "dob": "1990-05-15",
--     "passport": "AB1234567",
--     "room": "101",
--     "remarks": "Vegetarian meal"
--   },
--   {
--     "title": "Ms",
--     "name": "Jane Doe",
--     "gender": "Female",
--     "dob": "1992-08-22",
--     "passport": "CD7654321",
--     "room": "101",
--     "remarks": ""
--   }
-- ]
