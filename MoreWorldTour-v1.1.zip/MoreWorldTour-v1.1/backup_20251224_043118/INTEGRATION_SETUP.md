# 🚀 Supabase Integration - Quick Setup

## ✅ What's Been Completed:

1. ✅ Database schema created (8 tables)
2. ✅ Supabase JavaScript library added to project
3. ✅ Database helper functions created
4. ✅ Quotation form connected to save data

## 📝 What You Need to Do Now:

### Step 1: Add Your Supabase Credentials

Open this file: **`config/supabase-config.js`**

Replace these two lines with your actual credentials:

```javascript
const SUPABASE_URL = 'YOUR_SUPABASE_PROJECT_URL';  
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
```

**Where to get them:**
1. Go to your Supabase project dashboard
2. Click **Settings** (left sidebar) → **API**
3. Copy:
   - **Project URL** → Replace `YOUR_SUPABASE_PROJECT_URL`
   - **anon public** key → Replace `YOUR_SUPABASE_ANON_KEY`

### Step 2: Restart Your Server

```powershell
# Stop current server (Ctrl+C in the terminal)
# Then restart:
cd c:\Backup\TOURIX
npx http-server -p 3000 -c-1
```

### Step 3: Test the Integration

1. Open browser: http://127.0.0.1:3000
2. Navigate to **Quotations** → **Quotation with Itinerary**
3. Fill out the form with test data
4. Click **Save Draft** button
5. Check for success notification (green box top-right)
6. Verify in Supabase:
   - Go to Supabase dashboard
   - Click **Table Editor**
   - Check **quotations** table - you should see your saved data!

---

## 📚 What's Available Now:

### Database Functions (window.db):

**Quotations:**
- `db.saveQuotationItinerary(data, days, items)` - Save itinerary quotation
- `db.saveQuotationService(data, items)` - Save service quotation
- `db.getAllQuotations(limit)` - Get all quotations
- `db.getQuotation(id)` - Get single quotation with details
- `db.updateQuotation(id, updates)` - Update quotation
- `db.deleteQuotation(id)` - Delete quotation
- `db.getNextQuotationNumber()` - Generate next quote number

**Customers:**
- `db.saveCustomer(data)` - Save customer
- `db.searchCustomers(term)` - Search customers
- `db.getAllCustomers(limit)` - Get all customers

### Form Functions:

- `saveAsDraft()` - Save quotation as draft
- `saveQuotation(status)` - Save with custom status
- Auto-generates quote numbers from database
- Shows success/error notifications

---

## 🧪 Testing Checklist:

- [ ] Add Supabase credentials to config file
- [ ] Restart server
- [ ] Create test quotation
- [ ] Click "Save Draft"
- [ ] See green success message
- [ ] Verify data in Supabase Table Editor
- [ ] Check quotations table has 1 row
- [ ] Check itinerary_days table has day records
- [ ] Check activities table has activity records
- [ ] Check pricing_items table has pricing records

---

## 🎯 Next Steps (After Testing Works):

1. **Load quotations** - Display saved quotes in the quotations list
2. **Edit quotations** - Load and update existing quotes
3. **Delete quotations** - Remove quotes
4. **Service quotations** - Connect service form to database
5. **Customer management** - Save/search customers
6. **Bookings** - Convert quotes to bookings

---

## ⚠️ Common Issues:

**Error: "supabase is not defined"**
- Make sure Supabase library loaded (check browser console)
- Verify script order in index.html

**Error: "Failed to save"**
- Check Supabase credentials are correct
- Verify SQL schema ran successfully
- Check browser console for detailed error

**Quote number doesn't increment**
- This is expected on first save (starts at QT-2025-0001)
- Second quotation should be QT-2025-0002

---

## 🔧 Files Modified:

1. **index.html** - Added Supabase library and config scripts
2. **script.js** - Updated saveAsDraft() to save to database
3. **config/supabase-config.js** - New: Supabase connection
4. **config/database.js** - New: All database functions

---

## 📱 Need Help?

Check browser console (F12) for detailed error messages!
