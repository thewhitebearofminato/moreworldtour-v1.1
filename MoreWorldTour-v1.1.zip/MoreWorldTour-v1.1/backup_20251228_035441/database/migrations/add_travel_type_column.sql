-- ==========================================
-- Migration: Add travel_type column to bookings table
-- Date: 2025-12-28
-- ==========================================

-- Add travel_type column to store the type of travel
-- Values: Leisure, MICE, Incentive, FIT, Group Tour, Corporate, Educational, Pilgrimage, Medical, Adventure, Special Interest, Bleisure
ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS travel_type VARCHAR(50);

-- Add comment for documentation
COMMENT ON COLUMN bookings.travel_type IS 'Type of travel: Leisure, MICE, Incentive, FIT (Private), Group Tour, Corporate/Business, Educational/Student, Pilgrimage/Religious, Medical/Wellness, Adventure/Activity, Special Interest, Bleisure';

-- Create index for filtering by travel type
CREATE INDEX IF NOT EXISTS idx_bookings_travel_type ON bookings(travel_type);

-- ==========================================
-- Verify the column was added
-- ==========================================
-- Run this to check: SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'bookings' AND column_name = 'travel_type';
